"""Build isolated APK counterexamples for registered WebViewClient inputs.

Usage: python tests/build_webview_callback_fixtures.py /path/to/apktool.jar
These independent classes deliberately have no CVE- or package-specific rules.
"""
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).parent / 'fixtures' / 'webview-callbacks'
SMALI = ROOT / 'smali' / 'callbacks'
SMALI.mkdir(parents=True, exist_ok=True)
(ROOT / 'apktool.yml').write_text((ROOT.parent / 'apktool.yml').read_text())

manifest = ['''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dotori.callbacks">
<uses-sdk android:minSdkVersion="21" android:targetSdkVersion="34"/>
<application android:label="Callback regression cases">''']

(SMALI / 'Bridge.smali').write_text('''.class public Lcallbacks/Bridge;
.super Ljava/lang/Object;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 return-void
.end method
.method public call(Ljava/lang/String;)V
 .registers 2
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 return-void
.end method
''')

for name in ('Registered', 'Request', 'PageStarted', 'PageFinished', 'Unregistered',
             'Conditional', 'WrongView', 'Captured', 'WrongInstance'):
    request = name == 'Request'
    captured = name in ('Captured', 'WrongInstance')
    descriptor = ('(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Z' if request else
                  '(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V' if name == 'PageStarted' else
                  '(Landroid/webkit/WebView;Ljava/lang/String;)V' if name == 'PageFinished' else
                  '(Landroid/webkit/WebView;Ljava/lang/String;)Z')
    callback_name = 'onPageStarted' if name == 'PageStarted' else 'onPageFinished' if name == 'PageFinished' else 'shouldOverrideUrlLoading'
    constructor = '(Landroid/webkit/WebView;)V' if captured else '()V'
    capture_field = '.field private web:Landroid/webkit/WebView;\n' if captured else ''
    capture_write = f' iput-object p1,p0,Lcallbacks/{name}Client;->web:Landroid/webkit/WebView;\n' if captured else ''
    callback = f'''.class public Lcallbacks/{name}Client;
.super Landroid/webkit/WebViewClient;
{capture_field}.method public constructor <init>{constructor}
 .registers {2 if captured else 1}
 invoke-direct {{p0}},Landroid/webkit/WebViewClient;-><init>()V
{capture_write} return-void
.end method
.method public {callback_name}{descriptor}
 .locals 2
'''
    if captured:
        callback += f' iget-object v0,p0,Lcallbacks/{name}Client;->web:Landroid/webkit/WebView;\n'
    if request:
        callback += ''' invoke-interface {p2},Landroid/webkit/WebResourceRequest;->getUrl()Landroid/net/Uri;
 move-result-object v1
 invoke-virtual {v1},Landroid/net/Uri;->toString()Ljava/lang/String;
 move-result-object v1
'''
    callback += ' invoke-virtual {' + ('v0' if captured else 'p1') + ',' + ('v1' if request else 'p2') + '},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V\n'
    callback += ' const/4 v1,0x1\n return v1\n.end method\n' if descriptor.endswith('Z') else ' return-void\n.end method\n'
    (SMALI / (name + 'Client.smali')).write_text(callback)

    setup = f'''.class public Lcallbacks/{name};
.super Landroid/app/Activity;
.method public constructor <init>()V
 .registers 1
 invoke-direct {{p0}},Landroid/app/Activity;-><init>()V
 return-void
.end method
.method public onCreate(Landroid/os/Bundle;)V
 .locals 6
 new-instance v0,Landroid/webkit/WebView;
 invoke-direct {{v0,p0}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v4,Landroid/webkit/WebView;
 invoke-direct {{v4,p0}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1,Lcallbacks/{name}Client;
 invoke-direct {{{'v1,v0' if captured else 'v1'}}},Lcallbacks/{name}Client;-><init>{constructor}
'''
    if name == 'WrongInstance':
        setup += f''' new-instance v5,Lcallbacks/{name}Client;
 invoke-direct {{v5,v4}},Lcallbacks/{name}Client;-><init>{constructor}
'''
    if name == 'Conditional':
        setup += ' if-eqz p1,:done\n'
    if name != 'Unregistered':
        setup += ' invoke-virtual {' + ('v4' if name == 'WrongView' else 'v0') + ',' + ('v5' if name == 'WrongInstance' else 'v1') + '},Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V\n'
    setup += ''' new-instance v2,Lcallbacks/Bridge;
 invoke-direct {v2},Lcallbacks/Bridge;-><init>()V
 const-string v3,"Native"
 invoke-virtual {v0,v2,v3},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 :done
 return-void
.end method
'''
    (SMALI / (name + '.smali')).write_text(setup)
    manifest.append(f'<activity android:name="callbacks.{name}" android:exported="true"/>')

for name in ('Symbolic', 'SymbolicWrongView'):
    (SMALI / (name + 'Client.smali')).write_text(f'''.class public Lcallbacks/{name}Client;
.super Landroid/webkit/WebViewClient;
.method public constructor <init>()V
 .registers 1
 invoke-direct {{p0}},Landroid/webkit/WebViewClient;-><init>()V
 return-void
.end method
.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
 .registers 4
 invoke-virtual {{p1,p2}},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 const/4 v0,0x1
 return v0
.end method
''')
    # No DEX constructor caller: this represents a framework/XML-created view.
    # The model must preserve a symbolic constructor relation, not invent an
    # allocation or merge the second WebView with p0.
    (SMALI / (name + 'View.smali')).write_text(f'''.class public Lcallbacks/{name}View;
.super Landroid/webkit/WebView;
.method public constructor <init>(Landroid/content/Context;)V
 .locals 5
 invoke-direct {{p0,p1}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 move-object v0,p0
 new-instance v4,Landroid/webkit/WebView;
 invoke-direct {{v4,p1}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1,Lcallbacks/{name}Client;
 invoke-direct {{v1}},Lcallbacks/{name}Client;-><init>()V
 invoke-virtual {{v0,v1}},Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V
 new-instance v2,Lcallbacks/Bridge;
 invoke-direct {{v2}},Lcallbacks/Bridge;-><init>()V
 const-string v3,"Native"
 invoke-virtual {{{'v4' if name == 'SymbolicWrongView' else 'v0'},v2,v3}},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 return-void
.end method
''')

manifest.append('</application></manifest>')
(ROOT / 'AndroidManifest.xml').write_text('\n'.join(manifest))
if len(sys.argv) > 1:
    output = ROOT.parent / 'webview-callbacks.apk'
    subprocess.run(['java', '-jar', sys.argv[1], 'b', str(ROOT), '-o', str(output)], check=True)
    # Apktool can copy an XML-only manifest as raw bytes in resource-free
    # projects. Compile this fixture's own manifest using the official AAPT2
    # and Android framework already bundled in that same trusted APKtool jar.
    with tempfile.TemporaryDirectory(prefix='dotori-callback-build-') as folder:
        folder = Path(folder)
        with zipfile.ZipFile(sys.argv[1]) as archive:
            aapt = folder / 'aapt2'
            aapt.write_bytes(archive.read('prebuilt/linux/aapt2_64'))
            aapt.chmod(0o755)
            framework = folder / 'android-framework.jar'
            framework.write_bytes(archive.read('prebuilt/android-framework.jar'))
        packed_manifest = folder / 'manifest.apk'
        subprocess.run([str(aapt), 'link', '--manifest', str(ROOT / 'AndroidManifest.xml'),
                        '-I', str(framework), '-o', str(packed_manifest)], check=True)
        with zipfile.ZipFile(output) as archive:
            files = {name: archive.read(name) for name in archive.namelist()}
        with zipfile.ZipFile(packed_manifest) as archive:
            files['AndroidManifest.xml'] = archive.read('AndroidManifest.xml')
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name, content in files.items():
                archive.writestr(name, content)
