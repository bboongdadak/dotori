.class public Luri/Conditional;
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 10
 invoke-virtual {p0},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v1
 invoke-virtual {v1},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v1
 const-string v2,"fixed"
 new-instance v3,Landroid/webkit/WebView;
 invoke-direct {v3,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v4,Luri/Bridge;
 invoke-direct {v4},Ljava/lang/Object;-><init>()V
 const-string v5,"Native"
 invoke-virtual {v3,v4,v5},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 new-instance v0,Landroid/net/Uri$Builder;
 invoke-direct {v0},Landroid/net/Uri$Builder;-><init>()V
 const-string v5,"https"
 invoke-virtual {v0,v5},Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;
 const-string v5,"fixed.invalid"
 invoke-virtual {v0,v5},Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;
 const-string v5,"item"
 if-eqz p1,:after
 invoke-virtual {v0,v1},Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;
 :after
 invoke-virtual {v0},Landroid/net/Uri$Builder;->build()Landroid/net/Uri;
 move-result-object v7
 invoke-virtual {v7},Landroid/net/Uri;->toString()Ljava/lang/String;
 move-result-object v7
 invoke-virtual {v3,v7},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
