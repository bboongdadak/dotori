.class public Luri/Helpers;
.super Ljava/lang/Object;
.method public static put(Landroid/net/Uri$Builder;Ljava/lang/String;)V
 .registers 2
 invoke-virtual {p0,p1},Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;
 return-void
.end method
.method public static get(Landroid/net/Uri$Builder;)Ljava/lang/String;
 .locals 1
 invoke-virtual {p0},Landroid/net/Uri$Builder;->build()Landroid/net/Uri;
 move-result-object v0
 invoke-virtual {v0},Landroid/net/Uri;->toString()Ljava/lang/String;
 move-result-object v0
 return-object v0
.end method
