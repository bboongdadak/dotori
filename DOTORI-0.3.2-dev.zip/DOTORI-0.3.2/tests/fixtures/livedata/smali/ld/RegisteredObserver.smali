.class public Lld/RegisteredObserver;
.super Ljava/lang/Object;
.implements Landroidx/lifecycle/Observer;
.field private web:Landroid/webkit/WebView;
.method public constructor <init>(Landroid/webkit/WebView;)V
 .registers 2
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 iput-object p1,p0,Lld/RegisteredObserver;->web:Landroid/webkit/WebView;
 return-void
.end method
.method public onChanged(Ljava/lang/Object;)V
 .locals 1
 iget-object v0,p0,Lld/RegisteredObserver;->web:Landroid/webkit/WebView;
 check-cast p1,Ljava/lang/String;
 invoke-virtual {v0,p1},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
