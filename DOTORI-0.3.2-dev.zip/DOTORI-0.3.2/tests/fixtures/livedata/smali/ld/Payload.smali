.class public Lld/Payload;
.super Ljava/lang/Object;
.field public value:Ljava/lang/Object;
.method public constructor <init>(Ljava/lang/Object;)V
 .registers 2
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 iput-object p1,p0,Lld/Payload;->value:Ljava/lang/Object;
 return-void
.end method
