.class public Lld/Wrapped;
.super Landroid/app/Activity;
.implements Landroidx/lifecycle/LifecycleOwner;
.field private static first:Landroidx/lifecycle/MutableLiveData;
.field private static second:Landroidx/lifecycle/MutableLiveData;
.method static constructor <clinit>()V
 .registers 1
 new-instance v0,Landroidx/lifecycle/MutableLiveData;
 invoke-direct {v0},Landroidx/lifecycle/MutableLiveData;-><init>()V
 sput-object v0,Lld/Wrapped;->first:Landroidx/lifecycle/MutableLiveData;
 new-instance v0,Landroidx/lifecycle/MutableLiveData;
 invoke-direct {v0},Landroidx/lifecycle/MutableLiveData;-><init>()V
 sput-object v0,Lld/Wrapped;->second:Landroidx/lifecycle/MutableLiveData;
 return-void
.end method
.method public onCreate(Landroid/os/Bundle;)V
 .locals 5
 new-instance v0,Landroid/webkit/WebView;
 invoke-direct {v0,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1,Lld/WrappedObserver;
 invoke-direct {v1,v0},Lld/WrappedObserver;-><init>(Landroid/webkit/WebView;)V
 new-instance v2,Lld/Bridge;
 const-string v3,"Native"
 invoke-virtual {v0,v2,v3},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 sget-object v2,Lld/Wrapped;->first:Landroidx/lifecycle/MutableLiveData;
 invoke-virtual {v2,p0,v1},Landroidx/lifecycle/MutableLiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
 return-void
.end method
.method public onNewIntent(Landroid/content/Intent;)V
 .locals 4
 sget-object v0,Lld/Wrapped;->first:Landroidx/lifecycle/MutableLiveData;
 invoke-virtual {p1},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v1
 new-instance v2,Lld/Payload;
 invoke-direct {v2,v1},Lld/Payload;-><init>(Ljava/lang/Object;)V
 invoke-virtual {v0,v2},Landroidx/lifecycle/MutableLiveData;->postValue(Ljava/lang/Object;)V
 return-void
.end method
