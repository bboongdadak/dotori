.class public Landroidx/lifecycle/MutableLiveData;
.super Landroidx/lifecycle/LiveData;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Landroidx/lifecycle/LiveData;-><init>()V
 return-void
.end method
