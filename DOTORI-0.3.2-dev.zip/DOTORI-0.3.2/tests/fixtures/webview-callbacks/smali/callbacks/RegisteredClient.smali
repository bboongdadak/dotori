.class public Lcallbacks/RegisteredClient;
.super Landroid/webkit/WebViewClient;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Landroid/webkit/WebViewClient;-><init>()V
 return-void
.end method
.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
 .locals 2
 invoke-virtual {p1,p2},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 const/4 v1,0x1
 return v1
.end method
