.class public Lcallbacks/WrongInstanceClient;
.super Landroid/webkit/WebViewClient;
.field private web:Landroid/webkit/WebView;
.method public constructor <init>(Landroid/webkit/WebView;)V
 .registers 2
 invoke-direct {p0},Landroid/webkit/WebViewClient;-><init>()V
 iput-object p1,p0,Lcallbacks/WrongInstanceClient;->web:Landroid/webkit/WebView;
 return-void
.end method
.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
 .locals 2
 iget-object v0,p0,Lcallbacks/WrongInstanceClient;->web:Landroid/webkit/WebView;
 invoke-virtual {v0,p2},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 const/4 v1,0x1
 return v1
.end method
