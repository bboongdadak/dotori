.class public Lcallbacks/SymbolicWrongViewView;
.super Landroid/webkit/WebView;
.method public constructor <init>(Landroid/content/Context;)V
 .locals 5
 invoke-direct {p0,p1},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 move-object v0,p0
 new-instance v4,Landroid/webkit/WebView;
 invoke-direct {v4,p1},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1,Lcallbacks/SymbolicWrongViewClient;
 invoke-direct {v1},Lcallbacks/SymbolicWrongViewClient;-><init>()V
 invoke-virtual {v0,v1},Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V
 new-instance v2,Lcallbacks/Bridge;
 invoke-direct {v2},Lcallbacks/Bridge;-><init>()V
 const-string v3,"Native"
 invoke-virtual {v4,v2,v3},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 return-void
.end method
