.class public Lcallbacks/PageFinishedClient;
.super Landroid/webkit/WebViewClient;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Landroid/webkit/WebViewClient;-><init>()V
 return-void
.end method
.method public onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
 .locals 2
 invoke-virtual {p1,p2},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
