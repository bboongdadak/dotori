.class public Lcallbacks/WrongInstance;
.super Landroid/app/Activity;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Landroid/app/Activity;-><init>()V
 return-void
.end method
.method public onCreate(Landroid/os/Bundle;)V
 .locals 6
 new-instance v0,Landroid/webkit/WebView;
 invoke-direct {v0,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v4,Landroid/webkit/WebView;
 invoke-direct {v4,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1,Lcallbacks/WrongInstanceClient;
 invoke-direct {v1,v0},Lcallbacks/WrongInstanceClient;-><init>(Landroid/webkit/WebView;)V
 new-instance v5,Lcallbacks/WrongInstanceClient;
 invoke-direct {v5,v4},Lcallbacks/WrongInstanceClient;-><init>(Landroid/webkit/WebView;)V
 invoke-virtual {v0,v5},Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V
 new-instance v2,Lcallbacks/Bridge;
 invoke-direct {v2},Lcallbacks/Bridge;-><init>()V
 const-string v3,"Native"
 invoke-virtual {v0,v2,v3},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 :done
 return-void
.end method
