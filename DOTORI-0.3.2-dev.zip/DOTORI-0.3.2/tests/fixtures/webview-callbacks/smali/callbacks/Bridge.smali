.class public Lcallbacks/Bridge;
.super Ljava/lang/Object;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 return-void
.end method
.method public call(Ljava/lang/String;)V
 .registers 2
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 return-void
.end method
