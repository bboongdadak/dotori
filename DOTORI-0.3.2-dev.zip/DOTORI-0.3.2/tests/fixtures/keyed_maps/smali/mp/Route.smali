.class public Lmp/Route;
.super Ljava/lang/Object;
.field public destination:Ljava/lang/Class;
.method public constructor <init>(Ljava/lang/Class;)V
 .registers 2
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 iput-object p1,p0,Lmp/Route;->destination:Ljava/lang/Class;
 return-void
.end method
