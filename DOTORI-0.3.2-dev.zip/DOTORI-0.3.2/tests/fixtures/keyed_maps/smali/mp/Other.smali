.class public Lmp/Other;
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 4
 new-instance v0,Landroid/webkit/WebView;
 invoke-direct {v0,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1,Lmp/Bridge;
 invoke-direct {v1},Lmp/Bridge;-><init>()V
 const-string v2,"Native"
 invoke-virtual {v0,v1,v2},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 invoke-virtual {p0},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v1
 const-string v2,"url"
 invoke-virtual {v1,v2},Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
 move-result-object v3
 invoke-virtual {v0,v3},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
