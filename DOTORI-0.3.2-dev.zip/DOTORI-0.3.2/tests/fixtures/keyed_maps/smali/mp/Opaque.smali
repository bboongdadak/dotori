.class public Lmp/Opaque;
.super Ljava/lang/Object;
.method public static modify(Ljava/util/Map;)V
 .registers 1
 return-void
.end method
