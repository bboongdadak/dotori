.class public Lmp/Escaped;
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 7
 new-instance v0,Ljava/util/HashMap;
 invoke-direct {v0},Ljava/util/HashMap;-><init>()V
 new-instance v1,Ljava/util/HashMap;
 invoke-direct {v1},Ljava/util/HashMap;-><init>()V
 new-instance v2,Lmp/Route;
 const-class v3,Lmp/Target;
 invoke-direct {v2,v3},Lmp/Route;-><init>(Ljava/lang/Class;)V
 const-string v3,"/screen"
 invoke-interface {v0,v3,v2},Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
 invoke-static {v0},Lmp/Opaque;->modify(Ljava/util/Map;)V
 invoke-interface {v0,v3},Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
 move-result-object v2
 check-cast v2,Lmp/Route;
 iget-object v3,v2,Lmp/Route;->destination:Ljava/lang/Class;
 invoke-virtual {p0},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v4
 invoke-virtual {v4},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v4
 new-instance v5,Landroid/content/Intent;
 invoke-direct {v5,p0,v3},Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
 const-string v6,"url"
 invoke-virtual {v5,v6,v4},Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
 invoke-virtual {p0,v5},Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
 return-void
.end method
