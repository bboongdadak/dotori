.class public Llab/LayoutChange;
.super Landroid/app/Activity;
.field private web:Landroid/webkit/WebView;
.field private text:Ljava/lang/String;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0}, Landroid/app/Activity;-><init>()V
 return-void
.end method
.method protected onCreate(Landroid/os/Bundle;)V
 .registers 12

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;
    move-result-object v0
    const-string v1, "url"
    invoke-virtual {v0,v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
 const/16 v8,0x1234
 invoke-virtual {p0,v8},Landroid/app/Activity;->setContentView(I)V
 invoke-virtual {p0,v8},Landroid/app/Activity;->findViewById(I)Landroid/view/View;
 move-result-object v3
 check-cast v3,Landroid/webkit/WebView;

    new-instance v6, Llab/Bridge;
    invoke-direct {v6}, Llab/Bridge;-><init>()V
    const-string v7, "Native"
    invoke-virtual {v3,v6,v7}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 const/16 v9,0x5678
 invoke-virtual {p0,v9},Landroid/app/Activity;->setContentView(I)V
 invoke-virtual {p0,v8},Landroid/app/Activity;->findViewById(I)Landroid/view/View;
 move-result-object v3
 check-cast v3,Landroid/webkit/WebView;
    invoke-virtual {v3,v2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    return-void
.end method
