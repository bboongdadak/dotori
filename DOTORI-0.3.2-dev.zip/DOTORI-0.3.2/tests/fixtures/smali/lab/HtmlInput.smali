.class public Llab/HtmlInput;
.super Landroid/app/Activity;
.field private web:Landroid/webkit/WebView;
.field private text:Ljava/lang/String;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0}, Landroid/app/Activity;-><init>()V
 return-void
.end method
.method protected onCreate(Landroid/os/Bundle;)V
 .registers 12

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;
    move-result-object v0
    const-string v1, "url"
    invoke-virtual {v0,v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    new-instance v3, Landroid/webkit/WebView;
    invoke-direct {v3,p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v4
    const/4 v5, 0x1
    invoke-virtual {v4,v5}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    new-instance v6, Llab/Bridge;
    invoke-direct {v6}, Llab/Bridge;-><init>()V
    const-string v7, "Native"
    invoke-virtual {v3,v6,v7}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 move-object v4,v2
 const-string v5,"text/html"
 const-string v6,"UTF-8"
 const/4 v7,0x0
 move-object v2,v3
 const-string v3,"https://example.invalid/"
 invoke-virtual/range {v2 .. v7},Landroid/webkit/WebView;->loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    return-void
.end method
