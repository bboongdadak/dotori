.class public Llab/LoadData;
.super Landroid/app/Activity;
.field private web:Landroid/webkit/WebView;
.field private text:Ljava/lang/String;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0}, Landroid/app/Activity;-><init>()V
 return-void
.end method
.method protected onCreate(Landroid/os/Bundle;)V
 .registers 12

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;
    move-result-object v0
    const-string v1, "url"
    invoke-virtual {v0,v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    new-instance v3, Landroid/webkit/WebView;
    invoke-direct {v3,p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v4
    const/4 v5, 0x1
    invoke-virtual {v4,v5}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    new-instance v6, Llab/Bridge;
    invoke-direct {v6}, Llab/Bridge;-><init>()V
    const-string v7, "Native"
    invoke-virtual {v3,v6,v7}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 const-string v4,"text/html"
 const-string v5,"UTF-8"
 invoke-virtual {v3,v2,v4,v5},Landroid/webkit/WebView;->loadData(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    return-void
.end method
