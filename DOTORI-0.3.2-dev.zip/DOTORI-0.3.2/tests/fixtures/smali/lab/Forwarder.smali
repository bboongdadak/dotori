.class public Llab/Forwarder;
.super Landroid/app/Activity;
.field private web:Landroid/webkit/WebView;
.field private text:Ljava/lang/String;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0}, Landroid/app/Activity;-><init>()V
 return-void
.end method
.method protected onCreate(Landroid/os/Bundle;)V
 .registers 12

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;
    move-result-object v0
    const-string v1, "url"
    invoke-virtual {v0,v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
 new-instance v0,Landroid/content/Intent;
 const-class v8,Llab/Internal;
 invoke-direct {v0,p0,v8},Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
 const-string v1,"url"
 invoke-virtual {v0,v1,v2},Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
 invoke-virtual {p0,v0},Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    return-void
.end method
