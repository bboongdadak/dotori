.class public Llab/AContextNoise11;
.super Llab/ContextBaseActivity;
.field private web:Landroid/webkit/WebView;
.field private text:Ljava/lang/String;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0}, Llab/ContextBaseActivity;-><init>()V
 return-void
.end method
.method protected onCreate(Landroid/os/Bundle;)V
 .registers 12
    return-void
.end method
.method public pick()Ljava/lang/String;
 .registers 4
 const-string v2,"fixed"
 return-object v2
.end method
