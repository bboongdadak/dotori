.class public Llab/Receiver;
.super Landroid/content/BroadcastReceiver;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Landroid/content/BroadcastReceiver;-><init>()V
 return-void
.end method
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
 .registers 14
 const-string v1,"url"
 invoke-virtual {p2,v1},Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
 move-result-object v2
 new-instance v3,Landroid/webkit/WebView;
 invoke-direct {v3,p1},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    new-instance v6, Llab/Bridge;
    invoke-direct {v6}, Llab/Bridge;-><init>()V
    const-string v7, "Native"
    invoke-virtual {v3,v6,v7}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
    invoke-virtual {v3,v2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    return-void
.end method
