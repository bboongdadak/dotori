.class public Llab/ChildBridge;
.super Llab/Bridge;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Llab/Bridge;-><init>()V
 return-void
.end method
