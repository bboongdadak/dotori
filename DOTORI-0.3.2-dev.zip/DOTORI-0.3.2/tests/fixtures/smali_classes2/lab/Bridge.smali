.class public Llab/Bridge;
.super Ljava/lang/Object;

.method public constructor <init>()V
    .registers 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public ping(Ljava/lang/String;)Ljava/lang/String;
    .registers 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation
    return-object p1
.end method

.method public hidden()V
    .registers 1
    return-void
.end method

.method private privateAnnotated()V
    .registers 1
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation
    return-void
.end method
