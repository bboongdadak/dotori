.class public Llab/BasePicker;
.super Ljava/lang/Object;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 return-void
.end method
.method public pick(Ljava/lang/String;)Ljava/lang/String;
 .registers 3
 const-string v0,"fixed"
 return-object v0
.end method
