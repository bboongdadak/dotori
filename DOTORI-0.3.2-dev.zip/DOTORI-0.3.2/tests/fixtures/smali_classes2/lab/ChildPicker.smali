.class public Llab/ChildPicker;
.super Llab/BasePicker;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Llab/BasePicker;-><init>()V
 return-void
.end method
.method public pick(Ljava/lang/String;)Ljava/lang/String;
 .registers 2
 return-object p1
.end method
