.class public Llab/Lookalike;
.super Ljava/lang/Object;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 return-void
.end method
.method public addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 .registers 3
 return-void
.end method
.method public loadUrl(Ljava/lang/String;)V
 .registers 2
 return-void
.end method
