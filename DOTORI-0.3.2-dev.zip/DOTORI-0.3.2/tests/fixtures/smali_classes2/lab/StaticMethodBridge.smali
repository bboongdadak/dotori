.class public Llab/StaticMethodBridge;
.super Ljava/lang/Object;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 return-void
.end method
.method public static ping()V
 .registers 0
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 return-void
.end method
