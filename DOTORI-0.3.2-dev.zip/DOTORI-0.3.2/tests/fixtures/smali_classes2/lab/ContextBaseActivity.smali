.class public abstract Llab/ContextBaseActivity;
.super Landroid/app/Activity;
.field private stored:Ljava/lang/String;
.method public abstract pick()Ljava/lang/String;
.end method
.method public setup()V
 .registers 2
 invoke-virtual {p0},Llab/ContextBaseActivity;->pick()Ljava/lang/String;
 move-result-object v0
 invoke-virtual {p0,v0},Llab/ContextBaseActivity;->setStored(Ljava/lang/String;)V
 return-void
.end method
.method public setStored(Ljava/lang/String;)V
 .registers 2
 iput-object p1,p0,Llab/ContextBaseActivity;->stored:Ljava/lang/String;
 return-void
.end method
.method public stored()Ljava/lang/String;
 .registers 2
 iget-object v0,p0,Llab/ContextBaseActivity;->stored:Ljava/lang/String;
 return-object v0
.end method
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Landroid/app/Activity;-><init>()V
 return-void
.end method
