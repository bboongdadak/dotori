.class public Llab/Singleton;
.super Ljava/lang/Object;
.field public static instance:Llab/Bridge;
.method static constructor <clinit>()V
 .registers 1
 new-instance v0,Llab/Bridge;
 invoke-direct {v0},Llab/Bridge;-><init>()V
 sput-object v0,Llab/Singleton;->instance:Llab/Bridge;
 return-void
.end method
