.class public Lcollections/Bridge;
.super Ljava/lang/Object;
.method public call()V
 .registers 1
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 return-void
.end method
