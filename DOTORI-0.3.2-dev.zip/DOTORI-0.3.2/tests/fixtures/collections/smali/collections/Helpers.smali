.class public Lcollections/Helpers;
.super Ljava/lang/Object;
.method public static add(Ljava/util/List;Ljava/lang/Object;)V
 .registers 2
 invoke-interface {p0,p1},Ljava/util/List;->add(Ljava/lang/Object;)Z
 return-void
.end method
.method public static first(Ljava/util/List;)Ljava/lang/Object;
 .locals 1
 const/4 v0,0x0
 invoke-interface {p0,v0},Ljava/util/List;->get(I)Ljava/lang/Object;
 move-result-object v0
 return-object v0
.end method
