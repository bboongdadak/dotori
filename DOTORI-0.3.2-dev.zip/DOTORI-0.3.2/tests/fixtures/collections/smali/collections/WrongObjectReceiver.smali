.class public Lcollections/WrongObjectReceiver;
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 9
 invoke-virtual {p0},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v1
 invoke-virtual {v1},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v1
 const-string v2,"https://fixed.invalid/"
 new-instance v3,Landroid/webkit/WebView;
 invoke-direct {v3,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v4,Lcollections/Bridge;
 invoke-direct {v4},Ljava/lang/Object;-><init>()V
 const-string v5,"Native"
 invoke-virtual {v3,v4,v5},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 new-instance v0,Ljava/util/ArrayList;
 invoke-direct {v0},Ljava/util/ArrayList;-><init>()V
 invoke-virtual {v0,v3},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
 new-instance v2,Landroid/webkit/WebView;
 invoke-direct {v2,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 invoke-virtual {v0,v2},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
 const/4 v5,0x0
 const/4 v5,0x1
 invoke-interface {v0,v5},Ljava/util/List;->get(I)Ljava/lang/Object;
 move-result-object v6
 check-cast v6,Landroid/webkit/WebView;
 invoke-virtual {v6,v1},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
