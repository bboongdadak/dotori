.class public Lfr/Overwritten;
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 9
 new-instance v0,Landroid/webkit/WebView;
 invoke-direct {v0,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1,Lfr/Bridge;
 invoke-direct {v1},Lfr/Bridge;-><init>()V
 const-string v2,"Native"
 invoke-virtual {v0,v1,v2},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 new-instance v3,Lfr/Arguments;
 invoke-direct {v3},Lfr/Arguments;-><init>()V
 new-instance v4,Lfr/Arguments;
 invoke-direct {v4},Lfr/Arguments;-><init>()V
 new-instance v5,Landroid/os/Bundle;
 invoke-direct {v5},Landroid/os/Bundle;-><init>()V
 new-instance v8,Landroid/os/Bundle;
 invoke-direct {v8},Landroid/os/Bundle;-><init>()V
 invoke-virtual {p0},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v6
 invoke-virtual {v6},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v6
 const-string v7,"url"
 invoke-virtual {v5,v7,v6},Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
 const-string v6,"https://trusted.invalid"
 invoke-virtual {v5,v7,v6},Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
 invoke-virtual {v3,v5},Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V
 invoke-virtual {v3},Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;
 move-result-object v8
 invoke-virtual {v8,v7},Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
 move-result-object v6
 invoke-virtual {v0,v6},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
