.class public Lfr/Arguments;
.super Landroidx/fragment/app/Fragment;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Landroidx/fragment/app/Fragment;-><init>()V
 return-void
.end method
