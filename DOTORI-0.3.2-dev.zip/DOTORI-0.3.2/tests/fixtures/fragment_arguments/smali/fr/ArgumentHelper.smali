.class public Lfr/ArgumentHelper;
.super Ljava/lang/Object;
.method public static set(Landroidx/fragment/app/Fragment;Landroid/os/Bundle;)V
 .registers 2
 invoke-virtual {p0,p1},Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V
 return-void
.end method
