.class public Lformatcases/CopyBeforeSource;
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 9
 invoke-virtual {p0},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v1
 invoke-virtual {v1},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v1
 const-string v2,"https://fixed.invalid/"
 new-instance v3,Landroid/webkit/WebView;
 invoke-direct {v3,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v4,Lformatcases/Bridge;
 invoke-direct {v4},Lformatcases/Bridge;-><init>()V
 const-string v5,"Native"
 invoke-virtual {v3,v4,v5},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 const/4 v4,0x2
 new-array v0,v4,[Ljava/lang/Object;
 const/4 v5,0x0
 const/4 v7,0x1
 aput-object v2,v0,v5
 aput-object v2,v0,v7
 invoke-static {v0,v4},Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
 move-result-object v8
 aput-object v1,v0,v5
 const-string v5,"%s"
 invoke-static {v5,v8},Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
 move-result-object v6
 invoke-virtual {v3,v6},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
