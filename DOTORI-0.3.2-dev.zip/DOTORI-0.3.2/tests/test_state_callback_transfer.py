from dataclasses import replace
from dotori import state_summaries as state
from dotori.demand import Origin
from dotori.model import Method, Instruction as I
from test_state_summaries import analysis_for, MUTABLE, STATE, OBJECT, SET, GET, WEBVIEW


def transfer(other_state=False,conflict=False):
    writer=Method('Ltransfer/Factory;->write()V','public static',2,0,
        [I(0,'invoke-interface',(0,1),SET),I(2,'return-void')])
    reader=Method('Ltransfer/Effect;->read()'+OBJECT,'public static',2,0,
        [I(0,'invoke-interface',(0,),GET),I(2,'move-result-object',(1,)),I(4,'return-object',(1,))])
    a=analysis_for(writer,reader)
    root=Origin('allocation','state',MUTABLE,path=('allocation:compose_state_factory',),
                callback_instances=frozenset({'reader'}),guards=frozenset({('frame',1,2)}) if conflict else frozenset())
    target=replace(root,key='other-state' if other_state else root.key,callback_instances=frozenset({'writer'}),
                   guards=frozenset({('frame',1,4)}) if conflict else frozenset())
    value=Origin('allocation','webview',WEBVIEW,callback_instances=frozenset({'writer'}))
    def trace(ref,reg,before,mode,ctx=0,depth=0):
        if ref==reader.ref:return (root,)
        return (target,) if reg==0 else (value,)
    a.trace=trace
    return state.result(a,reader,reader.instructions[0],'object',0,0)


def test_same_state_transfers_between_distinct_callback_instances():
    values=transfer()
    assert len(values)==1 and values[0].key=='webview'
    assert values[0].callback_instances==frozenset({'reader','writer'})
    assert 'state_read_after_write_assumed' in values[0].path


def test_other_state_or_conflicting_conditions_do_not_transfer():
    assert not transfer(other_state=True)
    assert not transfer(conflict=True)


def test_proven_value_survives_budget_spent_on_unrelated_writer():
    writer=Method('Ltest/Factory;->write()V','public static',2,0,
        [I(0,'invoke-interface',(0,1),SET),I(2,'return-void')])
    unrelated=Method('Lzzz/Other;->write()V','public static',2,0,
        [I(0,'invoke-interface',(0,1),SET),I(2,'return-void')])
    reader=Method('Ltest/Effect;->read()'+OBJECT,'public static',2,0,
        [I(0,'invoke-interface',(0,),GET),I(2,'move-result-object',(1,)),I(4,'return-object',(1,))])
    a=analysis_for(writer,unrelated,reader)
    root=Origin('allocation','state',MUTABLE,path=('allocation:compose_state_factory',))
    value=Origin('allocation','webview',WEBVIEW)
    def trace(ref,reg,before,mode,ctx=0,depth=0):
        if ref==reader.ref:return (root,)
        if ref==unrelated.ref:
            a.sink_queries=a.per_sink_limit
            return ()
        if not a.allowed(depth):return ()
        return (root,) if reg==0 else (value,)
    a.trace=trace
    values=state.result(a,reader,reader.instructions[0],'object',0,0)
    assert len(values)==1 and values[0].key=='webview'
    assert a.sink_queries==a.per_sink_limit
