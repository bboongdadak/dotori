"""Report comparisons must retain changed constraints on stable witness IDs."""
import json
from pathlib import Path
import subprocess
import sys


def test_stable_witness_id_with_changed_guards_is_not_silently_unchanged(tmp_path):
    old = tmp_path / 'old'; new = tmp_path / 'new'
    old.mkdir(); new.mkdir()
    base = {'input': {'sha256': 'same', 'package': 'fixture'}, 'status': 'completed_with_gaps',
            'coverage_status': 'partial', 'candidates': [], 'bridge_javascript_paths': [],
            'input_webview_paths': [{'id': 'stable', 'source': {'branch_choices': []}}], 'diagnostics': []}
    (old / '01.json').write_text(json.dumps(base))
    base['input_webview_paths'][0]['source']['branch_choices'] = [['fixture', 2, 4]]
    (new / '01.json').write_text(json.dumps(base))
    output = tmp_path / 'comparison.json'
    tool = Path(__file__).resolve().parents[1] / 'tools' / 'compare_corpus.py'
    subprocess.run([sys.executable, str(tool), str(old), str(new), str(output)], check=True)
    group = json.loads(output.read_text())['cases'][0]['evidence_groups']['input_webview_paths']
    assert group['retained_ids'] == ['stable']
    assert group['changed_retained_ids'] == ['stable']
    assert not group['added_ids'] and not group['removed_ids']


def test_different_analysis_selections_cannot_be_compared_as_same_run(tmp_path):
    old=tmp_path/'old';new=tmp_path/'new';old.mkdir();new.mkdir()
    r={'input':{'sha256':'same'},'analysis_selection':{'focus_methods':[]}}
    (old/'01.json').write_text(json.dumps(r));r['analysis_selection']['focus_methods']=['Reduced']
    (new/'01.json').write_text(json.dumps(r))
    tool=Path(__file__).resolve().parents[1]/'tools/compare_corpus.py'
    p=subprocess.run([sys.executable,str(tool),str(old),str(new),str(tmp_path/'out.json')],capture_output=True,text=True)
    assert p.returncode!=0 and 'Different analysis selection' in p.stderr
