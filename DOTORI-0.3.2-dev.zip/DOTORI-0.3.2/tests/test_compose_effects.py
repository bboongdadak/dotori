from dotori.demand import Backward, INTENT
from dotori.model import Method, Instruction as I
from dotori.compose_effects import OBJECT, CONT, FUNCTION, INVOKE, CREATE, SUSPEND, COMPOSER
from test_webview_callbacks import catalog_program, ACTIVITY


def effect_fixture(register=True,wrong_api=False,bad_create=False):
    owner='Leffectfixture/Block;';field=owner+'->captured'+INTENT
    ctor=Method(owner+'-><init>('+INTENT+CONT+')V','public constructor',3,3,
        [I(0,'iput-object',(1,0),field),I(2,'return-void')])
    create=Method(owner+'->create'+CREATE,'public',5,3,
        ([I(0,'const/4',(0,),literal=0),I(2,'return-object',(0,))] if bad_create else [
        I(0,'new-instance',(0,),literal=owner),I(2,'iget-object',(1,2),field),
        I(4,'invoke-direct',(0,1,4),ctor.ref),I(6,'return-object',(0,))]))
    resume=Method(owner+'->invokeSuspend'+SUSPEND,'public',3,2,[I(0,'iget-object',(0,1),field),
        I(2,'invoke-virtual',(0,),INTENT+'->getDataString()Ljava/lang/String;'),I(4,'move-result-object',(0,)),I(6,'return-object',(0,))])
    invoke=Method(owner+'->invoke'+INVOKE,'public',4,3,[I(0,'invoke-virtual',(1,2,3),create.ref),
        I(2,'move-result-object',(0,)),I(4,'check-cast',(0,),literal=owner),
        I(6,'invoke-virtual',(0,2),resume.ref),I(8,'move-result-object',(0,)),I(10,'return-object',(0,))])
    bridge=Method(owner+'->invoke('+OBJECT+OBJECT+')'+OBJECT,'public bridge synthetic',3,3,
        [I(0,'invoke-virtual',(0,1,2),invoke.ref),I(2,'move-result-object',(0,)),I(4,'return-object',(0,))])
    api=('Lwrong/Effects;' if wrong_api else 'Landroidx/compose/runtime/EffectsKt;')+'->LaunchedEffect('+OBJECT+FUNCTION+COMPOSER+'I)V'
    rows=[I(0,'invoke-virtual',(3,),ACTIVITY+'->getIntent()'+INTENT),I(2,'move-result-object',(1,)),
          I(4,'new-instance',(0,),literal=owner),I(6,'const/4',(2,),literal=0),I(8,'invoke-direct',(0,1,2),ctor.ref)]
    if register:rows.append(I(10,'invoke-static',(2,0,2,2),api))
    rows.append(I(12,'return-void'))
    entry=Method(ACTIVITY+'->onCreate(Landroid/os/Bundle;)V','public',5,2,rows)
    p=catalog_program([ctor,create,resume,invoke,bridge,entry])
    p.catalog.interfaces[owner]=(FUNCTION,)
    return Backward(p),resume


def test_registered_effect_follows_actual_create_copy_and_captured_input():
    a,m=effect_fixture();values=a.trace(m.ref,0,6,'value')
    assert any(v.kind=='external_value' for v in values)
    assert all(not any('constructed_callback_dispatch_unproven' in s for s in v.path) for v in values)
    receivers=a.trace(m.ref,1,0,'object')
    assert receivers and all(any('coroutine_created_then_invoked:' in s for s in v.path) for v in receivers)
    assert all(any('callback_registered:LaunchedEffect:' in s for s in v.path) for v in receivers)
    assert all('->create' in v.key for v in receivers)


def test_unregistered_or_lookalike_effect_does_not_claim_execution():
    for options in ({'register':False},{'wrong_api':True},{'bad_create':True}):
        a,m=effect_fixture(**options);values=a.trace(m.ref,1,0,'object')
        assert not any('coroutine_created_then_invoked:' in s for v in values for s in v.path)


def test_two_effect_registrations_have_distinct_continuation_contexts():
    a,m=effect_fixture();entry=next(x for x in a.p.methods.values() if x.owner==ACTIVITY)
    call=entry.instructions[-2]
    from dotori.index import Site
    entry.instructions.insert(-1,I(11,'invoke-static',call.regs,call.ref))
    original=a.c.callers_of
    a.c.callers_of=lambda ref:original(ref)+([Site(entry.ref,11,call.ref,'invoke-static')] if ref==call.ref else [])
    values=a.trace(m.ref,1,0,'object')
    assert len({v.key for v in values})==2
