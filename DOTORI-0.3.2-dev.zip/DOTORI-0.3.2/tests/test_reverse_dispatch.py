"""Reverse virtual edges require receiver/implementation compatibility."""
from dotori.model import Instruction as I, Method
from test_context_identity import analysis_for

BASE='Ldispatch/Base;'
LEFT='Ldispatch/Left;'
RIGHT='Ldispatch/Right;'
DESC='(Ljava/lang/String;)V'


def override(owner):
    return Method(owner+'->accept'+DESC,'public',2,2,[I(0,'return-void')])


def test_reverse_virtual_dispatch_rejects_sibling_allocation():
    left=override(LEFT);right=override(RIGHT)
    caller=Method('Ldispatch/Entry;->use()V','public static',2,0,[
        I(0,'new-instance',(0,),literal=LEFT),I(2,'const-string',(1,),literal='payload'),
        I(4,'invoke-virtual',(0,1),ref=BASE+'->accept'+DESC),I(6,'return-void')])
    analysis=analysis_for(left,right,caller)
    analysis.p.supers.update({LEFT:BASE,RIGHT:BASE})
    assert {a.value for a in analysis.trace(left.ref,1,0)}=={'payload'}
    assert analysis.trace(right.ref,1,0)==()


def test_reverse_virtual_dispatch_resolves_field_receiver_allocation():
    left=override(LEFT);right=override(RIGHT)
    field='Ldispatch/Holder;->view'+BASE
    writer=Method('Ldispatch/Holder;->init()V','public static',1,0,[
        I(0,'new-instance',(0,),literal=LEFT),I(2,'sput-object',(0,),ref=field),I(4,'return-void')])
    caller=Method('Ldispatch/Entry;->use()V','public static',2,0,[
        I(0,'sget-object',(0,),ref=field),I(2,'const-string',(1,),literal='payload'),
        I(4,'invoke-virtual',(0,1),ref=BASE+'->accept'+DESC),I(6,'return-void')])
    analysis=analysis_for(left,right,writer,caller)
    analysis.p.supers.update({LEFT:BASE,RIGHT:BASE})
    assert {a.value for a in analysis.trace(left.ref,1,0)}=={'payload'}
    assert analysis.trace(right.ref,1,0)==()


def test_super_call_does_not_dispatch_to_child_override():
    base=override(BASE);left=override(LEFT)
    caller=Method(RIGHT+'->use()V','public',2,1,[
        I(0,'const-string',(0,),literal='payload'),
        I(2,'invoke-super',(1,0),ref=base.ref),I(4,'return-void')])
    analysis=analysis_for(base,left,caller)
    analysis.p.supers.update({LEFT:BASE,RIGHT:BASE})
    assert {a.value for a in analysis.trace(base.ref,1,0)}=={'payload'}
    assert analysis.trace(left.ref,1,0)==()


def test_exact_declared_base_call_respects_concrete_override():
    base=override(BASE);left=override(LEFT)
    caller=Method('Ldispatch/Entry;->use()V','public static',2,0,[
        I(0,'new-instance',(0,),literal=LEFT),I(2,'const-string',(1,),literal='payload'),
        I(4,'invoke-virtual',(0,1),ref=base.ref),I(6,'return-void')])
    analysis=analysis_for(base,left,caller);analysis.p.supers[LEFT]=BASE
    assert analysis.trace(base.ref,1,0)==()
    assert {a.value for a in analysis.trace(left.ref,1,0)}=={'payload'}


def test_cast_does_not_replace_concrete_receiver_type():
    left=override(LEFT);right=override(RIGHT)
    caller=Method('Ldispatch/Entry;->use()V','public static',2,0,[
        I(0,'new-instance',(0,),literal=LEFT),I(2,'check-cast',(0,),literal=BASE),
        I(4,'const-string',(1,),literal='payload'),I(6,'invoke-virtual',(0,1),ref=BASE+'->accept'+DESC),I(8,'return-void')])
    analysis=analysis_for(left,right,caller);analysis.p.supers.update({LEFT:BASE,RIGHT:BASE})
    assert {a.value for a in analysis.trace(left.ref,1,0)}=={'payload'}
    assert analysis.trace(right.ref,1,0)==()


def test_unknown_receiver_does_not_prove_an_approximate_override_edge():
    left=override(LEFT)
    caller=Method('Ldispatch/Entry;->use('+BASE+'Ljava/lang/String;)V','public static',2,2,[
        I(0,'invoke-virtual',(0,1),ref=BASE+'->accept'+DESC),I(2,'return-void')])
    analysis=analysis_for(left,caller);analysis.p.supers[LEFT]=BASE
    assert analysis.trace(left.ref,1,0)==()
    assert any(code=='virtual_receiver_unresolved' for code,_ in analysis.seed_notes)


def runnable_analysis(with_run=True,with_queue=False):
    callback=Method('Ldispatch/Task;->run()V','public',1,1,[I(0,'return-void')])
    scheduler=Method('Ldispatch/Scheduler;->submit(Ljava/lang/Runnable;)V','public static',3,1,[
        I(0,'sget-boolean',(0,),ref='Ldispatch/Scheduler;->readyZ'),
        I(2,'if-eqz',(0,),target=8),
        I(4,'invoke-interface',(2,),ref='Ljava/lang/Runnable;->run()V') if with_run else I(4,'nop'),
        I(6,'goto',target=12),
        I(8,'sget-object',(1,),ref='Ldispatch/Scheduler;->queueLjava/util/List;'),
        I(10,'invoke-interface',(1,2),ref='Ljava/util/List;->add(Ljava/lang/Object;)Z') if with_queue else I(10,'nop'),
        I(12,'return-void')])
    constructor=Method(callback.owner+'-><init>()V','public constructor',1,1,[I(0,'return-void')])
    caller=Method('Ldispatch/Entry;->use()V','public static',1,0,[
        I(0,'new-instance',(0,),literal=callback.owner),I(2,'invoke-direct',(0,),ref=constructor.ref),
        I(4,'invoke-static',(0,),ref=scheduler.ref),I(6,'return-void')])
    analysis=analysis_for(callback,constructor,scheduler,caller)
    analysis.p.catalog.interfaces[callback.owner]=('Ljava/lang/Runnable;',)
    return analysis,callback,scheduler,caller


def test_direct_interface_runnable_call_preserves_instance_and_branch():
    analysis,callback,scheduler,caller=runnable_analysis(with_run=True,with_queue=True)
    objects=analysis.trace(callback.ref,0,0,'object')
    assert len(objects)==1
    assert objects[0].key==analysis.site(caller.ref,0)
    assert objects[0].callback_instances==frozenset((objects[0].key,))
    assert any(owner.split(':call_context:',1)[0]==scheduler.ref and (branch,target)==(2,4) for owner,branch,target in objects[0].guards)
    assert any(x.startswith('callback_invoked:') for x in objects[0].path)


def test_enqueuing_runnable_does_not_invent_execution():
    analysis,callback,_,_=runnable_analysis(with_run=False,with_queue=True)
    assert analysis.trace(callback.ref,0,0,'object')==()
    assert any(code=='callback_registration_unresolved' for code,_ in analysis.seed_notes)


def test_lazy_catalog_placeholder_is_checked_after_instruction_decode():
    from dataclasses import replace
    left=override(LEFT);right=override(RIGHT)
    caller=Method('Ldispatch/Entry;->use()V','public static',2,0,[
        I(0,'new-instance',(0,),literal=LEFT),I(2,'const-string',(1,),literal='payload'),
        I(4,'invoke-virtual',(0,1),ref=BASE+'->accept'+DESC),I(6,'return-void')])
    analysis=analysis_for(left,right,caller);analysis.p.supers.update({LEFT:BASE,RIGHT:BASE})
    originals=analysis.c.callers_of
    analysis.c.callers_of=lambda ref:[replace(site,opcode='direct_reference') for site in originals(ref)]
    assert {a.value for a in analysis.trace(left.ref,1,0)}=={'payload'}
    assert analysis.trace(right.ref,1,0)==()


def test_unknown_declared_receiver_keeps_only_conditional_dispatch_evidence():
    left=override(LEFT)
    caller=Method('Ldispatch/Entry;->use('+BASE+')V','public static',2,1,[
        I(0,'const-string',(0,),literal='payload'),
        I(2,'invoke-virtual',(1,0),ref=BASE+'->accept'+DESC),I(4,'return-void')])
    analysis=analysis_for(left,caller);analysis.p.supers[LEFT]=BASE
    values=analysis.trace(left.ref,1,0)
    assert {value.value for value in values}=={'payload'}
    assert all(any('dispatch_receiver_type_unproven' in step for step in value.path) for value in values)
    assert any(code=='dispatch_receiver_type_unproven' for code,_ in analysis.seed_notes)


def test_custom_runnable_search_ignores_unrelated_run_calls():
    analysis,callback,scheduler,caller=runnable_analysis(with_run=True)
    decoys=[Method(f'Ldispatch/Decoy{n};->invoke(Ljava/lang/Runnable;)V','public static',1,1,[
        I(0,'invoke-interface',(0,),ref='Ljava/lang/Runnable;->run()V'),I(2,'return-void')]) for n in range(100)]
    analysis=analysis_for(*analysis.p.methods.values(),*decoys)
    analysis.p.catalog.interfaces[callback.owner]=('Ljava/lang/Runnable;',)
    original=analysis.trace
    def trace(ref,*args,**kwargs):
        assert not ref.startswith('Ldispatch/Decoy')
        return original(ref,*args,**kwargs)
    analysis.trace=trace
    objects=analysis.trace(callback.ref,0,0,'object')
    assert len(objects)==1 and objects[0].key==analysis.site(caller.ref,0)


def test_registered_runnable_is_resolved_before_unrelated_generic_calls():
    callback=Method('Ldispatch/Posted;->run()V','public',1,1,[I(0,'return-void')])
    constructor=Method(callback.owner+'-><init>()V','public constructor',1,1,[I(0,'return-void')])
    caller=Method('Ldispatch/Entry;->post()V','public static',2,0,[
        I(0,'new-instance',(0,),literal=callback.owner),I(2,'invoke-direct',(0,),ref=constructor.ref),
        I(4,'new-instance',(1,),literal='Landroid/view/View;'),
        I(6,'invoke-virtual',(1,0),ref='Landroid/view/View;->post(Ljava/lang/Runnable;)Z'),I(8,'return-void')])
    decoys=[Method(f'Ldispatch/Decoy{n};->invoke(Ljava/lang/Runnable;)V','public static',1,1,[
        I(0,'invoke-interface',(0,),ref='Ljava/lang/Runnable;->run()V'),I(2,'return-void')]) for n in range(100)]
    analysis=analysis_for(callback,constructor,caller,*decoys);analysis.per_sink_limit=100
    analysis.p.catalog.interfaces[callback.owner]=('Ljava/lang/Runnable;',)
    original=analysis.trace
    def trace(ref,*args,**kwargs):
        assert not ref.startswith('Ldispatch/Decoy')
        return original(ref,*args,**kwargs)
    analysis.trace=trace
    objects=analysis.trace(callback.ref,0,0,'object')
    assert len(objects)==1
    assert any(step.startswith('callback_registered:') for step in objects[0].path)
