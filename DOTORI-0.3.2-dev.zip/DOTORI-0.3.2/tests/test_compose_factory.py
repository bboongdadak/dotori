from dotori.demand import Backward,WV
from dotori.model import Instruction as I,Method
from dotori.compose_callbacks import FUNCTION,CONTEXT
from test_webview_callbacks import catalog_program,ACTIVITY


def factory_program(register=True,wrong_api=False,unused_overload=False):
    owner='Lcomposefixture/Factory;'
    ctor=Method(owner+'-><init>()V','public constructor',1,1,[I(0,'return-void')])
    invoke=Method(owner+'->invoke('+CONTEXT+')'+WV,'public',3,2,[I(0,'new-instance',(0,),literal=WV),I(2,'return-object',(0,))])
    bridge=Method(owner+'->invoke(Ljava/lang/Object;)Ljava/lang/Object;','public bridge synthetic',3,2,
        [I(0,'check-cast',(2,),literal=CONTEXT),I(2,'invoke-virtual',(1,2),invoke.ref if not unused_overload else owner+'->other('+CONTEXT+')'+WV),I(4,'move-result-object',(0,)),I(6,'return-object',(0,))])
    api=('Lunrelated/Views;' if wrong_api else 'Landroidx/compose/ui/viewinterop/AndroidView_androidKt;')+'->AndroidView('+FUNCTION+'I)V'
    ins=[I(0,'new-instance',(0,),literal=owner),I(2,'invoke-direct',(0,),ctor.ref),I(4,'const/4',(1,),literal=0)]
    if register:ins.append(I(6,'invoke-static',(0,1),api))
    ins.append(I(8,'return-void'))
    entry=Method(ACTIVITY+'->onCreate(Landroid/os/Bundle;)V','public',4,2,ins)
    p=catalog_program([ctor,invoke,bridge,entry],supers={owner:'Ljava/lang/Object;'})
    p.catalog.interfaces[owner]=(FUNCTION,)
    return Backward(p),invoke


def test_actual_androidview_factory_has_registration_proof():
    a,m=factory_program();v=a.trace(m.ref,1,0,'object')
    assert v and all(any('callback_registered:AndroidView_factory:' in s for s in o.path) for o in v)
    assert all(o.callback_instances for o in v)


def test_unregistered_or_lookalike_calls_do_not_claim_registration():
    for kwargs in ({'register':False},{'wrong_api':True},{'unused_overload':True}):
        a,m=factory_program(**kwargs);v=a.trace(m.ref,1,0,'object')
        assert not any('callback_registered:AndroidView_factory:' in s for o in v for s in o.path)


def test_reused_factory_does_not_merge_two_androidview_registrations():
    a,m=factory_program()
    entry=next(x for x in a.p.methods.values() if x.owner==ACTIVITY)
    api=entry.instructions[-2]
    entry.instructions.insert(-1,I(7,'invoke-static',api.regs,api.ref))
    from dotori.index import Site
    original=a.c.callers_of
    a.c.callers_of=lambda ref: original(ref)+([Site(entry.ref,7,api.ref,'invoke-static')] if ref==api.ref else [])
    values=a.trace(m.ref,0,2,'object')
    assert len({v.key for v in values})==2
    assert len({tuple(sorted(v.callback_instances)) for v in values})==2


def test_androidview_overload_forwarding_is_one_registration():
    a,m=factory_program()
    entry=next(x for x in a.p.methods.values() if x.owner==ACTIVITY)
    api=entry.instructions[-2].ref
    nested=api.replace('I)V','II)V')
    wrapper=Method(api,'public static',2,2,[I(0,'invoke-static',(0,1,1),nested),I(2,'return-void')])
    a.p.methods[wrapper.ref]=wrapper
    from dotori.index import Site
    original=a.c.callers_of
    a.c.callers_of=lambda ref:original(ref)+([Site(wrapper.ref,0,nested,'invoke-static')] if ref==nested else [])
    from dotori.model import split_ref
    _,name,desc=split_ref(nested)
    a.c.call_signatures[name,desc].add(nested)
    values=a.trace(m.ref,0,2,'object')
    assert len({v.key for v in values})==1


def test_internal_androidview_restart_callback_is_not_a_second_registration():
    a,m=factory_program()
    entry=next(x for x in a.p.methods.values() if x.owner==ACTIVITY)
    api=entry.instructions[-2].ref
    restart=Method('Landroidx/compose/ui/viewinterop/AndroidView_androidKt$AndroidView$2;->invoke(Landroidx/compose/runtime/Composer;I)V',
                   'public',3,3,[I(0,'invoke-static',(0,1),api),I(2,'return-void')])
    a.p.methods[restart.ref]=restart
    from dotori.index import Site
    original=a.c.callers_of
    a.c.callers_of=lambda ref:original(ref)+([Site(restart.ref,0,api,'invoke-static')] if ref==api else [])
    trace=a.trace
    template=trace(entry.ref,0,6,'object')
    # The compiler restart wrapper forwards exactly the outer factory. It is
    # not an additional independent registration of that same template.
    a.trace=lambda ref,reg,before,mode,ctx=0,depth=0:template if ref==restart.ref else trace(ref,reg,before,mode,ctx,depth)
    values=a.trace(m.ref,0,2,'object')
    assert len({v.key for v in values})==1
