"""Rebuild with official apktool (2.11.1 used), never execute the fixture app.

Usage: python tests/protocol_fixture/rebuild.py /path/to/apktool
The shared fixture binary manifest is reused so binary XML packaging is
independent of local Android resource tools. Smali is independently assembled.
"""
import pathlib,subprocess,sys,zipfile
root=pathlib.Path(__file__).resolve().parent
subprocess.run([sys.argv[1],'b',str(root),'-o',str(root/'cases.apk')],check=True)
p=root/'cases.apk'
with zipfile.ZipFile(p) as z:data={i.filename:z.read(i.filename) for i in z.infolist()}
with zipfile.ZipFile(root.parent/'fixtures'/'cases.apk') as z:data['AndroidManifest.xml']=z.read('AndroidManifest.xml')
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for name,value in data.items():z.writestr(name,value)
