.class public Llab/Protocol;
.super Ljava/lang/Object;
.field private view:Landroid/webkit/WebView;
.method public constructor <init>(Landroid/webkit/WebView;)V
 .registers 2
 invoke-direct {p0}, Ljava/lang/Object;-><init>()V
 iput-object p1, p0, Llab/Protocol;->view:Landroid/webkit/WebView;
 return-void
.end method
.method public static setup(Landroid/content/Context;)V
 .registers 4
 new-instance v0, Landroid/webkit/WebView;
 invoke-direct {v0,p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1, Llab/Protocol;
 invoke-direct {v1,v0}, Llab/Protocol;-><init>(Landroid/webkit/WebView;)V
 const-string v2, "Bridge"
 invoke-virtual {v0,v1,v2}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 return-void
.end method
.method public execute(Ljava/lang/String;)V
 .registers 5
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 new-instance v0, Ljava/lang/StringBuilder;
 invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
 const-string v1, "javascript:callback("
 invoke-virtual {v0,v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
 invoke-virtual {v0,p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
 const-string v1, ")"
 invoke-virtual {v0,v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
 invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
 move-result-object v0
 iget-object v1, p0, Llab/Protocol;->view:Landroid/webkit/WebView;
 invoke-virtual {v1,v0}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
.method public suffixOnly(Ljava/lang/String;)V
 .registers 5
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 new-instance v0, Ljava/lang/StringBuilder;
 invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
 invoke-virtual {v0,p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
 const-string v1, "javascript:callback()"
 invoke-virtual {v0,v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
 invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
 move-result-object v0
 iget-object v1, p0, Llab/Protocol;->view:Landroid/webkit/WebView;
 invoke-virtual {v1,v0}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
.method public caughtScript(Ljava/lang/String;)V
 .registers 5
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 :start
 invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
 :end
 const-string p1, "fixed after normal completion"
 return-void
 :handler
 move-exception v0
 iget-object v1, p0, Llab/Protocol;->view:Landroid/webkit/WebView;
 const/4 v0, 0x0
 invoke-virtual {v1,p1,v0}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
 return-void
 .catch Ljava/lang/IllegalArgumentException; {:start .. :end} :handler
.end method
