from dotori.demand import Backward
from dotori.model import Method, Instruction as I
from dotori.view_lookup import VIEW, ACTIVITY, APPCOMPAT
from test_webview_callbacks import catalog_program, ACTIVITY as SCREEN


def lifecycle(after=True):
    helper=Method(SCREEN+'->setup()V','public',3,1,[I(0,'const/16',(0,),literal=7),
        I(2,'invoke-virtual',(2,0),ACTIVITY+'->findViewById(I)'+VIEW),I(4,'move-result-object',(1,)),I(6,'return-object',(1,))])
    rows=[I(0,'const/16',(0,),literal=123)]
    rows+=([I(2,'invoke-virtual',(1,0),ACTIVITY+'->setContentView(I)V'),I(4,'invoke-virtual',(1,),helper.ref)] if after else [I(2,'invoke-virtual',(1,),helper.ref),I(4,'invoke-virtual',(1,0),ACTIVITY+'->setContentView(I)V')])
    create=Method(SCREEN+'->onCreate(Landroid/os/Bundle;)V','public',3,2,rows+[I(6,'return-void')])
    a=Backward(catalog_program([helper,create]))
    return a,a.trace(helper.ref,1,6,'object')


def test_oncreate_content_precedes_same_component_helper_lookup():
    a,v=lifecycle()
    assert v and all(x.kind=='view_lookup' for x in v)
    assert all(any('activity_content_before_helper' in s for s in x.path) for x in v)


def test_lookup_before_content_does_not_reuse_later_layout():
    assert not lifecycle(False)[1]


def appcompat_case(bad=False):
    wrapper=Method(APPCOMPAT+'->findViewById(I)'+VIEW,'public',3,2,
        ([I(0,'const/4',(0,),literal=0),I(2,'return-object',(0,))] if bad else [
        I(0,'invoke-virtual',(1,),APPCOMPAT+'->getDelegate()Landroidx/appcompat/app/AppCompatDelegate;'),
        I(2,'move-result-object',(0,)),I(4,'invoke-virtual',(0,2),'Landroidx/appcompat/app/AppCompatDelegate;->findViewById(I)'+VIEW),
        I(6,'move-result-object',(0,)),I(8,'return-object',(0,))]))
    lookup=Method(SCREEN+'->find()V','public',3,1,[I(0,'const/16',(0,),literal=123),I(2,'invoke-virtual',(2,0),ACTIVITY+'->setContentView(I)V'),
        I(4,'const/16',(0,),literal=7),I(6,'invoke-virtual',(2,0),SCREEN+'->findViewById(I)'+VIEW),I(8,'move-result-object',(1,)),I(10,'return-object',(1,))])
    a=Backward(catalog_program([wrapper,lookup],supers={SCREEN:APPCOMPAT,APPCOMPAT:ACTIVITY}))
    return a.trace(lookup.ref,1,10,'object')


def test_standard_appcompat_delegate_wrapper_keeps_activity_content_root():
    assert all(v.kind=='view_lookup' for v in appcompat_case()) and appcompat_case()


def test_changed_appcompat_wrapper_uses_its_actual_return_body():
    values=appcompat_case(True)
    assert values and all(v.kind=='constant' and v.value=='0' for v in values)
