"""Binary APK regression checks for demand-driven operand slicing."""
import json
from pathlib import Path
import pytest
from dotori.apk import load_apk
from dotori.demand import Backward
from dotori.engine import Limits

FIXTURES=Path(__file__).parent/'fixtures'
EXPECTED=json.loads((FIXTURES/'expected-demand.json').read_text())
@pytest.fixture(scope='module')
def program():return load_apk(FIXTURES/'cases.apk')
@pytest.fixture(scope='module')
def report(program):return Backward(program,Limits(max_depth=48)).run()

@pytest.mark.parametrize('entry,expected',EXPECTED.items())
def test_demand_binary_cases(report,entry,expected):
    assert any(c['entry_component']==entry for c in report['candidates'])==expected

def test_lazy_method_bodies(program,report):
    assert program.catalog is not None
    assert report['metrics']['ir_methods_decoded']<report['metrics']['methods_indexed']
    assert report['metrics']['ir_cache_peak']<=program.catalog.max_cache

def test_operand_evidence(report):
    c=next(c for c in report['candidates'] if c['entry_component']=='lab.Direct')
    assert c['object_relations']
    assert c['source']['path']
    assert c['bridge']['exposure']['methods']==['Llab/Bridge;->ping(Ljava/lang/String;)Ljava/lang/String;']
    assert c['load']['receiver']

def test_forwarding_preserves_target_and_extra(report):
    f=next(f for f in report['intent_forwarding_paths'] if f.get('target_class')=='Llab/Internal;')
    assert f['extra_key']=='url'
    assert f['source']['entry']=='lab.Forwarder'
    assert any(c['entry_component']=='lab.Forwarder' and 'Llab/Internal;' in c['load']['site'] for c in report['candidates'])

def test_model_limits_remain_visible(program):
    r=Backward(program,Limits(max_steps=2,max_depth=48)).run()
    assert r['status']=='incomplete'
    assert r['metrics']['slice_queries']<=2
    assert any(d['code']=='total_query_limit' for d in r['diagnostics'])

def test_semantic_ids_are_stable(program,report):
    again=Backward(program,Limits(max_depth=48)).run()
    assert [c['id'] for c in report['candidates']]==[c['id'] for c in again['candidates']]

def test_focus_is_an_explicitly_reduced_scope(program,report):
    focused=Backward(program,Limits(max_depth=48),focus_methods=('Direct;',)).run()
    assert focused['analysis_selection']['focus_methods']==['Direct;']
    assert len(focused['api_inventory'])<len(report['api_inventory'])
    assert any(c['entry_component']=='lab.Direct' for c in focused['candidates'])
    assert all('diagnostic_codes' in c for c in focused['seed_coverage'])
    assert focused['registration_coverage']

def test_cli_focus_option_reaches_analysis(tmp_path):
    from dotori.cli import main
    output=tmp_path/'focused.json'
    main(['analyze',str(FIXTURES/'cases.apk'),'--focus-method','NeverPresent',
          '-o',str(output)])
    result=json.loads(output.read_text())
    assert result['analysis_selection']['focus_methods']==['NeverPresent']
    assert result['input_webview_paths']==[]
    assert result['registration_coverage']

def test_completion_counts_are_grounded_in_seed_coverage(report):
    done=report['completion']
    assert done['loading_sites']==len(report['seed_coverage'])
    assert done['bridge_registration_sites']==len(report['registration_coverage'])
    assert done['loading_sliced_incomplete']==sum(x['status']=='sliced_incomplete' for x in report['seed_coverage'])

def test_javascript_enablement_requires_the_same_webview_and_known_setting(report):
    disabled=next(c for c in report['candidates'] if c['entry_component']=='lab.JavaScriptDisabled')
    direct=next(c for c in report['candidates'] if c['entry_component']=='lab.Direct')
    assert disabled['load']['javascript_enabled']['state']=='false'
    assert direct['load']['javascript_enabled']['state']=='true'
    assert any('explicitly disabled' in a for a in disabled['assumptions'])
    other=next(c for c in report['input_webview_paths'] if c['entry_component']=='lab.DifferentViews')
    assert other['load']['javascript_enabled']['state']=='unknown'
    reenabled=next(c for c in report['candidates'] if c['entry_component']=='lab.JavaScriptReenabled')
    conditional=next(c for c in report['candidates'] if c['entry_component']=='lab.JavaScriptConditional')
    assert reenabled['load']['javascript_enabled']['state']=='true'
    assert conditional['load']['javascript_enabled']['state']=='unknown'

def test_exact_callers_have_priority_over_virtual_approximations():
    from types import SimpleNamespace
    from dotori.index import Site
    from dotori.model import Program
    child='Llab/Child;->work()V';parent='Llab/Parent;->work()V'
    exact=[Site('Llab/ZExact;->call()V',1,child,'invoke-virtual')]
    approximate=[Site(f'Llab/A{i:02d};->call()V',i,parent,'invoke-virtual') for i in range(70)]
    catalog=SimpleNamespace(inventory=[],interfaces={},call_signatures={('work','()V'):(child,parent)},
                            callers_of=lambda ref:exact if ref==child else approximate if ref==parent else [])
    program=Program('lab',None,None,[],{}, { 'Llab/Child;':'Llab/Parent;' },catalog=catalog)
    analysis=Backward(program)
    analysis.source_distance=lambda ref:0
    callers=analysis.callers(child)
    assert callers[0]==exact[0]
    assert len(callers)==64
    assert ('caller_fanout_limit',child) in analysis.seed_notes

def test_bundle_key_and_control_flow_are_not_merged(report):
    found={c['entry_component'] for c in report['candidates']}
    assert 'lab.BundleElement' in found
    assert not {'lab.BundleWrongKey','lab.BundleOverwrite','lab.BundleTypeOverwrite','lab.BundleConditional'} & found
    conditional=next(c for c in report['seed_coverage'] if 'Llab/BundleConditional;' in c['site'])
    assert 'container_slice_unresolved' in conditional['diagnostic_codes']

def test_runnable_capture_requires_registration_and_same_instance(report):
    posted=next(c for c in report['candidates'] if c['entry_component']=='lab.RunnablePosted')
    assert posted['source']['callback_instances']
    assert any('callback_registered:' in site for object_ in posted['load']['receiver'] for site in object_['path'])
    assert not {'lab.RunnableUnposted','lab.RunnableDifferentView','lab.RunnableConditionalPost'} & {
        c['entry_component'] for c in report['candidates']}
    conditional=next(c for c in report['seed_coverage'] if 'Llab/DeferredLoad;->run()V' in c['site'])
    assert 'conditional_callback_registration' in conditional['diagnostic_codes']

def test_concrete_virtual_dispatch_uses_the_override(report):
    hit=next(c for c in report['candidates'] if c['entry_component']=='lab.ConcreteVirtualOverride')
    assert any('Llab/ChildPicker;->pick' in step for step in hit['source']['path'])
    assert not any(c['entry_component']=='lab.ConcreteVirtualBase' for c in report['candidates'])

def test_class_cast_preserves_the_argument_origin(report):
    hit=next(c for c in report['candidates'] if c['entry_component']=='lab.ClassCastIdentity')
    assert any(':class_cast' in step for step in hit['source']['path'])
    assert not any(c['entry_component']=='lab.ClassCastOverwrite' for c in report['candidates'])


def test_inherited_writer_keeps_the_reader_component(report):
    hit=next(c for c in report['candidates'] if c['entry_component']=='lab.ZContextDispatchInput')
    assert 'Llab/ZContextDispatchInput;' in ' '.join(hit['source']['path'])
    assert 'component_context:' in ' '.join(hit['source']['path'])
    assert not any(c['entry_component']=='lab.ZContextDispatchFixed' for c in report['candidates'])
    assert not any(c['entry_component']=='lab.ZContextOtherReceiver' for c in report['candidates'])
    seed=next(c for c in report['seed_coverage'] if 'ZContextDispatchInput;' in c['site'])
    assert 'virtual_dispatch_limit' not in seed['diagnostic_codes']


def test_flow_review_survives_unrelated_gaps(program):
    # Manifest uncertainty outside a known witness must not erase the handoff.
    from dataclasses import replace
    p=replace(program,diagnostics=program.diagnostics+[{'code':'manifest_resource_unresolved','detail':'unrelated'}])
    r=Backward(p,focus_methods=('Direct;',)).run()
    hit=next(c for c in r['candidates'] if c['entry_component']=='lab.Direct')
    assert hit['review']['status']=='ready_for_review'
    assert hit['review']['vulnerability_verdict']=='not_assessed'
    assert not hit['review']['context_gaps']
    assert r['coverage_status']=='partial'


def test_text_handoff_includes_the_value_flow(report):
    from dotori.cli import text_report
    text=text_report(report)
    assert 'Value flow:' in text
    assert 'getStringExtra' in text
    assert 'Manual check:' in text


@pytest.mark.parametrize('code,expected',[
    ('unmodeled_return','completed_with_gaps'),
    ('unresolved_parameter','completed_with_gaps'),
    ('local_definition_limit','completed_with_gaps'),
    ('manifest_resource_unresolved','completed_with_gaps'),
    ('analysis_timeout','incomplete'),
    ('total_query_limit','incomplete'),
    ('catalog_decode_gap','incomplete'),
])
def test_collection_status_distinguishes_gaps_from_interrupts(code,expected):
    from dotori.reporting import collection_status
    assert collection_status([{'status':'sliced_incomplete'}],[],[{'code':code}])==expected


def test_unvisited_seeds_are_still_incomplete():
    from dotori.reporting import collection_status
    assert collection_status([{'status':'unvisited_budget'}],[],[])=='incomplete'
    assert collection_status([],[],[])=='completed_with_model_limits'


def test_review_gaps_keep_the_involved_sites_only():
    from dotori.reporting import annotate_paths
    item={'source':{'path':['source','sink']},'load':{'site':'sink'},'assumptions':[]}
    summary=annotate_paths({'paths':[item]},[
        {'site':'sink','status':'sliced_incomplete','diagnostic_codes':['unmodeled_return']},
        {'site':'other','status':'sliced_incomplete','diagnostic_codes':['unresolved_parameter']},
    ],[])
    assert summary['status']=='paths_available'
    assert item['review']['status']=='ready_for_review'
    assert item['review']['context_gaps']==[{'site':'sink','slice_status':'sliced_incomplete','diagnostic_codes':['unmodeled_return']}]
