"""General View slot/identity contracts; no application-specific signatures."""
from dataclasses import replace

from dotori.demand import Backward, Origin
from dotori.model import Instruction as I, Method
from dotori.view_state import VIEW, WEBVIEW, INFLATER, OBJECT, result as view_result
from test_webview_callbacks import catalog_program

ROOT = 'Lcallbacktest/Screen;->work()Ljava/lang/Object;'
SET = VIEW + '->setTag(Ljava/lang/Object;)V'
GET = VIEW + '->getTag()Ljava/lang/Object;'
KSET = VIEW + '->setTag(ILjava/lang/Object;)V'
KGET = VIEW + '->getTag(I)Ljava/lang/Object;'
INFLATE = INFLATER + '->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;'
INFLATE3 = INFLATER + '->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;'


def analyze(instructions, *methods, reg=4, offset=None, ref=ROOT, ins_size=0, supers=None):
    method = Method(ref, 'public static', 8, ins_size, instructions)
    a = Backward(catalog_program([method, *methods], supers))
    result = a.trace(ref, reg, offset if offset is not None else instructions[-1].offset, 'value')
    return a, result


def local_set(read=GET, write=SET):
    return [I(0, 'new-instance', (0,), literal=WEBVIEW),
            I(1, 'const-string', (1,), literal='https://example.invalid/'),
            I(2, 'invoke-virtual', (0, 1), write),
            I(3, 'invoke-virtual', (0,), read), I(4, 'move-result-object', (4,)),
            I(5, 'return-object', (4,))]


def test_same_view_default_tag_roundtrip():
    a, result = analyze(local_set())
    assert [v.value for v in result] == ['https://example.invalid/']
    assert 'view_tag_slot:default' in result[0].path
    assert not any(code.startswith('view_tag_') for code, _ in a.notes)


def test_default_and_keyed_tags_are_independent():
    code = local_set()
    code[3:3] = [I(21, 'const/4', (2,), literal=7), I(22, 'const-string', (3,), literal='keyed'),
                 I(23, 'invoke-virtual', (0, 2, 3), KSET)]
    code = [replace(i, offset=n) for n, i in enumerate(code)]
    assert [v.value for v in analyze(code)[1]] == ['https://example.invalid/']
    code[-3] = replace(code[-3], regs=(0, 2), ref=KGET)
    assert [v.value for v in analyze(code)[1]] == ['keyed']


def test_keyed_tag_wrong_key_does_not_flow():
    code = [I(0, 'new-instance', (0,), literal=WEBVIEW), I(1, 'const/4', (2,), literal=7),
            I(2, 'const-string', (1,), literal='value'), I(3, 'invoke-virtual', (0, 2, 1), KSET),
            I(4, 'const/4', (2,), literal=8), I(5, 'invoke-virtual', (0, 2), KGET),
            I(6, 'move-result-object', (4,)), I(7, 'return-object', (4,))]
    assert not analyze(code)[1]


def test_default_tag_different_objects_do_not_flow():
    code = local_set()
    code.insert(3, I(30, 'new-instance', (0,), literal=WEBVIEW))
    code = [replace(i, offset=n) for n, i in enumerate(code)]
    assert not analyze(code)[1]


def test_last_write_and_clear_are_authoritative():
    code = local_set()
    code[3:3] = [I(30, 'const/4', (1,), literal=0), I(31, 'invoke-virtual', (0, 1), SET)]
    code = [replace(i, offset=n) for n, i in enumerate(code)]
    assert [v.value for v in analyze(code)[1]] == ['0']


def test_future_write_cannot_supply_earlier_read():
    code = local_set()
    code[2], code[3], code[4] = code[3], code[4], code[2]
    code = [replace(i, offset=n) for n, i in enumerate(code)]
    assert not analyze(code)[1]


def test_unknown_key_overwrite_blocks_earlier_keyed_value():
    ref = 'Lcallbacktest/Screen;->work(I)Ljava/lang/Object;'
    code = [I(0, 'new-instance', (0,), literal=WEBVIEW), I(1, 'const/4', (2,), literal=7),
            I(2, 'const-string', (1,), literal='value'), I(3, 'invoke-virtual', (0, 2, 1), KSET),
            I(4, 'invoke-virtual', (0, 7, 1), KSET), I(5, 'invoke-virtual', (0, 2), KGET),
            I(6, 'move-result-object', (4,)), I(7, 'return-object', (4,))]
    a, result = analyze(code, ref=ref, ins_size=1)
    assert not result
    assert any(c == 'view_tag_writer_alias_unresolved' for c, _ in a.notes)


def test_unknown_value_overwrite_never_revives_earlier_value():
    ref = 'Lcallbacktest/Screen;->work(Ljava/lang/Object;)Ljava/lang/Object;'
    code = local_set()
    code.insert(3, I(30, 'invoke-virtual', (0, 7), SET))
    code = [replace(i, offset=n) for n, i in enumerate(code)]
    a, result = analyze(code, ref=ref, ins_size=1)
    assert not result
    assert any(c == 'view_tag_value_unresolved' for c, _ in a.notes)


def test_conditional_overwrite_does_not_pick_either_value():
    code = local_set()
    code[3:3] = [I(3, 'if-eqz', (7,), target=6), I(4, 'const/4', (1,), literal=0),
                 I(5, 'invoke-virtual', (0, 1), SET)]
    code = [replace(i, offset=n) for n, i in enumerate(code)]
    a, result = analyze(code, ref='Lcallbacktest/Screen;->work(Z)Ljava/lang/Object;', ins_size=1)
    assert not result
    assert any(c == 'view_tag_write_order_unresolved' for c, _ in a.notes)


def test_unrelated_same_name_method_uses_actual_body():
    fake = 'Lcallbacktest/Box;->getTag()Ljava/lang/Object;'
    getter = Method(fake, 'public', 2, 1,
                    [I(0, 'const-string', (0,), literal='actual'), I(1, 'return-object', (0,))])
    code = [I(0, 'new-instance', (0,), literal='Lcallbacktest/Box;'),
            I(1, 'invoke-virtual', (0,), fake), I(2, 'move-result-object', (4,)),
            I(3, 'return-object', (4,))]
    assert [v.value for v in analyze(code, getter)[1]] == ['actual']


def test_cast_does_not_turn_nonview_allocation_into_tag_receiver():
    code = local_set()
    code[0] = replace(code[0], literal='Ljava/lang/Object;')
    code.insert(1, I(10, 'check-cast', (0,), literal=WEBVIEW))
    code = [replace(i, offset=n) for n, i in enumerate(code)]
    assert not analyze(code)[1]


def test_tag_setter_helper_keeps_argument_tuple():
    helper = Method('Lcallbacktest/Helper;->write(' + VIEW + OBJECT + ')V', 'public static', 2, 2,
                    [I(0, 'invoke-virtual', (0, 1), SET), I(1, 'return-void')])
    code = local_set()
    code[2] = replace(code[2], op='invoke-static', ref=helper.ref)
    assert [v.value for v in analyze(code, helper)[1]] == ['https://example.invalid/']


def test_independent_tag_write_keeps_lifecycle_order_gap():
    slot = 'Lcallbacktest/Holder;->view' + VIEW
    setup = Method('Lcallbacktest/Holder;->setup()V', 'public static', 1, 0,
        [I(0, 'new-instance', (0,), literal=WEBVIEW), I(1, 'sput-object', (0,), slot), I(2, 'return-void')])
    writer = Method('Lcallbacktest/Writer;->publish()V', 'public static', 2, 0,
        [I(0, 'sget-object', (0,), slot), I(1, 'const-string', (1,), literal='published'),
         I(2, 'invoke-virtual', (0, 1), SET), I(3, 'return-void')])
    code = [I(0, 'sget-object', (0,), slot), I(1, 'invoke-virtual', (0,), GET),
            I(2, 'move-result-object', (4,)), I(3, 'return-object', (4,))]
    a, result = analyze(code, setup, writer)
    assert [v.value for v in result] == ['published']
    assert 'view_tag_read_after_write_assumed' in result[0].path
    assert any(c == 'view_tag_lifecycle_order_unresolved' for c, _ in a.notes)


def inflate_sequence(two=False, attached=False, explicit=False):
    code = [I(0, 'const/4', (1,), literal=123),
            I(1, 'new-instance' if attached else 'const/4', (2,), literal=VIEW if attached else 0)]
    if explicit:
        code += [I(2, 'const/4', (3,), literal=1 if attached else 0)]
    code += [I(3, 'invoke-virtual', (0, 1, 2, 3) if explicit else (0, 1, 2), INFLATE3 if explicit else INFLATE),
             I(4, 'move-result-object', (4,))]
    if two:
        code += [I(5, 'invoke-virtual', (0, 1, 2), INFLATE), I(6, 'move-result-object', (5,))]
    code += [I(7, 'return-object', (4,))]
    return code


def test_null_root_inflation_is_fresh_per_call_not_per_resource():
    a, first = analyze(inflate_sequence(two=True))
    second = a.trace(ROOT, 5, 7, 'object')
    assert len(first) == len(second) == 1
    assert first[0].key != second[0].key
    assert first[0].typ == VIEW
    assert first[0].key.endswith(':layout:123')


def test_attached_inflation_returns_parent_for_both_overloads():
    for explicit in (False, True):
        _, result = analyze(inflate_sequence(attached=True, explicit=explicit))
        assert len(result) == 1 and result[0].key == ROOT + '@0001'


def test_explicit_false_inflation_is_fresh_with_nonnull_parent():
    code = inflate_sequence(attached=True, explicit=True)
    code[2] = replace(code[2], literal=0)
    _, result = analyze(code)
    assert len(result) == 1 and result[0].key.startswith('inflated:')


def test_unknown_attach_flag_never_guesses_return_identity():
    code = inflate_sequence(attached=True, explicit=True)
    code[2] = replace(code[2], op='move', regs=(3, 7), literal=None)
    a, result = analyze(code, ref='Lcallbacktest/Screen;->work(Z)Ljava/lang/Object;', ins_size=1)
    assert not result
    assert any(c == 'inflated_view_root_unresolved' for c, _ in a.notes)


def test_unknown_layout_never_fabricates_resource_identity():
    code = inflate_sequence()
    code[0] = replace(code[0], op='move', regs=(1, 7), literal=None)
    assert not analyze(code, ref='Lcallbacktest/Screen;->work(I)Ljava/lang/Object;', ins_size=1)[1]


def test_inflated_children_keep_root_and_view_id_separate():
    code = inflate_sequence(two=True)[:-1]
    find = VIEW + '->findViewById(I)Landroid/view/View;'
    code += [I(7, 'const/4', (1,), literal=45), I(8, 'invoke-virtual', (4, 1), find),
             I(9, 'move-result-object', (0,)), I(10, 'invoke-virtual', (5, 1), find),
             I(11, 'move-result-object', (2,)), I(12, 'const/4', (1,), literal=46),
             I(13, 'invoke-virtual', (4, 1), find), I(14, 'move-result-object', (3,)),
             I(15, 'return-object', (0,))]
    a, first = analyze(code, reg=0)
    second = a.trace(ROOT, 2, 15, 'object'); third = a.trace(ROOT, 3, 15, 'object')
    assert len({first[0].key, second[0].key, third[0].key}) == 3


def test_view_subclass_getter_override_uses_actual_body_even_through_base():
    custom = 'Lcallbacktest/CustomView;'
    getter = Method(custom + '->getTag()' + OBJECT, 'public', 2, 1,
        [I(0, 'const-string', (0,), literal='override'), I(1, 'return-object', (0,))])
    for read in (getter.ref, GET):
        code = local_set(read=read)
        code[0] = replace(code[0], literal=custom)
        _, result = analyze(code, getter, supers={custom: VIEW})
        assert [v.value for v in result] == ['override']
        assert not any(s.startswith('view_tag_slot:') for v in result for s in v.path)


def test_view_subclass_noop_setter_never_writes_framework_slot():
    custom = 'Lcallbacktest/CustomView;'
    setter = Method(custom + '->setTag(' + OBJECT + ')V', 'public', 2, 2,
                    [I(0, 'return-void')])
    for write in (setter.ref, SET):
        code = local_set(write=write)
        code[0] = replace(code[0], literal=custom)
        assert not analyze(code, setter, supers={custom: VIEW})[1]


def test_inherited_tags_on_view_subclass_still_roundtrip():
    custom = 'Lcallbacktest/CustomView;'
    code = local_set(read=custom + '->getTag()' + OBJECT,
                     write=custom + '->setTag(' + OBJECT + ')V')
    code[0] = replace(code[0], literal=custom)
    assert [v.value for v in analyze(code, supers={custom: VIEW})[1]] == ['https://example.invalid/']


def test_override_super_setter_uses_body_value_not_call_argument():
    custom = 'Lcallbacktest/CustomView;'
    setter = Method(custom + '->setTag(' + OBJECT + ')V', 'public', 3, 2,
        [I(0, 'const-string', (0,), literal='body'), I(1, 'invoke-super', (1, 0), SET),
         I(2, 'return-void')])
    code = local_set(write=setter.ref)
    code[0] = replace(code[0], literal=custom)
    assert [v.value for v in analyze(code, setter, supers={custom: VIEW})[1]] == ['body']


def test_override_super_getter_can_read_framework_slot():
    custom = 'Lcallbacktest/CustomView;'
    getter = Method(custom + '->getTag()' + OBJECT, 'public', 2, 1,
        [I(0, 'invoke-super', (1,), GET), I(1, 'move-result-object', (0,)),
         I(2, 'return-object', (0,))])
    code = local_set(read=getter.ref)
    code[0] = replace(code[0], literal=custom)
    assert [v.value for v in analyze(code, getter, supers={custom: VIEW})[1]] == ['https://example.invalid/']


def test_attached_inflation_preserves_operand_guards_and_context(monkeypatch):
    code = inflate_sequence(attached=True, explicit=True)
    method = Method(ROOT, 'public static', 8, 0, code)
    a = Backward(catalog_program([method]))
    call = next(i for i in code if i.ref == INFLATE3)
    root = Origin('view', 'parent', VIEW, callback_instances=frozenset({'root'}))
    layout = Origin('constant', 'layout', value='123',
                    guards=frozenset({(ROOT, 10, 11)}), callback_instances=frozenset({'root', 'layout'}))
    attach = Origin('constant', 'attach', value='1',
                    guards=frozenset({(ROOT, 20, 21)}), callback_instances=frozenset({'root', 'attach'}))
    monkeypatch.setattr(a, 'trace', lambda ref, reg, *args: {1: (layout,), 2: (root,), 3: (attach,)}[reg])
    result = view_result(a, method, call, 'object', 0, 0)
    assert len(result) == 1 and result[0].key == 'parent'
    assert result[0].guards == layout.guards | attach.guards
    assert result[0].callback_instances == frozenset({'root', 'layout', 'attach'})


def test_inflation_rejects_incompatible_attach_operand(monkeypatch):
    for attached in (False, True):
        code = inflate_sequence(attached=True, explicit=True)
        method = Method(ROOT, 'public static', 8, 0, code)
        a = Backward(catalog_program([method]))
        call = next(i for i in code if i.ref == INFLATE3)
        layout = Origin('constant', 'layout', value='123', guards=frozenset({(ROOT, 10, 11)}))
        root = Origin('view', 'parent', VIEW, guards=frozenset({(ROOT, 10, 11)}))
        attach = Origin('constant', 'attach', value='1' if attached else '0',
                        guards=frozenset({(ROOT, 10, 12)}))
        monkeypatch.setattr(a, 'trace', lambda ref, reg, *args: {1: (layout,), 2: (root,), 3: (attach,)}[reg])
        assert not view_result(a, method, call, 'object', 0, 0)


def test_tag_transfer_preserves_writer_receiver_context(monkeypatch):
    code = local_set()
    method = Method(ROOT, 'public static', 8, 0, code)
    a = Backward(catalog_program([method]))
    base = Origin('view', 'shared-view', VIEW, callback_instances=frozenset({'reader'}))
    target = replace(base, callback_instances=frozenset({'writer'}))
    value = Origin('constant', 'value', value='stored')
    monkeypatch.setattr(a, 'trace', lambda ref, reg, before, *args:
                        (value,) if reg == 1 else ((target,) if before == 2 else (base,)))
    result = view_result(a, method, code[3], 'value', 0, 0)
    assert [v.value for v in result] == ['stored']
    assert result[0].callback_instances == frozenset({'reader', 'writer'})


def test_keyed_tag_rejects_conflicting_key_and_receiver_guards(monkeypatch):
    code = [I(0, 'invoke-virtual', (0, 2, 1), KSET), I(1, 'invoke-virtual', (0, 2), KGET)]
    method = Method(ROOT, 'public static', 8, 0, code)
    a = Backward(catalog_program([method]))
    base = Origin('view', 'shared-view', VIEW, guards=frozenset({(ROOT, 10, 11)}))
    key = Origin('constant', 'key', value='7', guards=frozenset({(ROOT, 10, 12)}))
    value = Origin('constant', 'value', value='stored')
    monkeypatch.setattr(a, 'trace', lambda ref, reg, *args: {0: (base,), 1: (value,), 2: (key,)}[reg])
    assert not view_result(a, method, code[1], 'value', 0, 0)


def test_keyed_tag_rejects_conflicting_writer_operands(monkeypatch):
    code = [I(0, 'invoke-virtual', (0, 2, 1), KSET), I(1, 'invoke-virtual', (0, 2), KGET)]
    method = Method(ROOT, 'public static', 8, 0, code)
    a = Backward(catalog_program([method]))
    base = Origin('view', 'shared-view', VIEW)
    target = replace(base, guards=frozenset({(ROOT, 10, 11)}))
    key = Origin('constant', 'key', value='7')
    written_key = replace(key, guards=frozenset({(ROOT, 10, 12)}))
    value = Origin('constant', 'value', value='stored')
    monkeypatch.setattr(a, 'trace', lambda ref, reg, before, *args:
                        {0: (target,), 1: (value,), 2: (written_key,)}[reg] if before == 0
                        else {0: (base,), 2: (key,)}[reg])
    assert not view_result(a, method, code[1], 'value', 0, 0)


def test_cast_to_view_does_not_hide_overridden_tag_getter():
    custom = 'Lcallbacktest/CustomView;'
    getter = Method(custom + '->getTag()' + OBJECT, 'public', 2, 1,
        [I(0, 'const-string', (0,), literal='override'), I(1, 'return-object', (0,))])
    code = local_set()
    code[0] = replace(code[0], literal=custom)
    code.insert(1, I(10, 'check-cast', (0,), literal=VIEW))
    code = [replace(i, offset=n) for n, i in enumerate(code)]
    assert [v.value for v in analyze(code, getter, supers={custom: VIEW})[1]] == ['override']


def test_tag_writer_helper_invocations_keep_receivers_and_values_together():
    helper = Method('Lcallbacktest/Helper;->write(' + VIEW + OBJECT + ')V', 'public static', 2, 2,
                    [I(0, 'invoke-virtual', (0, 1), SET), I(1, 'return-void')])
    code = [I(0, 'new-instance', (0,), literal=VIEW), I(1, 'new-instance', (2,), literal=VIEW),
            I(2, 'const-string', (1,), literal='first'), I(3, 'const-string', (3,), literal='second'),
            I(4, 'invoke-static', (0, 1), helper.ref), I(5, 'invoke-static', (2, 3), helper.ref),
            I(6, 'invoke-virtual', (0,), GET), I(7, 'move-result-object', (4,)),
            I(8, 'return-object', (4,))]
    assert [v.value for v in analyze(code, helper)[1]] == ['first']


def test_inflater_factory_invocations_have_distinct_view_identity():
    factory = Method('Lcallbacktest/Factory;->make()' + VIEW, 'public static', 5, 0,
                     inflate_sequence())
    code = [I(0, 'invoke-static', (), factory.ref), I(1, 'move-result-object', (0,)),
            I(2, 'invoke-static', (), factory.ref), I(3, 'move-result-object', (2,)),
            I(4, 'const-string', (1,), literal='first'), I(5, 'invoke-virtual', (0, 1), SET),
            I(6, 'invoke-virtual', (2,), GET), I(7, 'move-result-object', (4,)),
            I(8, 'return-object', (4,))]
    a, result = analyze(code, factory)
    assert not result
    first = a.trace(ROOT, 0, 8, 'object'); second = a.trace(ROOT, 2, 8, 'object')
    assert len(first) == len(second) == 1
    assert first[0].key != second[0].key


def test_detached_inflation_preserves_callback_context(monkeypatch):
    code = inflate_sequence()
    method = Method(ROOT, 'public static', 8, 0, code)
    a = Backward(catalog_program([method]))
    call = next(i for i in code if i.ref == INFLATE)
    layout = Origin('constant', 'layout', value='123', callback_instances=frozenset({'callback'}))
    root = Origin('constant', 'null', value='0')
    monkeypatch.setattr(a, 'trace', lambda ref, reg, *args: {1: (layout,), 2: (root,)}[reg])
    result = view_result(a, method, call, 'object', 0, 0)
    assert len(result) == 1
    assert result[0].callback_instances == frozenset({'callback'})
