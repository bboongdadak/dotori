"""LiveData is an allocation/registration transfer, never a name-based join."""
from dotori.demand import Backward
from dotori.engine import Limits
from dotori.model import Instruction as I, Method
from dotori.livedata import LIVE, MUTABLE, OBSERVER, OWNER, OBJECT, OBSERVE
from test_webview_callbacks import catalog_program, ACTIVITY, WEBVIEW, BRIDGE

OBS = 'Llivedatatest/Observer;'
EVENT = 'Llivedatatest/Envelope;'
STATIC = 'Llivedatatest/State;'
FIRST = STATIC + '->first' + MUTABLE
SECOND = STATIC + '->second' + MUTABLE


def scenario(*, register=True, wrong_live=False, wrong_observer=False,
             fake_live=False, wrap=False, wrong_payload=False,
             observe_forever=False, remove=False, conditional=False):
    setup = Method(ACTIVITY + '->onCreate(Landroid/os/Bundle;)V', 'public', 9, 2)
    instructions = []
    def add(op, regs=(), ref='', literal=None, target=None):
        instructions.append(I(len(instructions)*2, op, regs, ref, literal, target))
    add('new-instance', (0,), literal=MUTABLE)
    add('sput-object', (0,), FIRST)
    add('new-instance', (1,), literal=MUTABLE)
    add('sput-object', (1,), SECOND)
    add('new-instance', (2,), literal=WEBVIEW)
    add('new-instance', (3,), literal=OBS)
    init = Method(OBS+'-><init>('+WEBVIEW+')V', 'public constructor', 2, 2,
        [I(0, 'iput-object', (1,0), OBS+'->web'+WEBVIEW), I(2,'return-void')])
    add('invoke-direct', (3,2), init.ref)
    if wrong_observer:
        add('new-instance', (4,), literal=WEBVIEW)
        add('new-instance', (5,), literal=OBS)
        add('invoke-direct', (5,4), init.ref)
    add('new-instance', (4,), literal=BRIDGE)
    add('const-string', (6,), literal='Native')
    add('invoke-virtual', (2,4,6), WEBVIEW+'->addJavascriptInterface('+OBJECT+'Ljava/lang/String;)V')
    if conditional:
        add('if-eqz', (8,), target=100)
    obsreg = 5 if wrong_observer else 3
    if register:
        add('invoke-virtual', (0,obsreg) if observe_forever else (0,7,obsreg),
            MUTABLE+('->observeForever('+OBSERVER+')V' if observe_forever else '->observe'+OBSERVE))
    if remove:
        # This scenario emits in the setup method after explicitly unregistering.
        add('invoke-virtual', (0,obsreg), MUTABLE+'->removeObserver('+OBSERVER+')V')
        add('invoke-virtual', (7,), ACTIVITY+'->getIntent()Landroid/content/Intent;')
        add('move-result-object', (4,))
        add('invoke-virtual', (4,), 'Landroid/content/Intent;->getDataString()Ljava/lang/String;')
        add('move-result-object', (4,))
        add('invoke-virtual', (0,4), MUTABLE+'->setValue('+OBJECT+')V')
    add('return-void')
    if conditional:
        instructions.append(I(100,'return-void'))
    setup.instructions=instructions
    emit = Method(ACTIVITY+'->onNewIntent(Landroid/content/Intent;)V','public',6,2)
    instructions=[]
    add('sget-object',(0,), SECOND if wrong_live else FIRST)
    add('invoke-virtual',(5,), 'Landroid/content/Intent;->getDataString()Ljava/lang/String;')
    add('move-result-object',(1,))
    eventinit = Method(EVENT+'-><init>('+OBJECT+')V','public constructor',2,2,
        [I(0,'iput-object',(1,0),EVENT+'->value'+OBJECT), I(2,'return-void')])
    value = 1
    if wrap:
        add('new-instance',(2,),literal=EVENT)
        add('invoke-direct',(2,1),eventinit.ref)
        value=2
        if wrong_payload:
            add('const-string',(1,),literal='https://safe.invalid')
            add('new-instance',(3,),literal=EVENT)
            add('invoke-direct',(3,1),eventinit.ref)
            value=3
    if not remove:
        add('invoke-virtual',(0,value), MUTABLE+'->postValue('+OBJECT+')V')
    add('return-void')
    emit.instructions=instructions
    callback = Method(OBS+'->onChanged('+OBJECT+')V','public',4,2)
    instructions=[]
    add('iget-object',(0,2), OBS+'->web'+WEBVIEW)
    if wrap:
        add('check-cast',(3,),literal=EVENT)
        add('iget-object',(1,3),EVENT+'->value'+OBJECT)
        value=1
    else:value=3
    add('invoke-virtual',(0,value),WEBVIEW+'->loadUrl(Ljava/lang/String;)V')
    add('return-void')
    callback.instructions=instructions
    bridge=Method(BRIDGE+'->call()V','public',1,1,[I(0,'return-void')],('Landroid/webkit/JavascriptInterface;',))
    p=catalog_program([setup,emit,init,eventinit,callback,bridge],
        {OBS:'Ljava/lang/Object;', EVENT:'Ljava/lang/Object;', MUTABLE:LIVE if not fake_live else 'Ljava/lang/Object;'})
    p.catalog.interfaces[OBS]=(OBSERVER,)
    return p,callback,setup,emit


def analyze(p):
    return Backward(p,Limits(max_depth=64,max_steps=100000,timeout_seconds=10)).run()


def test_registered_livedata_delivers_only_emitted_operand_and_same_captured_webview():
    p,callback,setup,emit=scenario()
    result=analyze(p)
    assert len(result['candidates'])==1
    source=result['candidates'][0]['source']
    assert source['kind']=='external_value'
    assert any(step.startswith('livedata_emit:'+emit.ref) for step in source['path'])
    assert any(step.startswith('livedata_observer_registered:'+setup.ref) for step in source['path'])
    assert any(step=='livedata_callback_dispatch:'+callback.ref for step in source['path'])
    assert source['callback_instances']
    assert 'livedata_delivery_lifecycle_order_unresolved' in {d['code'] for d in result['diagnostics']}


def test_unregistered_observer_and_different_stream_do_not_receive_values():
    for options in ({'register':False},{'wrong_live':True},{'fake_live':True}):
        p,*_=scenario(**options)
        result=analyze(p)
        assert not result['candidates']
        assert not result['input_webview_paths']


def test_registered_observer_capture_does_not_use_another_same_class_instance():
    p,*_=scenario(wrong_observer=True)
    result=analyze(p)
    assert not result['candidates']
    assert result['input_webview_paths']
    assert all(path['load']['receiver'][0]['key'].endswith('@000e') for path in result['input_webview_paths'])


def test_wrapper_field_retains_exact_posted_object_and_registration_proof():
    p,*_=scenario(wrap=True)
    result=analyze(p)
    assert len(result['candidates'])==1
    assert any('livedata_emit:' in step for step in result['candidates'][0]['source']['path'])
    p,*_=scenario(wrap=True,wrong_payload=True)
    assert not analyze(p)['input_webview_paths']


def test_observe_forever_is_supported_and_explicit_removal_blocks_delivery():
    p,*_=scenario(observe_forever=True)
    assert analyze(p)['candidates']
    p,*_=scenario(remove=True)
    result=analyze(p)
    assert not result['input_webview_paths']
    assert 'livedata_observer_removed' in {d['code'] for d in result['diagnostics']}


def test_conditional_registration_preserves_its_path_guard_through_payload():
    p,*_=scenario(conditional=True,wrap=True)
    result=analyze(p)
    assert result['candidates']
    source=result['candidates'][0]['source']
    assert any('onCreate' in ref for ref,branch,target in source['branch_choices'])


def rebuild(p):
    new=catalog_program(list(p.methods.values()),p.supers)
    new.catalog.interfaces.update(p.catalog.interfaces)
    return new


def test_constant_unreachable_registration_is_not_a_delivery():
    p,callback,setup,emit=scenario(conditional=True)
    branch=next(i for i in setup.instructions if i.op=='if-eqz')
    # Existing condition is p1; insert a dominating constant null definition.
    setup.instructions.insert(0,I(-2,'const/4',(8,),literal=0))
    assert not analyze(rebuild(p))['input_webview_paths']


def test_actual_livedata_subclass_override_is_not_summarized_as_framework():
    from dataclasses import replace
    for name,desc in [('observe',OBSERVE),('postValue','('+OBJECT+')V')]:
        p,callback,setup,emit=scenario()
        custom='Llivedatatest/CustomLiveData;'
        setup.instructions=[replace(i,literal=custom) if i.op=='new-instance' and i.literal==MUTABLE else i
                            for i in setup.instructions]
        override=Method(custom+'->'+name+desc,'public',3 if name=='observe' else 2,
                        3 if name=='observe' else 2,[I(0,'return-void')])
        p.methods[override.ref]=override
        p.supers[custom]=MUTABLE
        result=analyze(rebuild(p))
        assert not result['input_webview_paths']
        assert 'livedata_override_unresolved' in {d['code'] for d in result['diagnostics']}


def test_same_class_two_streams_preserve_registration_token_compatibility():
    from dotori.demand import compatible
    p,callback,setup,emit=scenario()
    # The same observer instance is registered on both streams. An emitted
    # first-stream value must keep the first registration's callback identity.
    setup.instructions.insert(-1,I(60,'invoke-virtual',(1,7,3),MUTABLE+'->observe'+OBSERVE))
    setup.instructions[-1]=I(62,'return-void')
    analysis=Backward(rebuild(p))
    sources=analysis.parameter(callback,callback.argument_registers()[1],'value',0,0)
    receivers=analysis.parameter(callback,callback.argument_registers()[0],'object',0,0)
    assert len(sources)==1 and len(receivers)==2
    assert sum(compatible(sources[0],r) for r in receivers)==1


def test_compiled_livedata_fixture_keeps_positive_and_counterexample_separate():
    from pathlib import Path
    from dotori.apk import load_apk
    path=Path(__file__).parent/'fixtures'/'livedata.apk'
    result=analyze(load_apk(path))
    positive={candidate['entry_component'] for candidate in result['candidates']}
    assert positive=={'ld.Registered','ld.Wrapped'}
    input_only={path['entry_component'] for path in result['input_webview_paths']}
    assert input_only=={'ld.Registered','ld.Wrapped','ld.WrongObserver'}
    assert all(any('livedata_same_allocation:' in step for step in candidate['source']['path'])
               for candidate in result['candidates'])
