"""Fragment delivery requires exact instances, setter operands, and payload keys."""
from dataclasses import replace

from dotori.demand import Backward, Origin
from dotori.engine import Limits
from dotori.model import Component, Instruction as I, Method
from dotori.router_transfers import BUNDLE, FRAGMENTS, GET, INTENT, SET, STRING
from test_webview_callbacks import ACTIVITY, BRIDGE, WEBVIEW, catalog_program

FRAGMENT = 'Lfragmenttest/ScreenFragment;'


def scenario(*, key='url', wrong_fragment=False, wrong_bundle=False, overwrite=False,
             set_after_read=False, conditional=False, helper=False, override=False,
             cross_method=False, second_write=False, mutate_after_set=False,
             mutation_after_read=False, wrong_type=False, unknown_key=False):
    method = Method(ACTIVITY + '->onCreate(' + BUNDLE + ')V', 'public', 12, 2)
    instructions = []
    def add(op, regs=(), ref='', literal=None, target=None):
        instructions.append(I(len(instructions)*2, op, regs, ref, literal, target))
    add('new-instance', (0,), literal=WEBVIEW)
    add('new-instance', (1,), literal=BRIDGE)
    add('const-string', (2,), literal='Native')
    add('invoke-virtual', (0,1,2), WEBVIEW+'->addJavascriptInterface(Ljava/lang/Object;'+STRING+')V')
    add('new-instance', (3,), literal=FRAGMENT)
    init = Method(FRAGMENT+'-><init>('+WEBVIEW+')V', 'public constructor', 2, 2,
                  [I(0,'iput-object',(1,0),FRAGMENT+'->web'+WEBVIEW), I(2,'return-void')])
    add('invoke-direct', (3,0), init.ref)
    if wrong_fragment:
        add('new-instance', (4,), literal=FRAGMENT)
        add('invoke-direct', (4,0), init.ref)
    add('new-instance', (5,), literal=BUNDLE)
    add('invoke-direct', (5,), BUNDLE+'-><init>()V')
    add('invoke-virtual', (10,), ACTIVITY+'->getIntent()'+INTENT)
    add('move-result-object', (6,))
    add('invoke-virtual', (6,), INTENT+'->getDataString()'+STRING)
    add('move-result-object', (6,))
    add('const-string', (7,), literal='url')
    add('invoke-virtual', (5,7,6), BUNDLE+'->putString('+STRING+STRING+')V')
    if overwrite:
        add('const-string', (6,), literal='https://trusted.invalid')
        add('invoke-virtual', (5,7,6), BUNDLE+'->putString('+STRING+STRING+')V')
    if wrong_bundle:
        add('new-instance', (8,), literal=BUNDLE)
        add('invoke-direct', (8,), BUNDLE+'-><init>()V')
    setter = Method('Lfragmenttest/Helper;->set('+FRAGMENTS[1]+BUNDLE+')V', 'public static', 2, 2,
                    [I(0,'invoke-virtual',(0,1),FRAGMENTS[1]+'->setArguments'+SET), I(2,'return-void')])
    def set_arguments():
        if helper:
            add('invoke-static', (4 if wrong_fragment else 3,8 if wrong_bundle else 5), setter.ref)
        else:
            add('invoke-virtual', (4 if wrong_fragment else 3,8 if wrong_bundle else 5), FRAGMENTS[1]+'->setArguments'+SET)
    if conditional:
        add('if-eqz', (11,), target=200)
    if not set_after_read:
        set_arguments()
    if mutate_after_set and not mutation_after_read:
        add('const-string', (6,), literal='https://trusted.invalid')
        add('invoke-virtual', (5,7,6), BUNDLE+'->putString('+STRING+STRING+')V')
    if wrong_type:
        add('const/4', (6,), literal=3)
        add('invoke-virtual', (5,7,6), BUNDLE+'->putInt('+STRING+'I)V')
    if second_write:
        add('new-instance',(8,),literal=BUNDLE)
        add('invoke-direct',(8,),BUNDLE+'-><init>()V')
        add('invoke-virtual',(3,8),FRAGMENTS[1]+'->setArguments'+SET)
    read = Method(FRAGMENT+'->onCreate('+BUNDLE+')V','public',4,2)
    if cross_method:
        add('return-void')
        read.instructions = [I(0,'invoke-virtual',(2,),FRAGMENTS[1]+'->getArguments'+GET),
            I(2,'move-result-object',(0,)), I(4,'const-string',(1,),literal=key),
            I(6,'invoke-virtual',(0,1),BUNDLE+'->getString('+STRING+')'+STRING),
            I(8,'move-result-object',(1,)), I(10,'iget-object',(0,2),FRAGMENT+'->web'+WEBVIEW),
            I(12,'invoke-virtual',(0,1),WEBVIEW+'->loadUrl('+STRING+')V'), I(14,'return-void')]
    else:
        add('invoke-virtual', (3,), FRAGMENTS[1]+'->getArguments'+GET)
        add('move-result-object', (8,))
        add('const-string', (7,), literal=key)
        if unknown_key:
            add('move-object', (7,6))
        add('invoke-virtual', (8,7), BUNDLE+'->getString('+STRING+')'+STRING)
        add('move-result-object', (9,))
        if mutation_after_read:
            add('const-string', (6,), literal='https://trusted.invalid')
            add('invoke-virtual', (5,7,6), BUNDLE+'->putString('+STRING+STRING+')V')
        if set_after_read:
            set_arguments()
        add('invoke-virtual', (0,9), WEBVIEW+'->loadUrl('+STRING+')V')
        add('return-void')
    if conditional:
        instructions.append(I(200,'return-void'))
    method.instructions = instructions
    bridge = Method(BRIDGE+'->go()V','public',1,1,[I(0,'return-void')],('Landroid/webkit/JavascriptInterface;',))
    methods = [method,init,bridge] + ([setter] if helper else []) + ([read] if cross_method else [])
    if override:
        methods.append(Method(FRAGMENT+'->getArguments'+GET,'public',2,1,
                              [I(0,'new-instance',(0,),literal=BUNDLE), I(2,'return-object',(0,))]))
    p = catalog_program(methods, {FRAGMENT:FRAGMENTS[1]})
    return p


def analyze(p):
    return Backward(p, Limits(max_depth=64,max_steps=100000,timeout_seconds=10)).run()


def test_fragment_arguments_deliver_same_allocation_and_exact_string_key():
    result = analyze(scenario())
    assert len(result['candidates']) == 1
    path = result['candidates'][0]['source']['path']
    assert any(s.startswith('fragment_arguments_set:') for s in path)
    assert any(s.startswith('fragment_arguments_get:') for s in path)
    assert any(s.startswith('fragment_argument_key:url:') for s in path)


def test_fragment_arguments_reject_different_instances_bundles_keys_and_overwrites():
    for kwargs in ({'wrong_fragment':True}, {'wrong_bundle':True}, {'key':'other'},
                   {'overwrite':True}, {'second_write':True}, {'set_after_read':True},
                   {'conditional':True}, {'override':True}):
        result = analyze(scenario(**kwargs))
        assert result['candidates'] == [], kwargs
        assert result['input_webview_paths'] == [], kwargs


def test_fragment_setter_helper_keeps_receiver_and_bundle_in_one_call_context():
    result = analyze(scenario(helper=True))
    assert len(result['candidates']) == 1
    assert analyze(scenario(helper=True, wrong_fragment=True))['input_webview_paths'] == []
    assert analyze(scenario(helper=True, wrong_bundle=True))['input_webview_paths'] == []


def test_fragment_lifecycle_read_requires_same_concrete_allocation_and_marks_order_limit():
    result = analyze(scenario(cross_method=True))
    assert len(result['candidates']) == 1
    assert 'fragment_arguments_lifecycle_order_unresolved' in {d['code'] for d in result['diagnostics']}


def internal_extras(key, forwarding=None):
    target = 'Lfragmenttest/Internal;'
    method = Method(target+'->onCreate('+BUNDLE+')V','public',4,2,
        [I(0,'invoke-virtual',(2,),target+'->getIntent()'+INTENT),
         I(2,'move-result-object',(0,)),
         I(4,'invoke-virtual',(0,),INTENT+'->getExtras'+GET),
         I(6,'move-result-object',(0,)), I(8,'const-string',(1,),literal=key),
         I(10,'invoke-virtual',(0,1),BUNDLE+'->getString('+STRING+')'+STRING),
         I(12,'move-result-object',(1,)), I(14,'return-void')])
    p = catalog_program([method],{target:'Landroid/app/Activity;'})
    p.components.append(Component('fragmenttest.Internal',target,'activity',False))
    analysis = Backward(p,Limits(max_steps=10000,timeout_seconds=10))
    source = Origin('external_value','intent:source',entry='source',path=('source.getData',))
    metadata = {'target_class':target,'payload':'extra','extra_key':'url'} if forwarding is None else forwarding
    analysis.forwarders = [{**metadata,'source':source.dump(),'site':'dispatch'}]
    return analysis.trace(method.ref,1,14)


def test_internal_get_extras_retains_payload_key_until_bundle_read():
    assert any(o.kind == 'external_value' for o in internal_extras('url'))
    assert not any(o.kind == 'external_value' for o in internal_extras('unrelated'))


def test_whole_nested_intent_forwarding_keeps_conditional_target_evidence():
    whole = {'classification':'conditional_intent_forwarding'}
    for key in ('url', 'other_external_extra'):
        values = internal_extras(key, whole)
        assert any(o.kind == 'external_value' for o in values)
        assert all(any(':conditional_internal_intent_target' in s for s in o.path)
                   for o in values if o.kind == 'external_value')


def test_whole_intent_fallback_never_relaxes_structured_payload_matching():
    target = 'Lfragmenttest/Internal;'
    negatives = [
        {'target_class':target,'payload':'extra','extra_key':'other'},
        {'target_class':'Lfragmenttest/Other;','payload':'extra','extra_key':'url'},
        {'target_class':target,'payload':'data','extra_key':''},
        {'target_class':target,'payload':'extra'},
        {},
        {'classification':'conditional_intent_forwarding','target_class':'Lfragmenttest/Other;'},
        {'classification':'conditional_intent_forwarding','payload':'extra','extra_key':'other'},
    ]
    for forwarding in negatives:
        assert not any(o.kind == 'external_value' for o in internal_extras('url', forwarding)), forwarding


def test_nested_intent_to_internal_bundle_read_end_to_end():
    target = 'Lfragmenttest/Internal;'
    source = Method(ACTIVITY+'->onCreate('+BUNDLE+')V','public',4,2,[
        I(0,'invoke-virtual',(2,),ACTIVITY+'->getIntent()'+INTENT),
        I(2,'move-result-object',(0,)), I(4,'const-string',(1,),literal='next'),
        I(6,'invoke-virtual',(0,1),INTENT+'->getParcelableExtra('+STRING+')Landroid/os/Parcelable;'),
        I(8,'move-result-object',(0,)), I(10,'check-cast',(0,),literal=INTENT),
        I(11,'if-eqz',(0,),target=14),
        I(12,'invoke-virtual',(2,0),ACTIVITY+'->startActivity('+INTENT+')V'), I(14,'return-void')])
    reader = Method(target+'->onCreate('+BUNDLE+')V','public',5,2,[
        I(0,'invoke-virtual',(3,),target+'->getIntent()'+INTENT),
        I(2,'move-result-object',(0,)), I(4,'invoke-virtual',(0,),INTENT+'->getExtras'+GET),
        I(6,'move-result-object',(0,)), I(8,'const-string',(1,),literal='url'),
        I(10,'invoke-virtual',(0,1),BUNDLE+'->getString('+STRING+')'+STRING),
        I(12,'move-result-object',(1,)), I(14,'new-instance',(2,),literal=WEBVIEW),
        I(16,'invoke-virtual',(2,1),WEBVIEW+'->loadUrl('+STRING+')V'), I(18,'return-void')])
    program = catalog_program([source,reader],{target:'Landroid/app/Activity;'})
    program.components.append(Component('fragmenttest.Internal',target,'activity',False))
    report = analyze(program)
    assert len(report['intent_forwarding_paths']) == 1
    assert len(report['input_webview_paths']) == 1
    path = report['input_webview_paths'][0]['source']['path']
    assert any(':getParcelableExtra' in s for s in path)
    assert any(':conditional_internal_intent_target' in s for s in path)
    assert any(':intent_extra_key:url' in s for s in path)
    assert [source.ref,11,12] in report['input_webview_paths'][0]['source']['branch_choices']


def test_fragment_argument_bundle_is_a_reference_not_a_snapshot_at_assignment():
    assert analyze(scenario(mutate_after_set=True))['input_webview_paths'] == []
    assert len(analyze(scenario(mutation_after_read=True))['candidates']) == 1


def test_fragment_cross_method_post_assignment_mutation_stays_unresolved():
    result = analyze(scenario(cross_method=True, mutate_after_set=True))
    assert result['input_webview_paths'] == []
    assert 'fragment_arguments_bundle_mutation_unresolved' in {d['code'] for d in result['diagnostics']}


def test_fragment_wrong_type_overwrite_and_nonconstant_read_key_do_not_propagate():
    assert analyze(scenario(wrong_type=True))['input_webview_paths'] == []
    assert analyze(scenario(unknown_key=True))['input_webview_paths'] == []


def test_fragment_conditional_setter_wrapper_does_not_erase_branch_limit():
    result = analyze(scenario(helper=True, conditional=True))
    assert result['input_webview_paths'] == []
    assert 'fragment_arguments_conditional_write_unresolved' in {d['code'] for d in result['diagnostics']}


def test_compiled_fragment_arguments_preserve_exact_instance_and_key_checks():
    from pathlib import Path
    from dotori.apk import load_apk
    result = analyze(load_apk(Path(__file__).parent/'fixtures'/'fragment_arguments.apk'))
    assert {c['entry_component'] for c in result['candidates']} == {'fr.Exact','fr.Helper'}
    assert {p['entry_component'] for p in result['input_webview_paths']} == {'fr.Exact','fr.Helper'}
    assert all(any(s.startswith('fragment_argument_key:url:') for s in c['source']['path'])
               for c in result['candidates'])
