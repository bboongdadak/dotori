"""Independent synthetic lookup contracts; no APK fixtures or labels."""
from dataclasses import replace

from dotori.demand import Backward, Origin
from dotori.model import Instruction as I, Method
from dotori.view_lookup import VIEW, GROUP, ACTIVITY, CHILD, CHILD_AT, COUNT, FIND, result
from test_webview_callbacks import catalog_program

ROOT = 'Lcallbacktest/Screen;->lookup()' + VIEW
SET_CONTENT = ACTIVITY + '->setContentView(I)V'


def analyze(code, *extra, ref=ROOT, reg=4, ins_size=0, access='public static', supers=None):
    method = Method(ref, access, 8, ins_size, code)
    a = Backward(catalog_program([method, *extra], supers))
    return a, a.trace(ref, reg, code[-1].offset, 'object')


def lookup(*, child=False, typ=GROUP, selector=7):
    return [I(0, 'new-instance', (0,), literal=typ), I(1, 'const/16', (1,), literal=selector),
            I(2, 'invoke-static' if child else 'invoke-virtual', (0, 1), CHILD if child else FIND),
            I(3, 'move-result-object', (4,)), I(4, 'return-object', (4,))]


def canonical_helper():
    return Method(CHILD, 'public static', 6, 2, [
        I(0, 'instance-of', (0, 4), literal=GROUP), I(1, 'if-eqz', (0,), target=17),
        I(2, 'check-cast', (4,), literal=GROUP), I(3, 'invoke-virtual', (4,), COUNT),
        I(4, 'move-result', (0,)), I(5, 'const/4', (1,), literal=0),
        I(6, 'if-ge', (1, 0), target=17), I(7, 'invoke-virtual', (4, 1), CHILD_AT),
        I(8, 'move-result-object', (2,)), I(9, 'invoke-virtual', (2, 5), FIND),
        I(10, 'move-result-object', (2,)), I(11, 'if-eqz', (2,), target=14),
        I(12, 'return-object', (2,)), I(14, 'add-int/lit8', (1, 1), literal=1),
        I(15, 'goto', target=6), I(17, 'const/4', (3,), literal=0), I(18, 'return-object', (3,))])


def test_direct_lookup_retains_conditional_occurrence_not_webview_type():
    a, values = analyze(lookup())
    assert len(values) == 1 and values[0].kind == 'view_lookup' and values[0].typ == VIEW
    assert 'view_lookup_id:7' in values[0].path
    assert 'view_lookup_nonnull_assumed' in values[0].path
    assert ('view_lookup_nullable_result', ROOT + '@0002') in a.notes


def test_distinct_roots_ids_and_lookup_occurrences_never_alias():
    code = lookup()[:-1] + [I(4, 'invoke-virtual', (0, 1), FIND), I(5, 'move-result-object', (2,)),
        I(6, 'new-instance', (0,), literal=GROUP), I(7, 'invoke-virtual', (0, 1), FIND),
        I(8, 'move-result-object', (3,)), I(9, 'const/16', (1,), literal=8),
        I(10, 'invoke-virtual', (0, 1), FIND), I(11, 'move-result-object', (5,)), I(12, 'return-object', (4,))]
    a, values = analyze(code)
    other = [a.trace(ROOT, reg, 12, 'object')[0] for reg in (2, 3, 5)]
    assert len({values[0].key, *(v.key for v in other)}) == 4
    assert not any(a.object_aliases(values, (v,)) for v in other)


def test_exact_androidx_helper_models_only_descendants():
    _, values = analyze(lookup(child=True), canonical_helper())
    assert len(values) == 1 and values[0].kind == 'view_lookup'
    assert any(':view_lookup:descendants' in step for step in values[0].path)
    assert 'view_lookup_viewgroup_assumed' not in values[0].path


def test_same_name_custom_helper_uses_its_body():
    fake = Method(CHILD, 'public static', 3, 2,
                  [I(0, 'const/4', (0,), literal=0), I(1, 'return-object', (0,))])
    _, values = analyze(lookup(child=True), fake)
    assert [v.value for v in values] == ['0']
    assert all(v.kind != 'view_lookup' for v in values)


def test_helper_returning_root_is_not_replaced_by_descendant_summary():
    fake = Method(CHILD, 'public static', 2, 2, [I(0, 'return-object', (0,))])
    _, values = analyze(lookup(child=True), fake)
    assert len(values) == 1 and values[0].kind == 'allocation'
    assert values[0].key == ROOT + '@0000'


def test_unrelated_find_view_by_id_uses_actual_body():
    fake = Method('Lcallbacktest/Other;->findViewById(I)' + VIEW, 'public', 3, 2,
                  [I(0, 'const/4', (0,), literal=0), I(1, 'return-object', (0,))])
    code = lookup(typ=fake.owner)
    code[2] = replace(code[2], ref=fake.ref)
    _, values = analyze(code, fake)
    assert [v.value for v in values] == ['0']


def test_defined_subclass_lookup_uses_actual_body_even_through_cast():
    fake = Method('Lcallbacktest/OtherView;->findViewById(I)' + VIEW, 'public', 3, 2,
                  [I(0, 'const/4', (0,), literal=0), I(1, 'return-object', (0,))])
    code = lookup(typ=fake.owner)
    code.insert(1, I(10, 'check-cast', (0,), literal=VIEW))
    code = [replace(i, offset=n) for n, i in enumerate(code)]
    _, values = analyze(code, fake, supers={fake.owner: VIEW})
    assert [v.value for v in values] == ['0']


def test_custom_view_traversal_does_not_get_framework_summary():
    traversal = Method('Lcallbacktest/OtherView;->findViewTraversal(I)' + VIEW, 'protected', 3, 2,
                       [I(0, 'const/4', (0,), literal=0), I(1, 'return-object', (0,))])
    a, values = analyze(lookup(typ=traversal.owner), traversal, supers={traversal.owner: VIEW})
    assert not values
    assert any(code == 'view_lookup_traversal_override_unresolved' for code, _ in a.notes)


def test_null_root_is_not_a_receiver_identity():
    for child in (False, True):
        code = lookup(child=child)
        code[0] = replace(code[0], op='const/4', literal=0)
        a, values = analyze(code)
        assert not values if not child else [v.value for v in values] == ['0']
        assert any(c == 'view_lookup_null_root' for c, _ in a.notes)


def test_descendant_lookup_on_known_non_group_is_null():
    _, values = analyze(lookup(child=True, typ=VIEW))
    assert [v.value for v in values] == ['0']


def test_lookup_with_no_id_is_null():
    for child in (False, True):
        assert [v.value for v in analyze(lookup(child=child, selector=-1))[1]] == ['0']


def test_unknown_selector_never_becomes_a_receiver_identity():
    code = lookup()
    code[1] = replace(code[1], op='move', regs=(1, 7), literal=None)
    a, values = analyze(code, ref='Lcallbacktest/Screen;->lookup(I)' + VIEW, ins_size=1)
    assert not values
    assert any(c == 'view_lookup_id_unresolved' for c, _ in a.notes)


def test_loop_lookup_occurrence_remains_unresolved():
    code = lookup()
    code.insert(-1, I(4, 'if-nez', (7,), target=2))
    code[-1] = replace(code[-1], offset=5)
    a, values = analyze(code, ref='Lcallbacktest/Screen;->lookup(Z)' + VIEW, ins_size=1)
    assert not values
    assert any(c == 'view_lookup_lifetime_unresolved' for c, _ in a.notes)


def test_helper_invocations_keep_lookup_occurrences_separate():
    helper = Method('Lcallbacktest/Helper;->find(' + VIEW + ')' + VIEW, 'public static', 3, 1,
        [I(0, 'const/16', (0,), literal=7), I(1, 'invoke-static', (2, 0), CHILD),
         I(2, 'move-result-object', (0,)), I(3, 'return-object', (0,))])
    code = [I(0, 'new-instance', (0,), literal=GROUP), I(1, 'invoke-static', (0,), helper.ref),
            I(2, 'move-result-object', (4,)), I(3, 'invoke-static', (0,), helper.ref),
            I(4, 'move-result-object', (5,)), I(5, 'return-object', (4,))]
    a, values = analyze(code, helper)
    second = a.trace(ROOT, 5, 5, 'object')
    assert len(values) == len(second) == 1
    assert values[0].key != second[0].key


def test_lookup_preserves_all_guards_and_callback_provenance(monkeypatch):
    method = Method(ROOT, 'public static', 8, 0, lookup(child=True))
    a = Backward(catalog_program([method]))
    root = Origin('view', 'inflated:root', VIEW, guards=frozenset({(ROOT, 10, 11)}),
                  callback_instances=frozenset({'callback'}))
    selector = Origin('constant', '7', value='7', guards=frozenset({(ROOT, 20, 21)}))
    monkeypatch.setattr(a, 'trace', lambda ref, reg, *args: (root,) if reg == 0 else (selector,))
    values = result(a, method, method.instructions[2], 'object', 0, 0)
    assert len(values) == 1
    assert values[0].guards == root.guards | selector.guards
    assert values[0].callback_instances == root.callback_instances
    assert 'view_lookup_viewgroup_assumed' in values[0].path
    selector = replace(selector, guards=frozenset({(ROOT, 10, 12)}))
    assert not result(a, method, method.instructions[2], 'object', 0, 0)


def test_field_slot_without_root_lifetime_is_unresolved(monkeypatch):
    method = Method(ROOT, 'public static', 8, 0, lookup())
    a = Backward(catalog_program([method]))
    root = Origin('field_slot', 'slot', VIEW)
    selector = Origin('constant', '7', value='7')
    monkeypatch.setattr(a, 'trace', lambda ref, reg, *args: (root,) if reg == 0 else (selector,))
    assert not result(a, method, method.instructions[2], 'object', 0, 0)
    assert any(c == 'view_lookup_root_unresolved' for c, _ in a.notes)


def test_activity_requires_same_frame_content_generation():
    find = ACTIVITY + '->findViewById(I)' + VIEW
    code = [I(0, 'const/16', (1,), literal=7), I(1, 'invoke-virtual', (7, 1), find),
            I(2, 'move-result-object', (4,)), I(3, 'return-object', (4,))]
    a, values = analyze(code, access='public', ins_size=1)
    assert not values
    assert any(c == 'view_lookup_content_root_unresolved' for c, _ in a.notes)


def test_activity_content_generation_is_part_of_root_evidence():
    find = ACTIVITY + '->findViewById(I)' + VIEW
    code = [I(0, 'const/16', (1,), literal=123), I(1, 'invoke-virtual', (7, 1), SET_CONTENT),
            I(2, 'const/16', (1,), literal=7), I(3, 'invoke-virtual', (7, 1), find),
            I(4, 'move-result-object', (4,)), I(5, 'const/16', (1,), literal=124),
            I(6, 'invoke-virtual', (7, 1), SET_CONTENT), I(7, 'const/16', (1,), literal=7),
            I(8, 'invoke-virtual', (7, 1), find), I(9, 'move-result-object', (5,)), I(10, 'return-object', (4,))]
    a, first = analyze(code, access='public', ins_size=1)
    second = a.trace(ROOT, 5, 10, 'object')
    assert len(first) == len(second) == 1 and first[0].key != second[0].key
    assert any(':layout:123' in s for s in first[0].path)
    assert any(':layout:124' in s for s in second[0].path)


def test_unrelated_content_setter_does_not_create_activity_root():
    other = 'Lcallbacktest/OtherActivity;'
    find = ACTIVITY + '->findViewById(I)' + VIEW
    code = [I(0, 'new-instance', (0,), literal=other), I(1, 'const/16', (1,), literal=123),
            I(2, 'invoke-virtual', (0, 1), SET_CONTENT), I(3, 'const/16', (1,), literal=7),
            I(4, 'invoke-virtual', (7, 1), find), I(5, 'move-result-object', (4,)), I(6, 'return-object', (4,))]
    assert not analyze(code, access='public', ins_size=1, supers={other: ACTIVITY})[1]
