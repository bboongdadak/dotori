"""Constructor field replay retains heap-delivery proof and branch conditions."""
from dataclasses import replace

from dotori.demand import Origin
from dotori.model import Instruction as I, Method
from test_context_identity import analysis_for


def capture(*, conflict=False):
    field='Lproof/Box;->valueLjava/lang/String;'
    constructor=Method('Lproof/Box;-><init>(Ljava/lang/String;)V','public constructor',2,2,
        [I(0,'iput-object',(1,0),field),I(2,'return-void')])
    factory=Method('Lproof/Factory;->make(Ljava/lang/String;)Lproof/Box;','public static',2,1,
        [I(0,'new-instance',(0,),literal='Lproof/Box;'),
         I(2,'invoke-direct',(0,1),constructor.ref),I(4,'return-object',(0,))])
    reader=Method('Lproof/Reader;->read(Lproof/Box;)Ljava/lang/String;','public static',3,1,
        [I(0,'iget-object',(0,2),field),I(2,'return-object',(0,))])
    analysis=analysis_for(constructor,factory,reader)
    allocated=analysis.trace(factory.ref,0,4,'object')[0]
    base=replace(allocated,guards=frozenset({('Lproof/Branch;->choose()V',4,10)}),
                 path=allocated.path+('heap_delivery:exact_allocation',))
    value=Origin('external_value','input:value',entry='proof.input',path=('external_payload',),
                 guards=frozenset({('Lproof/Branch;->choose()V',4,20 if conflict else 10)}))
    # These are explicit guarded input facts to the replay, not synthetic
    # callback tokens. Ordinary constructors must preserve them as well.
    analysis.context_origins[0]={1:(value,),2:(base,)}
    return analysis.trace(reader.ref,0,2),base,value


def test_constructor_capture_keeps_noncallback_receiver_proof_and_guards():
    origins,base,value=capture()
    assert len(origins)==1
    assert origins[0].kind=='external_value'
    assert 'heap_delivery:exact_allocation' in origins[0].path
    assert 'external_payload' in origins[0].path
    assert origins[0].guards==base.guards|value.guards
    assert not origins[0].callback_instances


def test_constructor_capture_rejects_incompatible_noncallback_receiver_guard():
    origins,_,_=capture(conflict=True)
    assert origins==()


def forwarding(*, conflict=False, string_action=False):
    intent='Landroid/content/Intent;'
    target='Lproof/Destination;'
    descriptor='(Ljava/lang/String;)V' if string_action else '(Landroid/content/Context;Ljava/lang/Class;)V'
    actual=(0,4) if string_action else (0,1,4)
    method=Method('Lproof/Factory;->intent(Ljava/lang/String;Ljava/lang/Class;)'+intent,
        'public static',5,2,[I(0,'new-instance',(0,),literal=intent),
          I(2,'const/4',(1,),literal=0),I(4,'invoke-direct',actual,intent+'-><init>'+descriptor),
          I(6,'const-string',(2,),literal='url'),
          I(8,'invoke-virtual',(0,2,3),intent+'->putExtra(Ljava/lang/String;Ljava/lang/String;)'+intent),
          I(10,'return-object',(0,))])
    analysis=analysis_for(method)
    guard=('Lproof/Branch;->choose()V',4,10)
    source=Origin('external_value','input:value',entry='proof.input',path=('external_payload',),guards=frozenset({guard}))
    destination=Origin('constant',target,value=target,path=('resolved_class_operand',),
        guards=frozenset({(guard[0],guard[1],20 if conflict else 10)}))
    analysis.context_origins[0]={3:(source,),4:(destination,)}
    allocation=analysis.trace(method.ref,0,10,'object')[0]
    return analysis.intent_payloads(method.ref,{allocation.key},None)


def test_forwarding_target_evidence_preserves_class_operand_and_compatible_guards():
    records=forwarding()
    assert len(records)==1
    record=records[0]
    assert record['payload_type']=='Ljava/lang/String;'
    assert record['target_evidence'][0]['origin']['path']==['resolved_class_operand']
    assert record['source']['branch_choices']==record['target_evidence'][0]['origin']['branch_choices']


def test_forwarding_rejects_incompatible_target_payload_and_class_shaped_action_string():
    assert forwarding(conflict=True)==[]
    assert forwarding(string_action=True)==[]
