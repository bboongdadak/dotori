"""Build inert String.format regression APKs; never install or execute them.

Usage: python tests/build_string_format_fixtures.py /path/to/apktool.jar

The checked-in smali and binary manifest exercise the real DEX parser. All
external input comes from an exported Activity's getIntent/getDataString pair.
"""
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile


ROOT = Path(__file__).parent / 'fixtures' / 'string_format'
SMALI = ROOT / 'smali' / 'formatcases'
CASES = (
    'Sequential', 'Indexed', 'SecondArgument', 'EscapedPercent', 'Copied',
    'CopySnapshot', 'SourceRegisterOverwrite', 'CopyReallocatedOriginal',
    'UnusedArgument', 'Overwritten', 'WrongArray', 'CopyTruncated',
    'CopyBeforeSource', 'CopyOverwritten', 'EscapedPercentOnly', 'NoPlaceholder',
    'UnknownFormat', 'ConditionalWrite', 'EscapedArray', 'UnsupportedConversion',
)
FORMAT = 'Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;'
COPY = 'Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;'


def case_smali(name):
    code = f'''.class public Lformatcases/{name};
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 9
 invoke-virtual {{p0}},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v1
 invoke-virtual {{v1}},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v1
 const-string v2,"https://fixed.invalid/"
 new-instance v3,Landroid/webkit/WebView;
 invoke-direct {{v3,p0}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v4,Lformatcases/Bridge;
 invoke-direct {{v4}},Lformatcases/Bridge;-><init>()V
 const-string v5,"Native"
 invoke-virtual {{v3,v4,v5}},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 const/4 v4,0x2
 new-array v0,v4,[Ljava/lang/Object;
 const/4 v5,0x0
 const/4 v7,0x1
'''
    if name in ('SecondArgument', 'CopyTruncated'):
        code += ''' aput-object v2,v0,v5
 aput-object v1,v0,v7
'''
    elif name == 'ConditionalWrite':
        code += ''' aput-object v2,v0,v5
 if-eqz p1,:after_write
 aput-object v1,v0,v5
 :after_write
 aput-object v2,v0,v7
'''
    elif name == 'CopyBeforeSource':
        code += ''' aput-object v2,v0,v5
 aput-object v2,v0,v7
'''
    else:
        code += ''' aput-object v1,v0,v5
 aput-object v2,v0,v7
'''

    array = 'v0'
    if name in ('Copied', 'CopySnapshot', 'CopyTruncated', 'CopyBeforeSource',
                'CopyOverwritten', 'CopyReallocatedOriginal'):
        if name == 'CopyTruncated':
            code += ' const/4 v4,0x1\n'
        code += f' invoke-static {{v0,v4}},{COPY}\n move-result-object v8\n'
        array = 'v8'
    if name in ('Overwritten', 'CopySnapshot'):
        code += ' aput-object v2,v0,v5\n'
    if name == 'CopyBeforeSource':
        code += ' aput-object v1,v0,v5\n'
    if name == 'CopyOverwritten':
        code += ' aput-object v2,v8,v5\n'
    if name == 'WrongArray':
        code += ''' new-array v8,v4,[Ljava/lang/Object;
 aput-object v2,v8,v5
 aput-object v2,v8,v7
'''
        array = 'v8'
    if name == 'SourceRegisterOverwrite':
        code += ' move-object v1,v2\n'
    if name == 'CopyReallocatedOriginal':
        code += ''' new-array v0,v4,[Ljava/lang/Object;
 aput-object v2,v0,v5
 aput-object v2,v0,v7
'''
    if name == 'EscapedArray':
        code += ' invoke-static {v0},Lformatcases/Unknown;->mutate([Ljava/lang/Object;)V\n'

    template = {
        'Indexed': 'https://format.invalid/%1$s/%1$s',
        'SecondArgument': '%2$s',
        'EscapedPercent': 'https://format.invalid/%%/%s',
        'UnusedArgument': '%2$s',
        'EscapedPercentOnly': 'https://fixed.invalid/%%s',
        'NoPlaceholder': 'https://fixed.invalid/static',
        'UnsupportedConversion': '%d',
    }.get(name, '%s')
    if name == 'UnknownFormat':
        code += ' invoke-static {},Lformatcases/Unknown;->template()Ljava/lang/String;\n move-result-object v5\n'
    else:
        code += f' const-string v5,"{template}"\n'
    return code + f''' invoke-static {{v5,{array}}},{FORMAT}
 move-result-object v6
 invoke-virtual {{v3,v6}},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
'''


def write_sources():
    SMALI.mkdir(parents=True, exist_ok=True)
    (ROOT / 'apktool.yml').write_text((ROOT.parent / 'apktool.yml').read_text())
    (SMALI / 'Bridge.smali').write_text('''.class public Lformatcases/Bridge;
.super Ljava/lang/Object;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 return-void
.end method
.method public call()V
 .registers 1
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 return-void
.end method
''')
    manifest = ['''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dotori.stringformat">
<uses-sdk android:minSdkVersion="21" android:targetSdkVersion="34"/>
<application android:label="String format regression cases">''']
    for name in CASES:
        (SMALI / (name + '.smali')).write_text(case_smali(name))
        manifest.append(f'<activity android:name="formatcases.{name}" android:exported="true"/>')
    manifest.append('</application></manifest>')
    (ROOT / 'AndroidManifest.xml').write_text('\n'.join(manifest))


def build(apktool):
    output = ROOT.parent / 'string_format.apk'
    subprocess.run(['java', '-jar', str(apktool), 'b', str(ROOT), '-o', str(output)], check=True)
    # apktool's copied manifest must be replaced with compiled binary XML so
    # these tests exercise the APK reader, not a synthetic Program object.
    with tempfile.TemporaryDirectory(prefix='dotori-string-format-build-') as directory:
        tmp = Path(directory)
        with zipfile.ZipFile(apktool) as archive:
            aapt = tmp / 'aapt2'
            aapt.write_bytes(archive.read('prebuilt/linux/aapt2_64'))
            aapt.chmod(0o755)
            framework = tmp / 'android-framework.jar'
            framework.write_bytes(archive.read('prebuilt/android-framework.jar'))
        packed = tmp / 'manifest.apk'
        subprocess.run([str(aapt), 'link', '--manifest', str(ROOT / 'AndroidManifest.xml'),
                        '-I', str(framework), '-o', str(packed)], check=True)
        with zipfile.ZipFile(output) as archive:
            files = {name: archive.read(name) for name in archive.namelist()}
        with zipfile.ZipFile(packed) as archive:
            files['AndroidManifest.xml'] = archive.read('AndroidManifest.xml')
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name, content in files.items():
                archive.writestr(name, content)
    return output


if __name__ == '__main__':
    write_sources()
    if len(sys.argv) > 1:
        print(build(Path(sys.argv[1])))
