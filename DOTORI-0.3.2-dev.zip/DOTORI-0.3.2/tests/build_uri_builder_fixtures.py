"""Compile inert, generic Uri.Builder bytecode fixtures; never execute APKs.
Usage: python tests/build_uri_builder_fixtures.py /path/to/apktool.jar
"""
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).parent / 'fixtures' / 'uri-builder'
SMALI = ROOT / 'smali' / 'uri'
SMALI.mkdir(parents=True, exist_ok=True)
(ROOT / 'apktool.yml').write_text((ROOT.parent / 'apktool.yml').read_text())
(SMALI / 'Bridge.smali').write_text('''.class public Luri/Bridge;
.super Ljava/lang/Object;
.method public call()V
 .registers 1
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 return-void
.end method
''')
CASES = ('Path', 'AppendQuery', 'BuildUpon', 'BoundHelpers', 'Replaced', 'Cleared',
         'WrongBuilder', 'LateSource', 'SnapshotRetained', 'SnapshotCleared', 'Conditional', 'Escaped')
manifest = ['''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dotori.uri">
<uses-sdk android:minSdkVersion="21" android:targetSdkVersion="34"/>
<application android:label="Uri Builder regression cases">''']
create=''' new-instance v0,Landroid/net/Uri$Builder;
 invoke-direct {v0},Landroid/net/Uri$Builder;-><init>()V
 const-string v5,"https"
 invoke-virtual {v0,v5},Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;
 const-string v5,"fixed.invalid"
 invoke-virtual {v0,v5},Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;
 const-string v5,"item"
'''
build=''' invoke-virtual {v0},Landroid/net/Uri$Builder;->build()Landroid/net/Uri;
 move-result-object v7
 invoke-virtual {v7},Landroid/net/Uri;->toString()Ljava/lang/String;
 move-result-object v7
'''
path=' invoke-virtual {v0,v1},Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;\n'
for name in CASES:
    code=f'''.class public Luri/{name};
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 10
 invoke-virtual {{p0}},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v1
 invoke-virtual {{v1}},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v1
 const-string v2,"fixed"
 new-instance v3,Landroid/webkit/WebView;
 invoke-direct {{v3,p0}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v4,Luri/Bridge;
 invoke-direct {{v4}},Ljava/lang/Object;-><init>()V
 const-string v5,"Native"
 invoke-virtual {{v3,v4,v5}},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
'''+create
    if name == 'BuildUpon':
        code += ''' invoke-static {v1},Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
 move-result-object v6
 invoke-virtual {v6},Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;
 move-result-object v0
 invoke-virtual {v0,v5,v2},Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;
'''
    elif name in ('AppendQuery','Cleared','SnapshotCleared'):
        code += ' invoke-virtual {v0,v5,v1},Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;\n'
    elif name == 'BoundHelpers':
        code += ' invoke-static {v0,v1},Luri/Helpers;->put(Landroid/net/Uri$Builder;Ljava/lang/String;)V\n'
    elif name == 'LateSource':
        code += ' invoke-virtual {v0,v2},Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;\n'
    elif name == 'Conditional':
        code += ' if-eqz p1,:after\n'+path+' :after\n'
    else:
        code += path
    if name == 'Replaced':
        code += ' invoke-virtual {v0,v2},Landroid/net/Uri$Builder;->encodedPath(Ljava/lang/String;)Landroid/net/Uri$Builder;\n'
    if name in ('Cleared','SnapshotCleared'):
        if name == 'SnapshotCleared':
            code += ''' invoke-virtual {v0},Landroid/net/Uri$Builder;->build()Landroid/net/Uri;
 move-result-object v6
 invoke-virtual {v6},Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;
 move-result-object v0
'''
        code += ' invoke-virtual {v0},Landroid/net/Uri$Builder;->clearQuery()Landroid/net/Uri$Builder;\n'
    if name == 'WrongBuilder':
        code += create
    if name == 'Escaped':
        code += ' invoke-static {v0},Luri/Unknown;->escape(Landroid/net/Uri$Builder;)V\n'
    if name == 'BoundHelpers':
        code += ' invoke-static {v0},Luri/Helpers;->get(Landroid/net/Uri$Builder;)Ljava/lang/String;\n move-result-object v7\n'
    else:
        code += build
    if name == 'LateSource':
        code += path
    if name == 'SnapshotRetained':
        code += ' invoke-virtual {v0,v2},Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;\n'
    code += ''' invoke-virtual {v3,v7},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
'''
    (SMALI / (name+'.smali')).write_text(code)
    manifest.append(f'<activity android:name="uri.{name}" android:exported="true"/>')
(SMALI/'Helpers.smali').write_text('''.class public Luri/Helpers;
.super Ljava/lang/Object;
.method public static put(Landroid/net/Uri$Builder;Ljava/lang/String;)V
 .registers 2
 invoke-virtual {p0,p1},Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;
 return-void
.end method
.method public static get(Landroid/net/Uri$Builder;)Ljava/lang/String;
 .locals 1
 invoke-virtual {p0},Landroid/net/Uri$Builder;->build()Landroid/net/Uri;
 move-result-object v0
 invoke-virtual {v0},Landroid/net/Uri;->toString()Ljava/lang/String;
 move-result-object v0
 return-object v0
.end method
''')
manifest.append('</application></manifest>')
(ROOT/'AndroidManifest.xml').write_text('\n'.join(manifest))
if len(sys.argv)>1:
    output=ROOT.parent/'uri-builder.apk'
    subprocess.run(['java','-jar',sys.argv[1],'b',str(ROOT),'-o',str(output)],check=True)
    with tempfile.TemporaryDirectory(prefix='dotori-uri-build-') as tmp:
        tmp=Path(tmp)
        with zipfile.ZipFile(sys.argv[1]) as archive:
            aapt=tmp/'aapt2';aapt.write_bytes(archive.read('prebuilt/linux/aapt2_64'));aapt.chmod(0o755)
            framework=tmp/'android-framework.jar';framework.write_bytes(archive.read('prebuilt/android-framework.jar'))
        packed=tmp/'manifest.apk'
        subprocess.run([str(aapt),'link','--manifest',str(ROOT/'AndroidManifest.xml'),'-I',str(framework),'-o',str(packed)],check=True)
        with zipfile.ZipFile(output) as archive:files={name:archive.read(name) for name in archive.namelist()}
        with zipfile.ZipFile(packed) as archive:files['AndroidManifest.xml']=archive.read('AndroidManifest.xml')
        with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
            for name,content in files.items():archive.writestr(name,content)
