from types import SimpleNamespace
from dotori.model import Program,Method,Instruction
from dotori.demand import Backward,Origin

def test_guard_variants_do_not_silently_hide_other_input_sources():
    ref='Llab/Inputs;->read()V'
    m=Method(ref,'public static',1,0,[Instruction(0,'const-string',(0,),literal='x'),Instruction(2,'return-void')])
    cat=SimpleNamespace(inventory=[],call_signatures={},interfaces={})
    b=Backward(Program('lab',34,21,[],{ref:m},{},catalog=cat))
    many=[Origin('external_value','intent:A',entry='A',path=('A:onCreate',),guards=frozenset({('A:branch',i,i+1)})) for i in range(40)]
    distinct=Origin('external_value','intent:A',entry='A',path=('A:onNewIntent',))
    b.definition=lambda *args:tuple(many+[distinct])
    result=b.trace(ref,0,2)
    assert len(result)==32 and distinct in result
    assert ('origin_alternative_limit',b.site(ref,2)) in b.notes
    assert all(len(o.guards)<=1 for o in result)  # never union incompatible paths

def test_conditional_dispatch_is_visible_in_manual_checks():
    from dotori.reporting import annotate_paths
    item={'source':{'path':['start','dispatch_receiver_type_unproven:Example'],'branch_choices':[]},'load':{'site':'load'},'assumptions':[]}
    annotate_paths({'input_webview_paths':[item]},[],[])
    assert any('Conditional dispatch' in task for task in item['review']['manual_checks'])


def test_fragment_lifecycle_assumption_is_visible_in_manual_checks():
    from dotori.reporting import annotate_paths
    item = {'source': {'path': ['fragment_arguments_read_after_set_assumed:fixture']}}
    annotate_paths({'input_webview_paths': [item]}, [], [])
    assert any('Fragment argument write' in task for task in item['review']['manual_checks'])


def test_exception_feasibility_is_visible_in_manual_checks():
    from dotori.reporting import annotate_paths
    item = {'source': {'path': ['fixture'], 'branch_choices': [['Lfixture;->run()V:exception', 2, 8]]}}
    annotate_paths({'bridge_javascript_paths': [item]}, [], [])
    assert any('handler type' in task for task in item['review']['manual_checks'])
