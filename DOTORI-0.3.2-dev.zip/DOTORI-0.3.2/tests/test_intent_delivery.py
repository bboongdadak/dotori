"""Exported targets retain direct input and exact compatible ICC alternatives."""
import pytest
from dotori.demand import Origin, INTENT
from dotori.intent_delivery import values
from dotori.model import Component, Instruction as I, Method
from test_context_identity import analysis_for

TARGET = 'Ldelivery/Target;'
SOURCE = 'Ldelivery/Source;'
STRING = 'Ljava/lang/String;'


def read(getter='getData', exported=True, forwarder=None, key='url'):
    desc = '(' + STRING + ')' + STRING if getter == 'getStringExtra' else '()Landroid/net/Uri;'
    instructions = [I(0, 'invoke-virtual', (3,), ref='Landroid/app/Activity;->getIntent()' + INTENT),
        I(2, 'move-result-object', (0,)), I(4, 'const-string', (1,), literal=key),
        I(6, 'invoke-virtual', (0, 1) if getter == 'getStringExtra' else (0,),
          ref=INTENT + '->' + getter + desc), I(8, 'move-result-object', (2,)), I(10, 'return-void')]
    method = Method(TARGET + '->onCreate()V', 'public', 4, 1, instructions)
    analysis = analysis_for(method, components=(Component('delivery.Target', TARGET, 'activity', exported),))
    source = Origin('external_value', 'intent:' + SOURCE, entry='delivery.Source', path=('source-read',),
        guards=frozenset({('source-method', 2, 4)}), callback_instances=frozenset({'source-callback'}))
    analysis.forwarders = [{'site':'source-dispatch', 'source':source.dump(),
        **({'target_class':TARGET, 'payload':'data'} if forwarder is None else forwarder)}]
    return analysis, analysis.trace(method.ref, 2, 10)


@pytest.mark.parametrize('exported', [False, True])
def test_explicit_data_delivery_preserves_source_context(exported):
    _, origins = read(exported=exported)
    sent = [o for o in origins if o.entry == 'delivery.Source']
    assert len(sent) == 1
    assert ('source-method', 2, 4) in sent[0].guards
    assert sent[0].callback_instances == frozenset({'source-callback'})
    assert 'source-dispatch:intent_forwarding' in sent[0].path
    assert any('explicit_intent_target:' + TARGET in step for step in sent[0].path)
    assert any(o.entry == 'delivery.Target' for o in origins) == exported


@pytest.mark.parametrize('metadata', [
    {'target_class':'Ldelivery/Other;', 'payload':'data'},
    {'payload':'data'},
    {'target_class':TARGET, 'payload':'extra', 'extra_key':'url'},
    {'classification':'conditional_intent_forwarding'},
])
def test_exported_direct_source_never_implies_unmatched_forwarding(metadata):
    _, origins = read(forwarder=metadata)
    assert {o.entry for o in origins} == {'delivery.Target'}


def test_extra_delivery_requires_matching_key_and_payload_type():
    good = {'target_class':TARGET, 'payload':'extra', 'extra_key':'url', 'payload_type':STRING}
    _, origins = read('getStringExtra', forwarder=good)
    assert {o.entry for o in origins} == {'delivery.Target', 'delivery.Source'}
    for metadata in (dict(good, extra_key='other'), dict(good, payload='data'),
                     dict(good, payload_type='Landroid/os/Parcelable;')):
        _, origins = read('getStringExtra', forwarder=metadata)
        assert {o.entry for o in origins} == {'delivery.Target'}


def test_unknown_key_or_conflicting_source_guards_cannot_prove_delivery():
    analysis, _ = read()
    analysis.forwarders[0].update(payload='extra', extra_key='url', payload_type=STRING)
    origin = Origin('external_intent', 'intent:' + TARGET, entry='delivery.Target')
    assert values(analysis, origin, 'getStringExtra', (Origin('unknown', 'key'),), 'read') == ()
    assert any(code == 'intent_payload_key_unresolved' for code, _ in analysis.notes)
    conflict = Origin('external_intent', 'intent:' + TARGET, guards=frozenset({('source-method', 2, 8)}))
    assert values(analysis, conflict, 'getStringExtra', (Origin('constant', 'url', value='url'),), 'read') == ()


def test_discovered_explicit_forwarding_to_exported_target_end_to_end():
    source = Method(SOURCE + '->onCreate()V', 'public', 5, 1, [
        I(0, 'invoke-virtual', (4,), ref='Landroid/app/Activity;->getIntent()' + INTENT),
        I(2, 'move-result-object', (0,)),
        I(4, 'invoke-virtual', (0,), ref=INTENT + '->getData()Landroid/net/Uri;'),
        I(6, 'move-result-object', (0,)), I(8, 'new-instance', (1,), literal=INTENT),
        I(10, 'const-class', (2,), literal=TARGET),
        I(12, 'invoke-direct', (1, 4, 2), ref=INTENT + '-><init>(Landroid/content/Context;Ljava/lang/Class;)V'),
        I(14, 'const-string', (2,), literal='android.intent.action.VIEW'),
        I(16, 'invoke-virtual', (1, 2), ref=INTENT + '->setAction(' + STRING + ')' + INTENT),
        I(18, 'move-result-object', (1,)),
        I(20, 'invoke-virtual', (1, 0), ref=INTENT + '->setData(Landroid/net/Uri;)' + INTENT),
        I(22, 'move-result-object', (1,)),
        I(24, 'invoke-virtual', (4, 1), ref='Landroid/app/Activity;->startActivity(' + INTENT + ')V'),
        I(26, 'return-void')])
    target = Method(TARGET + '->onCreate()V', 'public', 2, 1, [
        I(0, 'invoke-virtual', (1,), ref='Landroid/app/Activity;->getIntent()' + INTENT),
        I(2, 'move-result-object', (0,)),
        I(4, 'invoke-virtual', (0,), ref=INTENT + '->getData()Landroid/net/Uri;'),
        I(6, 'move-result-object', (0,)), I(8, 'return-void')])
    analysis = analysis_for(source, target, components=(
        Component('delivery.Source', SOURCE, 'activity', True),
        Component('delivery.Target', TARGET, 'activity', True)))
    analysis.discover_forwarders()
    assert len(analysis.forwarders) == 1
    assert analysis.forwarders[0]['target_class'] == TARGET
    analysis.reset()
    origins = analysis.trace(target.ref, 0, 8)
    assert {o.entry for o in origins} == {'delivery.Source', 'delivery.Target'}


def test_typed_parcelable_getter_does_not_ignore_requested_class():
    analysis, _ = read()
    parcelable = 'Ldelivery/Parcel;'
    analysis.p.supers[parcelable] = 'Landroid/os/Parcelable;'
    analysis.forwarders[0].update(payload='extra', extra_key='url', payload_type=parcelable)
    origin = Origin('external_intent', 'intent:' + TARGET)
    key = (Origin('constant', 'url', value='url'),)
    wanted = (Origin('constant', parcelable, value=parcelable),)
    assert values(analysis, origin, 'getParcelableExtra', key, 'read', wanted)
    wrong = (Origin('constant', 'Ldelivery/OtherParcel;', value='Ldelivery/OtherParcel;'),)
    assert values(analysis, origin, 'getParcelableExtra', key, 'read', wrong) == ()
    assert values(analysis, origin, 'getParcelableExtra', key, 'read', ()) == ()


def test_set_action_preserves_receiver_identity_and_guards_only():
    method = Method('Ldelivery/Factory;->configure(' + INTENT + ')' + INTENT, 'public static', 4, 1,
        [I(0, 'new-instance', (0,), literal=INTENT),
         I(2, 'const-string', (1,), literal='action'),
         I(4, 'invoke-virtual', (3, 1), ref=INTENT + '->setAction(' + STRING + ')' + INTENT),
         I(6, 'move-result-object', (2,)), I(8, 'return-object', (2,))])
    analysis = analysis_for(method)
    original = Origin('allocation', 'actual-intent', typ=INTENT,
                      guards=frozenset({('caller', 1, 2)}), callback_instances=frozenset({'cb'}))
    analysis.context_origins[0] = {3:(original,)}
    result = analysis.trace(method.ref, 2, 8, 'object')
    assert len(result) == 1 and result[0].key == 'actual-intent'
    assert result[0].guards == original.guards
    assert result[0].callback_instances == original.callback_instances
    assert result[0].key != method.ref + '@0000'
    assert not any('validation' in step for step in result[0].path)


@pytest.mark.parametrize('owner,desc', [
    ('Ldelivery/Lookalike;', '(' + STRING + ')' + INTENT),
    (INTENT, '(Ljava/lang/Object;)' + INTENT),
])
def test_set_action_lookalike_or_wrong_descriptor_gets_no_identity_summary(owner, desc):
    method = Method('Ldelivery/Caller;->configure()V', 'public static', 3, 0,
        [I(0, 'new-instance', (0,), literal=owner), I(2, 'const-string', (1,), literal='action'),
         I(4, 'invoke-virtual', (0, 1), ref=owner + '->setAction' + desc),
         I(6, 'move-result-object', (2,)), I(8, 'return-void')])
    analysis = analysis_for(method)
    assert analysis.trace(method.ref, 2, 8, 'object') == ()
