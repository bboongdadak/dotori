from types import SimpleNamespace
from dotori.demand import Backward, Origin
from dotori.model import Program
from dotori.reporting import annotate_paths


def test_null_receiver_does_not_become_webview_identity():
    p=Program('fixture',34,21,[],{}, {}, catalog=SimpleNamespace(inventory=[],call_signatures={},interfaces={}))
    b=Backward(p)
    zero=Origin('constant','0',value='0')
    view=Origin('allocation','exact',typ='Landroid/webkit/WebView;')
    assert b.nonnull_receivers((zero,view),'sink') == (view,)
    assert b.nonnull_receivers((zero,),'sink') == ()
    assert ('null_receiver_alternative_discarded','sink') in b.notes
    assert b.receiver_resolution(()) == 'unresolved'
    assert b.receiver_resolution((view,)) == 'abstract_identity'


def test_value_only_loading_argument_explicitly_requires_receiver_review():
    item={'source':{'path':['input','transform']},'load':{'receiver':[],'receiver_resolution':'unresolved'}}
    annotate_paths({'input_webview_paths':[item]},[],[])
    assert item['review']['receiver_resolution']=='unresolved'
    assert any('non-null WebView receiver is unresolved' in x for x in item['review']['manual_checks'])


def test_lookup_occurrence_is_a_weak_not_allocation_identity():
    p=Program('fixture',34,21,[],{}, {}, catalog=SimpleNamespace(inventory=[],call_signatures={},interfaces={}))
    b=Backward(p)
    lookup=Origin('view_lookup','lookup:call')
    assert b.receiver_resolution((lookup,))=='possible_identity'
    relation=b.object_aliases((lookup,),(lookup,))
    assert relation[0]['relation']=='same_lookup_result_possible_instance'
    assert not b.object_aliases((lookup,),(Origin('view_lookup','lookup:other-call'),))
    item={'source':{'path':['input']},'object_relations':relation}
    annotate_paths({'candidates':[item]},[],[])
    assert item['review']['evidence_level']=='value_path_with_possible_receiver'
    assert any('root/view-tree lifetime' in t for t in item['review']['manual_checks'])


def test_uri_normal_success_assumption_is_explicit_for_analyst():
    item={'source':{'path':['uri_builder_normal_success_assumed']}}
    annotate_paths({'input_webview_paths':[item]},[],[])
    assert any('covering exception handlers' in t for t in item['review']['manual_checks'])


def test_null_load_preserves_argument_evidence_but_is_not_receiver_supported():
    from dotori.model import Method, Instruction as I
    from test_webview_callbacks import catalog_program, ACTIVITY
    method=Method(ACTIVITY+'->onNewIntent(Landroid/content/Intent;)V','public',4,2,[
        I(0,'const/4',(0,),literal=0),
        I(2,'invoke-virtual',(3,),'Landroid/content/Intent;->getDataString()Ljava/lang/String;'),
        I(4,'move-result-object',(1,)),
        I(6,'invoke-virtual',(0,1),'Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V'),
        I(8,'return-void')])
    report=Backward(catalog_program([method])).run()
    assert len(report['input_webview_paths'])==1
    item=report['input_webview_paths'][0]
    assert not item['load']['receiver']
    assert item['review']['receiver_resolution']=='unresolved'
    assert not report['candidates']
    assert any(d['code']=='null_receiver_alternative_discarded' for d in report['diagnostics'])


def test_constructed_callback_capture_is_not_labeled_as_registration():
    from dotori.model import Method, Instruction as I
    from test_webview_callbacks import catalog_program, ACTIVITY
    owner='Lcallbacktest/Capture;'
    ctor=Method(owner+'-><init>()V','public constructor',1,1,[I(0,'return-void')])
    callback=Method(owner+'->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;','public',2,2,[I(0,'return-object',(1,))])
    factory=Method(ACTIVITY+'->make()V','public static',1,0,[
        I(0,'new-instance',(0,),literal=owner),I(2,'invoke-direct',(0,),ctor.ref),I(4,'return-void')])
    b=Backward(catalog_program([ctor,callback,factory]))
    origins=b.trace(callback.ref,0,0,'object')
    assert origins and all(any('constructed_callback_dispatch_unproven:' in p for p in a.path) for a in origins)
    assert not any('callback_registered:' in p for a in origins for p in a.path)
    item={'source':origins[0].dump()}
    annotate_paths({'input_webview_paths':[item]},[],[])
    assert any('does not establish callback registration' in p for p in item['review']['manual_checks'])


def test_receiver_from_incompatible_branch_does_not_support_input_path():
    from dotori.model import Method, Instruction as I
    from test_webview_callbacks import catalog_program, ACTIVITY
    method=Method(ACTIVITY+'->onNewIntent(Landroid/content/Intent;)V','public',5,2,[
        I(0,'if-eqz',(4,),target=10),
        I(2,'invoke-virtual',(4,),'Landroid/content/Intent;->getDataString()Ljava/lang/String;'),
        I(4,'move-result-object',(1,)),I(6,'goto',target=14),
        I(10,'new-instance',(0,),literal='Landroid/webkit/WebView;'),
        I(12,'const-string',(1,),literal='https://safe.invalid'),
        I(14,'invoke-virtual',(0,1),'Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V'),
        I(16,'return-void')])
    report=Backward(catalog_program([method])).run()
    assert len(report['input_webview_paths'])==1
    assert not report['input_webview_paths'][0]['load']['receiver']
    assert report['input_webview_paths'][0]['review']['receiver_resolution']=='unresolved'


def test_bridge_object_from_exclusive_source_branch_is_not_exposed_on_path():
    from dotori.model import Method, Instruction as I
    from test_webview_callbacks import catalog_program, ACTIVITY
    from dotori.demand import JS, WV
    bridge='Lbranchproof/Bridge;'
    surface=Method(bridge+'->ping()V','public',1,1,[I(0,'return-void')],annotations=(JS,))
    m=Method(ACTIVITY+'->onNewIntent(Landroid/content/Intent;)V','public',7,2,[
        I(0,'new-instance',(0,),literal=WV),I(2,'const-string',(3,),literal='Native'),
        I(4,'if-eqz',(6,),target=14),
        I(6,'invoke-virtual',(6,),'Landroid/content/Intent;->getDataString()Ljava/lang/String;'),
        I(8,'move-result-object',(1,)),I(10,'const/4',(2,),literal=0),I(12,'goto',target=18),
        I(14,'new-instance',(2,),literal=bridge),I(16,'const-string',(1,),literal='https://safe.invalid'),
        I(18,'invoke-virtual',(0,2,3),WV+'->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V'),
        I(20,'invoke-virtual',(0,1),WV+'->loadUrl(Ljava/lang/String;)V'),I(22,'return-void')])
    r=Backward(catalog_program([m,surface],supers={bridge:'Ljava/lang/Object;'})).run()
    assert r['input_webview_paths']
    assert not r['candidates']


def test_allocation_from_unproven_field_owner_is_only_possible_identity():
    from dotori.model import Method, Instruction as I
    from test_context_identity import analysis_for
    from dotori.demand import WV
    owner='Lownerproof/Wrapper;';field=owner+'->view'+WV
    writer=Method(owner+'->setup()V','public',2,1,[
        I(0,'new-instance',(0,),literal=WV),I(2,'iput-object',(0,1),field),I(4,'return-void')])
    reader=Method(owner+'->read()'+WV,'public',2,1,[I(0,'iget-object',(0,1),field),I(2,'return-object',(0,))])
    a=analysis_for(writer,reader)
    values=a.trace(reader.ref,0,2,'object')
    assert values and a.receiver_resolution(values)=='possible_identity'
    assert all(any('field_owner_instance_unproven:' in s for s in v.path) for v in values)
    assert a.object_aliases(values,values)[0]['relation']=='same_field_slot_possible_instance'
    item={'source':{'path':['input']},'load':{'receiver':[v.dump() for v in values],'receiver_resolution':a.receiver_resolution(values)}}
    annotate_paths({'input_webview_paths':[item]},[],[])
    assert item['review']['evidence_level']=='value_path_with_possible_receiver'
    assert any('same runtime owner instance' in s for s in item['review']['manual_checks'])
