from dotori.demand import Backward, WV, JS, compatible, Origin
from dotori.model import Instruction as I, Method
from test_webview_callbacks import catalog_program, ACTIVITY


def program(register_first):
    owner='Ltuple/Panel;';field=owner+'->web'+WV;bridge='Ltuple/Bridge;'
    init=Method(owner+'->prepare()V','private',2,1,[I(0,'new-instance',(0,),literal=WV),I(2,'iput-object',(0,1),field),I(4,'return-void')])
    ctor=Method(owner+'-><init>()V','public constructor',1,1,[I(0,'invoke-direct',(0,),init.ref),I(2,'return-void')])
    load=Method(owner+'->show(Ljava/lang/String;)V','public',3,2,[I(0,'iget-object',(0,1),field),I(2,'invoke-virtual',(0,2),WV+'->loadUrl(Ljava/lang/String;)V'),I(4,'return-void')])
    exposure=Method(bridge+'->ping()V','public',1,1,[I(0,'return-void')],annotations=(JS,))
    entry=Method(ACTIVITY+'->onNewIntent(Landroid/content/Intent;)V','public',8,2,[
        I(0,'new-instance',(0,),literal=owner),I(2,'invoke-direct',(0,),ctor.ref),
        I(4,'new-instance',(1,),literal=owner),I(6,'invoke-direct',(1,),ctor.ref),
        I(8,'iget-object',(2,0 if register_first else 1),field),I(10,'new-instance',(3,),literal=bridge),
        I(12,'const-string',(4,),literal='Native'),I(14,'invoke-virtual',(2,3,4),WV+'->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V'),
        I(16,'invoke-virtual',(7,),'Landroid/content/Intent;->getDataString()Ljava/lang/String;'),I(18,'move-result-object',(5,)),
        I(20,'invoke-virtual',(0,5),load.ref),I(22,'const-string',(5,),literal='https://fixed.invalid'),I(24,'invoke-virtual',(1,5),load.ref),I(26,'return-void')])
    return catalog_program([init,ctor,load,exposure,entry],supers={owner:'Ljava/lang/Object;',bridge:'Ljava/lang/Object;'})


def test_same_call_tuple_recovers_owned_helper_webview():
    r=Backward(program(True)).run()
    assert r['candidates']
    c=r['candidates'][0]
    assert c['source']['invocation_choices']
    assert c['load']['receiver_resolution']=='abstract_identity'
    assert any(':owned_initializer_field:' in s for v in c['load']['receiver'] for s in v['path'])


def test_second_call_receiver_cannot_use_first_calls_input():
    r=Backward(program(False)).run()
    assert r['input_webview_paths']
    assert not r['candidates']


def test_invocation_constraints_remain_in_origin_dump():
    a=Origin('external_value','value',path=('call_tuple:["method","one"]',))
    b=Origin('allocation','view',path=('call_tuple:["method","two"]',))
    assert not compatible(a,b)
    assert a.dump()['invocation_choices']==[['method','one']]
