from pathlib import Path
from types import SimpleNamespace
import struct
import pytest
from dotori.model import Program,Method,Instruction as I
from dotori.demand import Backward
from dotori.index import CompactDex,sleb

def test_signed_leb_handlers():
    assert sleb(bytes([0x7f]),0)==(-1,1)
    assert sleb(bytes([0x80,0x7f]),0)==(-128,2)
    assert sleb(bytes([0]),0)==(0,1)

def test_dex_try_handler_units_padding_and_catchall():
    d=CompactDex.__new__(CompactDex);d.types=['Ljava/lang/Exception;']
    code=4;size=5
    # code_item + odd instruction count + padding + try + list size,
    # -1 typed handler count means one typed handler followed by catch-all.
    d.data=b'\0'*code+struct.pack('<4H2I',2,1,1,1,0,size)+b'\0'*(2*size)+b'\0\0'+struct.pack('<IHH',0,2,1)+bytes([1,0x7f,0,3,4])
    assert d.exception_handlers(code)==((0,4,6,'Ljava/lang/Exception;'),(0,4,8,'*'))

def test_exception_edge_uses_pre_instruction_value():
    ref='Llab/Failure;->run(Ljava/lang/String;)V'
    ins=[I(0,'const-string',(0,),literal='before'),I(2,'iget-object',(0,1),'Llab/Failure;->textLjava/lang/String;'),I(4,'const-string',(0,),literal='after'),I(6,'return-void'),I(8,'move-exception',(2,)),I(10,'return-object',(0,))]
    m=Method(ref,'public static',3,1,ins,has_exceptions=True,exception_handlers=((2,4,8,'Ljava/lang/Exception;'),))
    cat=SimpleNamespace(inventory=[],call_signatures={},interfaces={})
    b=Backward(Program('lab',34,21,[],{ref:m},{},catalog=cat))
    definitions=b.definitions(ref,0,10)
    assert [(i.offset,i.literal) for i,_ in definitions]==[(0,'before')]
    assert any(owner.endswith(':exception') for _,guards in definitions for owner,_,_ in guards)
    assert b.reachable(ref,10)

def test_binary_catch_keeps_bridge_parameter_and_real_receiver():
    from dotori.apk import load_apk
    program=load_apk(Path(__file__).parent/'protocol_fixture'/'cases.apk')
    method=program.methods['Llab/Protocol;->caughtScript(Ljava/lang/String;)V']
    assert method.has_exceptions and method.exception_handlers
    report=Backward(program).run()
    path=next(p for p in report['bridge_javascript_paths'] if 'caughtScript' in p['bridge_method'])
    assert path['source']['kind']=='bridge_parameter'
    assert path['object_relations']
    assert any(g[0].endswith(':exception') for g in path['source']['branch_choices'])
    assert 'exception_type_feasibility_unresolved' in {d['code'] for d in report['diagnostics']}

def test_text_report_keeps_exception_edges_and_bridge_surface():
    from dotori.apk import load_apk
    from dotori.cli import text_report
    program=load_apk(Path(__file__).parent/'protocol_fixture'/'cases.apk')
    text=text_report(Backward(program).run())
    assert 'Exceptional edge: Llab/Protocol;->caughtScript' in text
    assert 'Source kind: bridge_parameter' in text
    assert 'Exposed bridge method: Llab/Protocol;->caughtScript' in text

def test_disconnected_handler_is_not_a_new_parameter_entry():
    ref='Llab/Failure;->run(Ljava/lang/String;)V'
    ins=[I(0,'return-void'),I(2,'move-exception',(0,)),I(4,'return-object',(1,))]
    m=Method(ref,'public static',2,1,ins,has_exceptions=True)
    cat=SimpleNamespace(inventory=[],call_signatures={},interfaces={})
    b=Backward(Program('lab',34,21,[],{ref:m},{},catalog=cat))
    assert b.definitions(ref,1,4)==[]
    assert not b.reachable(ref,4)
