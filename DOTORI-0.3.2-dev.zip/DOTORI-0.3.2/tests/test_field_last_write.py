from dotori.demand import WV
from dotori.model import Method, Instruction as I
from test_context_identity import analysis_for

FIELD='Loverwrite/Owner;->web'+WV


def test_last_local_field_assignment_blocks_stale_receiver():
    m=Method('Loverwrite/Entry;->use()V','public static',4,0,[
        I(0,'new-instance',(0,),literal='Loverwrite/Owner;'),
        I(2,'new-instance',(1,),literal=WV),I(4,'iput-object',(1,0),FIELD),
        I(6,'new-instance',(2,),literal=WV),I(8,'iput-object',(2,0),FIELD),
        I(10,'iget-object',(3,0),FIELD),I(12,'return-object',(3,))])
    a=analysis_for(m)
    expected=a.trace(m.ref,2,10,'object')
    actual=a.trace(m.ref,3,12,'object')
    assert {v.key for v in actual}=={v.key for v in expected}


def test_null_overwrite_does_not_resurrect_old_webview():
    m=Method('Loverwrite/Entry;->use()V','public static',3,0,[
        I(0,'new-instance',(0,),literal='Loverwrite/Owner;'),
        I(2,'new-instance',(1,),literal=WV),I(4,'iput-object',(1,0),FIELD),
        I(6,'const/4',(1,),literal=0),I(8,'iput-object',(1,0),FIELD),
        I(10,'iget-object',(2,0),FIELD),I(12,'return-object',(2,))])
    a=analysis_for(m)
    values=a.trace(m.ref,2,12,'object')
    assert [v.value for v in values]==['0']
    assert a.nonnull_receivers(values,'read')==()


def test_last_write_to_different_owner_does_not_replace_reader_slot():
    m=Method('Loverwrite/Entry;->use()V','public static',5,0,[
        I(0,'new-instance',(0,),literal='Loverwrite/Owner;'),
        I(2,'new-instance',(1,),literal='Loverwrite/Owner;'),
        I(4,'new-instance',(2,),literal=WV),I(6,'iput-object',(2,0),FIELD),
        I(8,'const/4',(3,),literal=0),I(10,'iput-object',(3,1),FIELD),
        I(12,'iget-object',(4,0),FIELD),I(14,'return-object',(4,))])
    a=analysis_for(m)
    assert {v.key for v in a.trace(m.ref,4,14,'object')}=={v.key for v in a.trace(m.ref,2,12,'object')}


def test_unknown_call_does_not_enable_local_strong_update():
    m=Method('Loverwrite/Entry;->use()V','public static',3,0,[
        I(0,'new-instance',(0,),literal='Loverwrite/Owner;'),
        I(2,'new-instance',(1,),literal=WV),I(4,'iput-object',(1,0),FIELD),
        I(6,'invoke-static',(0,),'Lunknown/Helper;->change(Loverwrite/Owner;)V'),
        I(8,'iget-object',(2,0),FIELD),I(10,'return-object',(2,))])
    a=analysis_for(m)
    assert a.last_local_field_value(m,m.instructions[-2],a.trace(m.ref,0,8,'object'),'object',0,0) is None
