"""Build static-only Fragment argument fixtures using the official APKtool jar."""
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).parent / 'fixtures' / 'fragment_arguments'
SMALI = ROOT / 'smali'
SMALI.mkdir(parents=True, exist_ok=True)
(ROOT / 'apktool.yml').write_text((ROOT.parent / 'apktool.yml').read_text())


def write(name, source):
    path = SMALI / (name + '.smali')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(source)


write('fr/Arguments', '''.class public Lfr/Arguments;
.super Landroidx/fragment/app/Fragment;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Landroidx/fragment/app/Fragment;-><init>()V
 return-void
.end method
''')
write('fr/Bridge', '''.class public Lfr/Bridge;
.super Ljava/lang/Object;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 return-void
.end method
.method public call()V
 .registers 1
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 return-void
.end method
''')
write('fr/ArgumentHelper', '''.class public Lfr/ArgumentHelper;
.super Ljava/lang/Object;
.method public static set(Landroidx/fragment/app/Fragment;Landroid/os/Bundle;)V
 .registers 2
 invoke-virtual {p0,p1},Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V
 return-void
.end method
''')
manifest = ['''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dotori.fragments">
<uses-sdk android:minSdkVersion="21" android:targetSdkVersion="34"/>
<application android:label="Fragment argument regression cases">''']
for name in ('Exact', 'Helper', 'WrongFragment', 'WrongBundle', 'WrongKey', 'Overwritten', 'AfterSetMutated'):
    source = f'''.class public Lfr/{name};
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 9
 new-instance v0,Landroid/webkit/WebView;
 invoke-direct {{v0,p0}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1,Lfr/Bridge;
 invoke-direct {{v1}},Lfr/Bridge;-><init>()V
 const-string v2,"Native"
 invoke-virtual {{v0,v1,v2}},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 new-instance v3,Lfr/Arguments;
 invoke-direct {{v3}},Lfr/Arguments;-><init>()V
 new-instance v4,Lfr/Arguments;
 invoke-direct {{v4}},Lfr/Arguments;-><init>()V
 new-instance v5,Landroid/os/Bundle;
 invoke-direct {{v5}},Landroid/os/Bundle;-><init>()V
 new-instance v8,Landroid/os/Bundle;
 invoke-direct {{v8}},Landroid/os/Bundle;-><init>()V
 invoke-virtual {{p0}},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v6
 invoke-virtual {{v6}},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v6
 const-string v7,"url"
 invoke-virtual {{v5,v7,v6}},Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
'''
    if name == 'Overwritten':
        source += ''' const-string v6,"https://trusted.invalid"
 invoke-virtual {v5,v7,v6},Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
'''
    if name == 'Helper':
        source += ' invoke-static {v3,v5},Lfr/ArgumentHelper;->set(Landroidx/fragment/app/Fragment;Landroid/os/Bundle;)V\n'
    else:
        source += ' invoke-virtual {' + ('v4' if name == 'WrongFragment' else 'v3') + ',' + ('v8' if name == 'WrongBundle' else 'v5') + '},Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V\n'
    if name == 'AfterSetMutated':
        source += ''' const-string v6,"https://trusted.invalid"
 invoke-virtual {v5,v7,v6},Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
'''
    source += ''' invoke-virtual {v3},Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;
 move-result-object v8
'''
    if name == 'WrongKey':
        source += ' const-string v7,"other"\n'
    source += ''' invoke-virtual {v8,v7},Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
 move-result-object v6
 invoke-virtual {v0,v6},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
'''
    write('fr/' + name, source)
    manifest.append(f'<activity android:name="fr.{name}" android:exported="true"/>')
manifest.append('</application></manifest>')
(ROOT / 'AndroidManifest.xml').write_text('\n'.join(manifest))
if len(sys.argv) > 1:
    output = ROOT.parent / 'fragment_arguments.apk'
    subprocess.run(['java', '-jar', sys.argv[1], 'b', str(ROOT), '-o', str(output)], check=True)
    with tempfile.TemporaryDirectory(prefix='dotori-fragment-build-') as tmp:
        tmp = Path(tmp)
        with zipfile.ZipFile(sys.argv[1]) as archive:
            aapt = tmp / 'aapt2'
            aapt.write_bytes(archive.read('prebuilt/linux/aapt2_64'))
            aapt.chmod(0o755)
            framework = tmp / 'android-framework.jar'
            framework.write_bytes(archive.read('prebuilt/android-framework.jar'))
        packed = tmp / 'manifest.apk'
        subprocess.run([str(aapt), 'link', '--manifest', str(ROOT / 'AndroidManifest.xml'),
                        '-I', str(framework), '-o', str(packed)], check=True)
        with zipfile.ZipFile(output) as archive:
            files = {name: archive.read(name) for name in archive.namelist()}
        with zipfile.ZipFile(packed) as archive:
            files['AndroidManifest.xml'] = archive.read('AndroidManifest.xml')
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name, content in files.items():
                archive.writestr(name, content)
