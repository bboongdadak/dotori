"""Compile exact local registry/metadata/Intent cases without running an APK."""
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT=Path(__file__).parent/'fixtures'/'keyed_maps'
SMALI=ROOT/'smali'
SMALI.mkdir(parents=True,exist_ok=True)
(ROOT/'apktool.yml').write_text((ROOT.parent/'apktool.yml').read_text())

def write(name,source):
    path=SMALI/(name+'.smali');path.parent.mkdir(parents=True,exist_ok=True);path.write_text(source)

write('mp/Route','''.class public Lmp/Route;
.super Ljava/lang/Object;
.field public destination:Ljava/lang/Class;
.method public constructor <init>(Ljava/lang/Class;)V
 .registers 2
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 iput-object p1,p0,Lmp/Route;->destination:Ljava/lang/Class;
 return-void
.end method
''')
write('mp/Opaque','''.class public Lmp/Opaque;
.super Ljava/lang/Object;
.method public static modify(Ljava/util/Map;)V
 .registers 1
 return-void
.end method
''')
write('mp/Bridge','''.class public Lmp/Bridge;
.super Ljava/lang/Object;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 return-void
.end method
.method public call()V
 .registers 1
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 return-void
.end method
''')
manifest=['''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dotori.maps">
<uses-sdk android:minSdkVersion="21" android:targetSdkVersion="34"/>
<application android:label="Map route regression cases">''']
for name in ('Exact','WrongMap','WrongKey','Replaced','Removed','Cleared','Escaped'):
    source=f'''.class public Lmp/{name};
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 7
 new-instance v0,Ljava/util/HashMap;
 invoke-direct {{v0}},Ljava/util/HashMap;-><init>()V
 new-instance v1,Ljava/util/HashMap;
 invoke-direct {{v1}},Ljava/util/HashMap;-><init>()V
 new-instance v2,Lmp/Route;
 const-class v3,Lmp/Target;
 invoke-direct {{v2,v3}},Lmp/Route;-><init>(Ljava/lang/Class;)V
 const-string v3,"/screen"
 invoke-interface {{{'v1' if name=='WrongMap' else 'v0'},v3,v2}},Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
'''
    if name=='Replaced':
        source+=''' new-instance v2,Lmp/Route;
 const-class v4,Lmp/Other;
 invoke-direct {v2,v4},Lmp/Route;-><init>(Ljava/lang/Class;)V
 invoke-interface {v0,v3,v2},Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
'''
    if name=='Removed':source+=' invoke-interface {v0,v3},Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;\n'
    if name=='Cleared':source+=' invoke-interface {v0},Ljava/util/Map;->clear()V\n'
    if name=='Escaped':source+=' invoke-static {v0},Lmp/Opaque;->modify(Ljava/util/Map;)V\n'
    if name=='WrongKey':source+=' const-string v3,"/other"\n'
    source+=''' invoke-interface {v0,v3},Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
 move-result-object v2
 check-cast v2,Lmp/Route;
 iget-object v3,v2,Lmp/Route;->destination:Ljava/lang/Class;
 invoke-virtual {p0},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v4
 invoke-virtual {v4},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v4
 new-instance v5,Landroid/content/Intent;
 invoke-direct {v5,p0,v3},Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
 const-string v6,"url"
 invoke-virtual {v5,v6,v4},Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
 invoke-virtual {p0,v5},Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
 return-void
.end method
'''
    write('mp/'+name,source)
    manifest.append(f'<activity android:name="mp.{name}" android:exported="true"/>')
for name in ('Target','Other'):
    write('mp/'+name,f'''.class public Lmp/{name};
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 4
 new-instance v0,Landroid/webkit/WebView;
 invoke-direct {{v0,p0}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1,Lmp/Bridge;
 invoke-direct {{v1}},Lmp/Bridge;-><init>()V
 const-string v2,"Native"
 invoke-virtual {{v0,v1,v2}},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 invoke-virtual {{p0}},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v1
 const-string v2,"url"
 invoke-virtual {{v1,v2}},Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
 move-result-object v3
 invoke-virtual {{v0,v3}},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
''')
    manifest.append(f'<activity android:name="mp.{name}" android:exported="false"/>')
manifest.append('</application></manifest>')
(ROOT/'AndroidManifest.xml').write_text('\n'.join(manifest))
if len(sys.argv)>1:
    output=ROOT.parent/'keyed_maps.apk'
    subprocess.run(['java','-jar',sys.argv[1],'b',str(ROOT),'-o',str(output)],check=True)
    with tempfile.TemporaryDirectory(prefix='dotori-map-build-') as tmp:
        tmp=Path(tmp)
        with zipfile.ZipFile(sys.argv[1]) as archive:
            aapt=tmp/'aapt2';aapt.write_bytes(archive.read('prebuilt/linux/aapt2_64'));aapt.chmod(0o755)
            framework=tmp/'android-framework.jar';framework.write_bytes(archive.read('prebuilt/android-framework.jar'))
        packed=tmp/'manifest.apk'
        subprocess.run([str(aapt),'link','--manifest',str(ROOT/'AndroidManifest.xml'),'-I',str(framework),'-o',str(packed)],check=True)
        with zipfile.ZipFile(output) as archive:files={name:archive.read(name) for name in archive.namelist()}
        with zipfile.ZipFile(packed) as archive:files['AndroidManifest.xml']=archive.read('AndroidManifest.xml')
        with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
            for name,content in files.items():archive.writestr(name,content)
