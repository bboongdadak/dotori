"""Adversarial registration/operand tests, independent of APK fixture labels."""
from collections import defaultdict
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

import pytest

from dotori.demand import Backward, compatible
from dotori.engine import Limits
from dotori.index import API_NAMES, Site
from dotori.model import Component, Instruction as I, Method, Program, split_ref
from dotori.webview_callbacks import CALLBACKS, CLIENT, REQUEST, STRING, WEBVIEW


ACTIVITY = 'Lcallbacktest/Screen;'
CONCRETE = 'Lcallbacktest/NavigationClient;'
BRIDGE = 'Lcallbacktest/Bridge;'


def catalog_program(methods, supers=None):
    by_class = defaultdict(list)
    by_signature = defaultdict(list)
    call_signatures = defaultdict(set)
    callers = defaultdict(list)
    writers = defaultdict(list)
    inventory = []
    for method in methods:
        by_class[method.owner].append(method.ref)
        by_signature[(method.name, method.descriptor)].append(method.ref)
        for instruction in method.instructions:
            if instruction.op.startswith('invoke-'):
                owner, name, descriptor = split_ref(instruction.ref)
                site = Site(method.ref, instruction.offset, instruction.ref, instruction.op)
                call_signatures[(name, descriptor)].add(instruction.ref)
                callers[instruction.ref].append(site)
                if name in API_NAMES:
                    inventory.append(site)
            elif instruction.op.startswith(('iput', 'sput')):
                writers[instruction.ref].append((method.ref, instruction.offset))
    catalog = SimpleNamespace(
        by_class=by_class, by_signature=by_signature, call_signatures=call_signatures,
        callers_of=lambda ref: callers[ref], writers_of=lambda ref: writers[ref],
        literal_users=lambda value: (), field_types={}, interfaces={},
        inventory=inventory, max_cache=256, decoded=len(methods), cache_peak=len(methods))
    return Program('callbacktest', 34, 21,
        [Component('callbacktest.Screen', ACTIVITY, 'activity', True)],
        {method.ref: method for method in methods},
        {ACTIVITY: 'Landroid/app/Activity;', CONCRETE: CLIENT,
         BRIDGE: 'Ljava/lang/Object;', **(supers or {})}, catalog=catalog)


def scenario(*, signature=('shouldOverrideUrlLoading', f'({WEBVIEW}{STRING})Z'),
             register=True, wrong_view=False, conditional=False, fake_owner=False,
             captured=False, wrong_instance=False, cast_client=False):
    name, descriptor = signature
    owner = CONCRETE
    extra = 1 if name == 'onPageStarted' else 0
    formals = 3 + extra
    callback = Method(owner + '->' + name + descriptor, 'public', formals + 2, formals)
    # p0=2, p1=3 and p2=4. Keep locals separate from all formals.
    instructions = []
    def add(op, regs=(), ref='', literal=None, target=None):
        instructions.append(I(len(instructions) * 2, op, regs, ref, literal, target))
    receiver = 3
    if captured:
        add('iget-object', (0, 2), CONCRETE + '->web' + WEBVIEW)
        receiver = 0
    value = 4
    if REQUEST in descriptor:
        add('invoke-interface', (4,), REQUEST + '->getUrl()Landroid/net/Uri;')
        add('move-result-object', (1,))
        add('invoke-virtual', (1,), 'Landroid/net/Uri;->toString()Ljava/lang/String;')
        add('move-result-object', (1,))
        value = 1
    add('invoke-virtual', (receiver, value), WEBVIEW + '->loadUrl(Ljava/lang/String;)V')
    add('const/4', (1,), literal=1)
    add('return' if descriptor.endswith('Z') else 'return-void', (1,) if descriptor.endswith('Z') else ())
    callback.instructions = instructions

    init = Method(CONCRETE + '-><init>(' + (WEBVIEW if captured else '') + ')V',
                  'public constructor', 2 if captured else 1, 2 if captured else 1)
    init.instructions = ([I(0, 'iput-object', (1, 0), CONCRETE + '->web' + WEBVIEW)] if captured else [])
    init.instructions.append(I(2, 'return-void'))
    bridge = Method(BRIDGE + '->call(Ljava/lang/String;)V', 'public', 2, 2,
                    [I(0, 'return-void')], ('Landroid/webkit/JavascriptInterface;',))
    setup = Method(ACTIVITY + '->onCreate(Landroid/os/Bundle;)V', 'public', 10, 2)
    instructions = []
    add('new-instance', (0,), literal=WEBVIEW)
    add('new-instance', (4,), literal=WEBVIEW)
    add('new-instance', (1,), literal=CONCRETE)
    add('invoke-direct', (1, 0) if captured else (1,), init.ref)
    if wrong_instance:
        # The first instance captures the bridge WebView but is unregistered.
        # The actual registered client captures the different, bridge-free view.
        add('new-instance', (5,), literal=CONCRETE)
        add('invoke-direct', (5, 4) if captured else (5,), init.ref)
    if conditional:
        add('if-eqz', (9,), target=100)
    if cast_client:
        add('check-cast', (5 if wrong_instance else 1,), literal=CLIENT)
    if register:
        add('invoke-virtual', (4 if wrong_view else 0, 5 if wrong_instance else 1),
            WEBVIEW + '->setWebViewClient(' + CLIENT + ')V')
    add('new-instance', (2,), literal=BRIDGE)
    add('const-string', (3,), literal='Native')
    add('invoke-virtual', (0, 2, 3), WEBVIEW + '->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V')
    add('return-void')
    if conditional:
        instructions.append(I(100, 'return-void'))
    setup.instructions = instructions
    program = catalog_program([setup, init, callback, bridge],
        {CONCRETE: 'Ljava/lang/Object;'} if fake_owner else None)
    return program, callback, setup


def analyze(program):
    return Backward(program, Limits(max_depth=48, max_steps=100000, timeout_seconds=10)).run()


@pytest.mark.parametrize('signature', [
    ('shouldOverrideUrlLoading', f'({WEBVIEW}{STRING})Z'),
    ('shouldOverrideUrlLoading', f'({WEBVIEW}{REQUEST})Z'),
    ('onPageStarted', f'({WEBVIEW}{STRING}Landroid/graphics/Bitmap;)V'),
    ('onPageFinished', f'({WEBVIEW}{STRING})V'),
])
def test_registered_url_and_request_callbacks_have_navigation_provenance(signature):
    program, callback, setup = scenario(signature=signature, cast_client=True)
    result = analyze(program)
    assert len(result['candidates']) == 1
    candidate = result['candidates'][0]
    assert candidate['source']['kind'] == 'web_navigation'
    assert candidate['source']['entry'] == callback.ref
    assert candidate['source']['callback_instances']
    assert any('callback_registered:' + setup.ref in step for step in candidate['source']['path'])
    assert all('intent:' not in step for step in candidate['source']['path'])
    assert any('OS Intent' in text for text in candidate['assumptions'])
    assert all(relation['relation'] == 'same_abstract_object' for relation in candidate['object_relations'])


@pytest.mark.parametrize('options,diagnostic', [
    ({'register': False}, 'callback_registration_unresolved'),
    ({'conditional': True}, 'conditional_callback_registration'),
    ({'fake_owner': True}, None),
])
def test_unregistered_or_unproven_callbacks_are_not_navigation_sources(options, diagnostic):
    program, _, _ = scenario(**options)
    result = analyze(program)
    assert result['candidates'] == []
    assert not any(path['source']['kind'] == 'web_navigation' for path in result['input_webview_paths'])
    if diagnostic:
        assert diagnostic in {item['code'] for item in result['diagnostics']}


def test_callback_webview_is_the_registered_receiver_not_any_bridge_view():
    program, _, _ = scenario(wrong_view=True)
    result = analyze(program)
    assert result['candidates'] == []
    assert len(result['input_webview_paths']) == 1
    assert result['input_webview_paths'][0]['load']['receiver'][0]['key'].endswith('@0002')


def test_registered_client_capture_is_instance_specific():
    positive, _, _ = scenario(captured=True)
    assert len(analyze(positive)['candidates']) == 1
    negative, _, _ = scenario(captured=True, wrong_instance=True)
    result = analyze(negative)
    assert result['candidates'] == []
    assert result['input_webview_paths']
    assert all(path['load']['receiver'][0]['key'].endswith('@0002') for path in result['input_webview_paths'])


def test_request_accessor_does_not_invent_a_source_for_an_arbitrary_object():
    method = Method('Lcallbacktest/Other;->load(' + REQUEST + ')V', 'public static', 3, 1,
        [I(0, 'new-instance', (0,), literal=WEBVIEW),
         I(2, 'invoke-interface', (2,), REQUEST + '->getUrl()Landroid/net/Uri;'),
         I(4, 'move-result-object', (1,)),
         I(6, 'invoke-virtual', (0, 1), WEBVIEW + '->loadUrl(Ljava/lang/String;)V'),
         I(8, 'return-void')])
    result = analyze(catalog_program([method]))
    assert not result['input_webview_paths']
    assert not result['candidates']


def test_different_registration_tokens_cannot_cross_pair():
    program, callback, setup = scenario()
    instructions = setup.instructions
    setter = next(i for i in instructions if '->setWebViewClient(' in i.ref)
    # Register the same object on a second WebView: source and callback receiver
    # alternatives must retain separate registration provenance.
    instructions.insert(-1, I(40, 'invoke-virtual', (4, 1), setter.ref))
    instructions[-1] = I(42, 'return-void')
    analysis = Backward(program)
    # Rebuild the small index after editing the IR.
    analysis = Backward(catalog_program(list(program.methods.values())))
    sources = analysis.parameter(callback, 4, 'value', 0, 1)
    views = analysis.parameter(callback, 3, 'object', 0, 1)
    assert len(sources) == len(views) == 2
    assert sum(compatible(source, view) for source in sources for view in views) == 2


def test_android_callback_signatures_are_exact():
    program, callback, _ = scenario()
    callback.ref = callback.ref.replace(')Z', 'Ljava/lang/Object;)Z')
    # A lookalike overload has no Android framework source semantics.
    assert (callback.name, callback.descriptor) not in CALLBACKS


def test_binary_callback_registration_counterexamples():
    from dotori.apk import load_apk
    program = load_apk(Path(__file__).parent / 'fixtures' / 'webview-callbacks.apk')
    result = analyze(program)
    found = {item['source']['entry'].split(';->', 1)[0].rsplit('/', 1)[-1]
             for item in result['candidates']}
    assert found == {'RegisteredClient', 'RequestClient', 'PageStartedClient',
                     'PageFinishedClient', 'CapturedClient', 'SymbolicClient'}
    assert all(item['source']['kind'] == 'web_navigation' for item in result['candidates'])
    assert all(item['source']['callback_instances'] for item in result['candidates'])
    conditional = next(item for item in result['seed_coverage'] if '/ConditionalClient;' in item['site'])
    assert 'conditional_callback_registration' in conditional['diagnostic_codes']
    assert not {'WrongViewClient', 'WrongInstanceClient', 'UnregisteredClient',
                'ConditionalClient', 'SymbolicWrongViewClient'} & found


def constructor_scenario(*, other_bridge_view=False, separate_constructor=False):
    program, callback, setup = scenario()
    custom = 'Lcallbacktest/CustomView;'
    constructor = replace(setup, ref=custom + '-><init>(Landroid/content/Context;)V',
                          access='public constructor')
    constructor.instructions = []
    bridge_call = None
    for instruction in setup.instructions:
        if instruction.offset == 0:  # The WebView is constructor p0 itself.
            continue
        if '->setWebViewClient(' in instruction.ref:
            instruction = replace(instruction, regs=(8, instruction.regs[1]))
        if '->addJavascriptInterface(' in instruction.ref:
            instruction = replace(instruction, regs=(4 if other_bridge_view else 8,) + instruction.regs[1:])
            bridge_call = instruction
            if separate_constructor:
                continue
        constructor.instructions.append(instruction)
    methods = [m for m in program.methods.values() if m.ref != setup.ref] + [constructor]
    if separate_constructor:
        # Another overload's p0 is not evidence for the registering overload.
        other = replace(constructor, ref=custom + '-><init>(Landroid/content/Context;I)V',
                        registers=11, ins_size=3,
                        instructions=[i for i in constructor.instructions
                                      if i.op.startswith('new-instance') or i.op.startswith('const-string')]
                                     + [bridge_call, I(80, 'return-void')])
        methods.append(other)
    return catalog_program(methods, {custom: WEBVIEW}), callback, constructor


def test_unbound_custom_view_constructor_identity_is_explicitly_symbolic():
    program, _, _ = constructor_scenario()
    result = analyze(program)
    assert len(result['candidates']) == 1
    candidate = result['candidates'][0]
    assert candidate['object_relations'][0]['relation'] == 'same_constructor_receiver_possible_instance'
    assert candidate['review']['evidence_level'] == 'value_path_with_possible_receiver'
    assert any('not a recovered allocation' in item for item in candidate['review']['manual_checks'])
    assert candidate['load']['receiver'][0]['kind'] == 'constructor_receiver'


@pytest.mark.parametrize('options', [{'other_bridge_view': True}, {'separate_constructor': True}])
def test_symbolic_constructor_identity_never_crosses_objects_or_overloads(options):
    program, _, _ = constructor_scenario(**options)
    assert analyze(program)['candidates'] == []


def test_two_real_constructor_calls_do_not_collapse_into_a_symbolic_this():
    program, _, constructor = constructor_scenario()
    factory = Method('Lcallbacktest/Factory;->build()V', 'public static', 2, 0, [
        I(0, 'new-instance', (0,), literal=constructor.owner),
        I(2, 'const/4', (1,), literal=0),
        I(4, 'invoke-direct', (0, 1), constructor.ref),
        I(6, 'new-instance', (0,), literal=constructor.owner),
        I(8, 'invoke-direct', (0, 1), constructor.ref), I(10, 'return-void')])
    program = catalog_program(list(program.methods.values()) + [factory],
                              {constructor.owner: WEBVIEW})
    analysis = Backward(program)
    setter = next(i for i in constructor.instructions if '->setWebViewClient(' in i.ref)
    origins = analysis.trace(constructor.ref, 8, setter.offset, 'object')
    assert len({origin.key for origin in origins}) == 2
    assert all(origin.kind == 'allocation' for origin in origins)
    result = analyze(program)
    assert all(origin['kind'] != 'constructor_receiver'
               for registration in result['bridge_registrations'] for origin in registration['receiver'])


def test_symbolic_constructor_context_keys_are_deterministic_and_distinct():
    from dotori.webview_callbacks import constructor_receiver
    program, _, constructor = constructor_scenario()
    analysis = Backward(program)
    setter = next(i for i in constructor.instructions if '->setWebViewClient(' in i.ref)
    origins = analysis.trace(constructor.ref, 8, setter.offset, 'object')
    analysis.context_tokens[1] = 'one'
    analysis.context_tokens[2] = 'two'
    first = constructor_receiver(analysis, constructor, 8, setter.offset, origins, 1)
    second = constructor_receiver(analysis, constructor, 8, setter.offset, origins, 2)
    assert first[0].key != second[0].key


@pytest.mark.parametrize('overrides', [False, True])
def test_registered_concrete_client_dispatch_selects_the_actual_override(overrides):
    program, callback, setup = scenario(cast_client=True)
    child = 'Lcallbacktest/ChildClient;'
    setup.instructions = [replace(i, literal=child) if i.op == 'new-instance' and i.literal == CONCRETE
                          else i for i in setup.instructions]
    methods = list(program.methods.values())
    if overrides:
        methods.append(Method(child + '->' + callback.name + callback.descriptor,
            'public', 4, 3, [I(0, 'const/4', (0,), literal=0), I(2, 'return', (0,))]))
    program = catalog_program(methods, {child: CONCRETE})
    result = analyze(program)
    assert bool(result['candidates']) is not overrides

def test_prior_branch_preserves_registration_guards_without_blocking_local_client():
    program,_,setup=scenario()
    shifted=[replace(i,offset=i.offset+8 if i.offset>=4 else i.offset) for i in setup.instructions]
    setup.instructions=shifted[:2]+[I(4,'if-eqz',(9,),target=12),I(6,'nop'),I(8,'goto',target=12),I(10,'nop')]+shifted[2:]
    result=analyze(catalog_program(list(program.methods.values())))
    assert result['candidates']
    assert result['candidates'][0]['source']['branch_choices']
    assert 'callback_registration_guarded' in {d['code'] for d in result['diagnostics']}


def test_opposite_registration_and_bridge_branches_do_not_pair():
    program,_,setup=scenario()
    init=CONCRETE+'-><init>()V'
    setup.instructions=[I(0,'new-instance',(0,),literal=WEBVIEW),I(2,'if-eqz',(9,),target=100),
        I(4,'new-instance',(1,),literal=CONCRETE),I(6,'invoke-direct',(1,),init),
        I(8,'invoke-virtual',(0,1),WEBVIEW+'->setWebViewClient('+CLIENT+')V'),I(10,'return-void'),
        I(100,'new-instance',(2,),literal=BRIDGE),I(102,'const-string',(3,),literal='Native'),
        I(104,'invoke-virtual',(0,2,3),WEBVIEW+'->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V'),I(106,'return-void')]
    result=analyze(catalog_program(list(program.methods.values())))
    assert result['input_webview_paths']
    assert result['input_webview_paths'][0]['source']['branch_choices']
    assert result['candidates']==[]


def test_later_client_replacement_does_not_preserve_old_dispatch():
    program,_,setup=scenario()
    end=setup.instructions[-1].offset
    setup.instructions=setup.instructions[:-1]+[I(end,'const/4',(1,),literal=0),
        I(end+2,'invoke-virtual',(0,1),WEBVIEW+'->setWebViewClient('+CLIENT+')V'),I(end+4,'return-void')]
    result=analyze(catalog_program(list(program.methods.values())))
    assert result['candidates']==[]
    assert 'callback_replacement_unresolved' in {d['code'] for d in result['diagnostics']}
