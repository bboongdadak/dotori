"""Small IR regressions for call-context-sensitive allocation identity."""
from collections import defaultdict
from types import SimpleNamespace

from dotori.demand import Backward, INTENT, WV
from dotori.engine import Limits
from dotori.index import Site
from dotori.model import Component, Instruction as I, Method, Program, split_ref


def analysis_for(*methods, components=()):
    callers=defaultdict(list);writers=defaultdict(list);by_class=defaultdict(list)
    signatures=defaultdict(list);by_signature=defaultdict(list)
    for method in methods:
        owner,name,desc=split_ref(method.ref)
        by_class[owner].append(method.ref);by_signature[name,desc].append(method.ref)
        for instruction in method.instructions:
            if instruction.op.startswith('invoke-'):
                callers[instruction.ref].append(Site(method.ref,instruction.offset,instruction.ref,instruction.op))
                _,name,desc=split_ref(instruction.ref)
                if instruction.ref not in signatures[name,desc]:signatures[name,desc].append(instruction.ref)
            if instruction.op.startswith(('iput','sput')):
                writers[instruction.ref].append((method.ref,instruction.offset))
    catalog=SimpleNamespace(inventory=[],interfaces={},call_signatures=signatures,
        callers_of=lambda ref:callers[ref],writers_of=lambda ref:writers[ref],
        by_class=by_class,by_signature=by_signature,field_types={})
    program=Program('ctx',None,None,list(components),{m.ref:m for m in methods},{},catalog=catalog)
    return Backward(program,Limits(max_depth=48,max_steps=100000,timeout_seconds=60))


def make_factory(typ=WV):
    return Method('Lctx/Factory;->make()'+typ,'public static',1,0,[
        I(0,'new-instance',(0,),literal=typ),I(2,'return-object',(0,))])


def test_two_calls_to_same_factory_are_different_objects():
    factory=make_factory()
    caller=Method('Lctx/Caller;->use()V','public static',2,0,[
        I(0,'invoke-static',ref=factory.ref),I(2,'move-result-object',(0,)),
        I(4,'invoke-static',ref=factory.ref),I(6,'move-result-object',(1,)),I(8,'return-void')])
    analysis=analysis_for(factory,caller)
    left=analysis.trace(caller.ref,0,8,'object');right=analysis.trace(caller.ref,1,8,'object')
    assert len(left)==len(right)==1
    assert left[0].key!=right[0].key
    assert analysis.object_aliases(left,right)==[]
    assert analysis.object_aliases(left,left)


def test_factory_identity_preserves_outer_call_context():
    factory=make_factory()
    wrapper=Method('Lctx/Wrapper;->make()'+WV,'public static',1,0,[
        I(0,'invoke-static',ref=factory.ref),I(2,'move-result-object',(0,)),I(4,'return-object',(0,))])
    caller=Method('Lctx/Caller;->use()V','public static',2,0,[
        I(0,'invoke-static',ref=wrapper.ref),I(2,'move-result-object',(0,)),
        I(4,'invoke-static',ref=wrapper.ref),I(6,'move-result-object',(1,)),I(8,'return-void')])
    analysis=analysis_for(factory,wrapper,caller)
    assert analysis.trace(caller.ref,0,8,'object')[0].key!=analysis.trace(caller.ref,1,8,'object')[0].key


def test_context_keys_are_stable_across_seed_reset_and_query_order():
    factory=make_factory()
    caller=Method('Lctx/Caller;->use()V','public static',2,0,[
        I(0,'invoke-static',ref=factory.ref),I(2,'move-result-object',(0,)),
        I(4,'invoke-static',ref=factory.ref),I(6,'move-result-object',(1,)),I(8,'return-void')])
    analysis=analysis_for(factory,caller)
    first=[analysis.trace(caller.ref,r,8,'object')[0].key for r in (0,1)]
    analysis.reset()
    second=[analysis.trace(caller.ref,r,8,'object')[0].key for r in (1,0)]
    assert first==list(reversed(second))


def test_identity_return_keeps_the_existing_allocation():
    factory=make_factory()
    identity=Method('Lctx/Identity;->same('+WV+')'+WV,'public static',1,1,[I(0,'return-object',(0,))])
    caller=Method('Lctx/Caller;->use()V','public static',2,0,[
        I(0,'invoke-static',ref=factory.ref),I(2,'move-result-object',(0,)),
        I(4,'invoke-static',(0,),ref=identity.ref),I(6,'move-result-object',(1,)),I(8,'return-void')])
    analysis=analysis_for(factory,identity,caller)
    left=analysis.trace(caller.ref,0,8,'object');right=analysis.trace(caller.ref,1,8,'object')
    assert left[0].key==right[0].key
    assert analysis.object_aliases(left,right)


def test_constructor_capture_uses_its_factory_call_arguments():
    field='Lctx/Box;->valueLjava/lang/String;'
    constructor=Method('Lctx/Box;-><init>(Ljava/lang/String;)V','public constructor',2,2,[
        I(0,'iput-object',(1,0),ref=field),I(2,'return-void')])
    factory=Method('Lctx/Factory;->make(Ljava/lang/String;)Lctx/Box;','public static',2,1,[
        I(0,'new-instance',(0,),literal='Lctx/Box;'),
        I(2,'invoke-direct',(0,1),ref=constructor.ref),I(4,'return-object',(0,))])
    caller=Method('Lctx/Caller;->use()V','public static',5,0,[
        I(0,'const-string',(0,),literal='first'),I(2,'invoke-static',(0,),ref=factory.ref),I(4,'move-result-object',(1,)),
        I(6,'const-string',(0,),literal='second'),I(8,'invoke-static',(0,),ref=factory.ref),I(10,'move-result-object',(2,)),
        I(12,'iget-object',(3,1),ref=field),I(14,'iget-object',(4,2),ref=field),I(16,'return-void')])
    analysis=analysis_for(constructor,factory,caller)
    assert {x.value for x in analysis.trace(caller.ref,3,16)}=={'first'}
    assert {x.value for x in analysis.trace(caller.ref,4,16)}=={'second'}


def test_arrays_from_separate_factory_calls_keep_distinct_identity():
    factory=Method('Lctx/Factory;->make()[Ljava/lang/String;','public static',2,0,[
        I(0,'const/4',(1,),literal=1),I(2,'new-array',(0,1),literal='[Ljava/lang/String;'),I(4,'return-object',(0,))])
    caller=Method('Lctx/Caller;->use()V','public static',2,0,[
        I(0,'invoke-static',ref=factory.ref),I(2,'move-result-object',(0,)),
        I(4,'invoke-static',ref=factory.ref),I(6,'move-result-object',(1,)),I(8,'return-void')])
    analysis=analysis_for(factory,caller)
    assert analysis.trace(caller.ref,0,8,'object')[0].key!=analysis.trace(caller.ref,1,8,'object')[0].key


def test_intent_factory_payloads_do_not_cross_call_contexts():
    factory=Method('Lctx/Factory;->intent(Ljava/lang/String;Ljava/lang/Class;)'+INTENT,'public static',4,2,[
        I(0,'new-instance',(0,),literal=INTENT),I(2,'invoke-direct',(0,),ref=INTENT+'-><init>()V'),
        I(4,'const/4',(1,),literal=0),I(6,'invoke-virtual',(0,1,3),ref=INTENT+'->setClass(Landroid/content/Context;Ljava/lang/Class;)'+INTENT),
        I(8,'const-string',(1,),literal='url'),I(10,'invoke-virtual',(0,1,2),ref=INTENT+'->putExtra(Ljava/lang/String;Ljava/lang/String;)'+INTENT),
        I(12,'return-object',(0,))])
    caller=Method('Lctx/Entry;->use()V','public',5,1,[
        I(0,'invoke-virtual',(4,),ref='Landroid/app/Activity;->getIntent()'+INTENT),I(2,'move-result-object',(0,)),
        I(4,'const-string',(1,),literal='url'),I(6,'invoke-virtual',(0,1),ref=INTENT+'->getStringExtra(Ljava/lang/String;)Ljava/lang/String;'),I(8,'move-result-object',(0,)),
        I(10,'const-class',(1,),literal='Lctx/ExternalTarget;'),I(12,'invoke-static',(0,1),ref=factory.ref),I(14,'move-result-object',(2,)),
        I(16,'const-string',(0,),literal='fixed'),I(18,'const-class',(1,),literal='Lctx/FixedTarget;'),
        I(20,'invoke-static',(0,1),ref=factory.ref),I(22,'move-result-object',(3,)),I(24,'return-void')])
    entry=Component('ctx.Entry','Lctx/Entry;','activity',True)
    analysis=analysis_for(factory,caller,components=(entry,))
    external=analysis.trace(caller.ref,2,24,'object')[0]
    fixed=analysis.trace(caller.ref,3,24,'object')[0]
    assert external.key!=fixed.key
    assert analysis.intent_payloads(factory.ref,{fixed.key},None)==[]
    summaries=analysis.intent_payloads(factory.ref,{external.key,fixed.key},None)
    assert len(summaries)==1
    assert summaries[0]['target_class']=='Lctx/ExternalTarget;'
    assert summaries[0]['extra_key']=='url'
    assert summaries[0]['source']['entry']=='ctx.Entry'
