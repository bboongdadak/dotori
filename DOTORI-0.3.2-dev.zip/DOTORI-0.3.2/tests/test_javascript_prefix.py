from types import SimpleNamespace
import pytest
from dotori.model import Program,Method,Instruction as I
from dotori.demand import Backward
from dotori.javascript import javascript_url_evidence

SB='Ljava/lang/StringBuilder;'
REF='Llab/Build;->script(Ljava/lang/String;)V'
def analysis(ins):
    m=Method(REF,'public static',6,1,ins)
    cat=SimpleNamespace(inventory=[],call_signatures={},interfaces={},by_class={},callers_of=lambda ref:[],by_signature={})
    return Backward(Program('lab',34,21,[],{REF:m},{},catalog=cat))

def builder(prefix='javascript:',tail=None):
    ins=[I(0,'new-instance',(0,),literal=SB),I(2,'invoke-direct',(0,),SB+'-><init>()V'),I(4,'const-string',(1,),literal=prefix),I(6,'invoke-virtual',(0,1),SB+'->append(Ljava/lang/String;)Ljava/lang/StringBuilder;'),I(8,'invoke-virtual',(0,5),SB+'->append(Ljava/lang/String;)Ljava/lang/StringBuilder;')]
    if tail:ins.extend(tail)
    ins.extend([I(30,'invoke-virtual',(0,),SB+'->toString()Ljava/lang/String;'),I(32,'move-result-object',(2,)),I(34,'return-void')])
    return ins

@pytest.mark.parametrize('prefix,expected',[('javascript:',True),('JavaScript:invoke(',True),('https://host/?javascript:',False),('notjavascript:',False),('',False)])
def test_prefix_must_be_actual_first_characters(prefix,expected):
    b=analysis(builder(prefix))
    assert bool(javascript_url_evidence(b,REF,2,34)) is expected

@pytest.mark.parametrize('tail',[
    [I(10,'const/4',(3,),literal=0),I(12,'invoke-virtual',(0,3),SB+'->setLength(I)V')],
    [I(10,'invoke-static',(0,),'Llab/Escape;->mutate(Ljava/lang/StringBuilder;)V')],
    [I(10,'if-eqz',(5,),target=30)],
])
def test_mutation_escape_and_condition_do_not_prove_scheme(tail):
    b=analysis(builder(tail=tail))
    assert javascript_url_evidence(b,REF,2,34) is None

def test_unrelated_javascript_constant_does_not_prove_scheme():
    b=analysis([I(0,'const-string',(0,),literal='javascript:'),I(2,'move-object',(2,5)),I(4,'return-void')])
    assert javascript_url_evidence(b,REF,2,4) is None

def test_concat_uses_receiver_prefix_not_argument():
    b=analysis([I(0,'const-string',(0,),literal='javascript:'),I(2,'invoke-virtual',(5,0),'Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;'),I(4,'move-result-object',(2,)),I(6,'return-void')])
    assert javascript_url_evidence(b,REF,2,6) is None

def test_binary_bridge_loadurl_requires_proven_javascript_prefix():
    from pathlib import Path
    from dotori.apk import load_apk
    p=load_apk(Path(__file__).parent/'protocol_fixture'/'cases.apk')
    report=Backward(p).run()
    paths=[p for p in report['bridge_javascript_paths'] if p['javascript_execution']['api']=='loadUrl']
    assert len(paths)==1
    assert paths[0]['bridge_method']=='Llab/Protocol;->execute(Ljava/lang/String;)V'
    assert paths[0]['javascript_execution']['api']=='loadUrl'
    assert paths[0]['javascript_execution']['javascript_scheme_evidence']['proof']=='builder_first_append'
    assert paths[0]['object_relations']
    assert not any('suffixOnly' in p['bridge_method'] for p in paths)
