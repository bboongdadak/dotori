"""Expected outcomes from independent smali programs, through binary APK parsing."""

import json
import xml.etree.ElementTree as ET
from dataclasses import replace
from pathlib import Path

import pytest

from dotori.apk import InputError, load_apk
from dotori.engine import Analyzer, Limits
from dotori.manifest import parse_manifest

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(scope="module")
def program():
    return load_apk(FIXTURES / "cases.apk")


@pytest.fixture(scope="module")
def report(program):
    return Analyzer(program).run()


EXPECTED = json.loads((FIXTURES / "expected.json").read_text())


@pytest.mark.parametrize("entry,expected", EXPECTED.items())
def test_independent_smali_programs(report, entry, expected):
    found = [c for c in report["candidates"] if c["entry_component"] == entry]
    assert bool(found) == expected


def test_multidex_annotations_and_visibility(program, report):
    assert program.dex_count == 2
    c = next(c for c in report["candidates"] if c["entry_component"] == "lab.Direct")
    assert c["bridge"]["exposure"]["methods"] == [
        "Llab/Bridge;->ping(Ljava/lang/String;)Ljava/lang/String;"
    ]
    assert c["load"]["javascript_enabled"] == "true"
    assert c["registration_before_load"]
    assert c["relation"] == "same_abstract_object"
    assert not c["bridge"]["exposure"]["legacy_runtime_possible"]


def test_temporal_and_javascript_conditions(report):
    after = next(
        c
        for c in report["candidates"]
        if c["entry_component"] == "lab.RegisterAfterLoad"
    )
    assert not after["registration_before_load"]
    assert any("reload" in a for a in after["assumptions"])
    disabled = next(
        c
        for c in report["candidates"]
        if c["entry_component"] == "lab.JavaScriptDisabled"
    )
    assert disabled["load"]["javascript_enabled"] == "false"


def test_proof_graph_is_resolvable(report):
    seen = set()

    def visit(ident):
        if ident in seen:
            return
        seen.add(ident)
        assert ident in report["evidence"]
        for p in report["evidence"][ident]["parents"]:
            visit(p)

    for c in report["candidates"]:
        for root in c["evidence_roots"]:
            visit(root)
    kinds = {report["evidence"][ident]["kind"] for ident in seen}
    assert {
        "manifest_entry",
        "external_input",
        "field_write",
        "field_read",
        "argument",
        "return",
        "bridge_registration",
        "webview_loading",
    } <= kinds


def test_legacy_target(program):
    report = Analyzer(replace(program, target_sdk=16, min_sdk=16)).run()
    no_annotation = next(
        c for c in report["candidates"] if c["entry_component"] == "lab.NoAnnotation"
    )
    assert no_annotation["bridge"]["exposure"]["mode"] == "legacy_target_all_public"
    assert "Llab/NoBridge;->hidden()V" in no_annotation["bridge"]["exposure"]["methods"]


def test_modern_target_on_legacy_runtime(program):
    report = Analyzer(replace(program, min_sdk=16)).run()
    c = next(
        c for c in report["candidates"] if c["entry_component"] == "lab.NoAnnotation"
    )
    assert c["bridge"]["exposure"]["methods"] == []
    assert c["bridge"]["exposure"]["legacy_public_methods"]


def test_limits_are_explicit(program):
    report = Analyzer(program, Limits(max_steps=5)).run()
    assert report["status"] == "incomplete"
    assert any(d["code"] == "step_limit" for d in report["diagnostics"])
    assert report["metrics"]["instructions_executed"] <= 5


def test_stable_candidate_ids(program):
    first = Analyzer(program).run()
    second = Analyzer(program).run()
    assert [c["id"] for c in first["candidates"]] == [
        c["id"] for c in second["candidates"]
    ]


def test_manifest_permissions_aliases_and_defaults():
    root = ET.fromstring(
        """<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="p">
      <uses-sdk android:minSdkVersion="16" android:targetSdkVersion="31"/>
      <permission android:name="p.SECRET" android:protectionLevel="signature"/>
      <application android:permission="p.SECRET">
        <activity android:name=".Internal" android:exported="false"/>
        <activity-alias android:name=".Alias" android:targetActivity=".Internal" android:exported="true"/>
        <activity android:name=".Implicit"><intent-filter><action android:name="x"/></intent-filter></activity>
        <provider android:name=".Provider"/>
      </application></manifest>"""
    )
    _, _, _, components, notes = parse_manifest(root)
    alias = components[1]
    assert alias.code_class == "Lp/Internal;"
    assert alias.exported and alias.permission_level == "signature"
    assert not components[-1].exported
    assert notes[0]["code"] == "manifest_installability"


def test_invalid_input(tmp_path):
    p = tmp_path / "bad.apk"
    p.write_bytes(b"bad")
    with pytest.raises(InputError):
        load_apk(p)
    with pytest.raises(InputError, match="size"):
        load_apk(FIXTURES / "cases.apk", 10)


def test_cli_output_and_exit(tmp_path):
    from dotori.cli import main

    out = tmp_path / "out.json"
    txt = tmp_path / "out.txt"
    code = main(
        ["analyze", str(FIXTURES / "cases.apk"), "--engine", "legacy", "-o", str(out), "--text", str(txt)]
    )
    legacy = json.loads(out.read_text())
    assert code == (3 if legacy["status"] == "incomplete" else 0)
    assert legacy["candidates"]
    assert "confirmed vulnerability" in txt.read_text()
    assert (
        main(
            ["analyze", str(FIXTURES / "cases.apk"), "--max-steps", "2", "-o", str(out)]
        )
        == 3
    )
    assert main(["analyze", "missing.apk", "--max-steps", "-2"]) == 2


def test_call_depth_pruning(program):
    report = Analyzer(program, Limits(max_depth=1)).run()
    assert report["status"] == "incomplete"
    assert any(d["code"] == "call_depth_limit" for d in report["diagnostics"])


def test_html_input_and_wide_arguments(report):
    html = next(
        c for c in report["candidates"] if c["entry_component"] == "lab.HtmlInput"
    )
    assert html["load"]["api"] == "loadDataWithBaseURL"
    assert html["load"]["argument_index"] == 1
    assert any(c["entry_component"] == "lab.WideArgument" for c in report["candidates"])


def test_static_initializer_and_inheritance(report):
    singleton = next(
        c for c in report["candidates"] if c["entry_component"] == "lab.StaticBridge"
    )
    assert singleton["bridge"]["bridge_types"] == ["Llab/Bridge;"]
    inherited = next(
        c for c in report["candidates"] if c["entry_component"] == "lab.InheritedBridge"
    )
    assert inherited["bridge"]["exposure"]["methods"] == [
        "Llab/Bridge;->ping(Ljava/lang/String;)Ljava/lang/String;"
    ]


def test_repeated_allocations_and_layout_changes(report):
    assert not any(
        c["entry_component"] in ("lab.RepeatedAllocation", "lab.LayoutChange")
        for c in report["candidates"]
    )


def test_source_parameters_in_receiver_and_service(report):
    for name in ["lab.Receiver", "lab.Service", "lab.OnNewIntent"]:
        c = next(c for c in report["candidates"] if c["entry_component"] == name)
        assert c["sources"]


def test_unknown_calls_do_not_fabricate_return_flow(program):
    methods = dict(program.methods)
    original = methods[
        "Llab/HelperReturn;->identity(Ljava/lang/String;)Ljava/lang/String;"
    ]
    methods[original.ref] = replace(original, instructions=[], access="private native")
    report = Analyzer(replace(program, methods=methods)).run()
    assert report["status"] == "incomplete"
    assert not any(
        c["entry_component"] == "lab.HelperReturn" for c in report["candidates"]
    )
    assert any(d["code"] == "unresolved_method_body" for d in report["diagnostics"])


def test_allocation_bound_reports_incomplete(program):
    report = Analyzer(program, Limits(max_allocations_per_site=1)).run()
    assert report["status"] == "incomplete"
    assert any(
        d["code"] == "allocation_occurrence_limit" for d in report["diagnostics"]
    )


def test_permission_gate_is_preserved(program):
    components = [
        (
            replace(c, permission="lab.SIGNATURE", permission_level="signature")
            if c.name == "lab.Direct"
            else c
        )
        for c in program.components
    ]
    report = Analyzer(replace(program, components=components)).run()
    candidate = next(
        c for c in report["candidates"] if c["entry_component"] == "lab.Direct"
    )
    assert candidate["entry_permission"]["permission_level"] == "signature"
    assert candidate["entry_permission"]["permission"] == "lab.SIGNATURE"


def test_static_annotated_method_is_exposed(report):
    c = next(
        c for c in report["candidates"] if c["entry_component"] == "lab.StaticMethod"
    )
    assert c["bridge"]["exposure"]["methods"] == ["Llab/StaticMethodBridge;->ping()V"]


def test_unknown_target_is_conditional(program):
    report = Analyzer(replace(program, target_sdk=None)).run()
    c = next(
        c for c in report["candidates"] if c["entry_component"] == "lab.NoAnnotation"
    )
    assert (
        c["bridge"]["exposure"]["mode"] == "unknown_target_public_methods_conditional"
    )
