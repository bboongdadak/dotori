"""Constructor capture replay avoids global receiver discovery for known objects."""
from dotori.model import Instruction as I, Method
from test_context_identity import analysis_for

BOX = 'Lcapture/Box;'
FIELD = BOX + '->valueLjava/lang/String;'


def fixture():
    constructor = Method(BOX + '-><init>(Ljava/lang/String;)V', 'public constructor', 2, 2,
        [I(0, 'iput-object', (1, 0), ref=FIELD), I(2, 'return-void')])
    factory = Method('Lcapture/Factory;->make(Ljava/lang/String;)' + BOX,
        'public static', 2, 1, [I(0, 'new-instance', (0,), literal=BOX),
        I(2, 'invoke-direct', (0, 1), ref=constructor.ref), I(4, 'return-object', (0,))])
    getter = Method(BOX + '->get()Ljava/lang/String;', 'public', 2, 1,
        [I(0, 'iget-object', (0, 1), ref=FIELD), I(2, 'return-object', (0,))])
    caller = Method('Lcapture/Caller;->use()V', 'public static', 5, 0, [
        I(0, 'const-string', (0,), literal='first'), I(2, 'invoke-static', (0,), ref=factory.ref),
        I(4, 'move-result-object', (1,)), I(6, 'const-string', (0,), literal='second'),
        I(8, 'invoke-static', (0,), ref=factory.ref), I(10, 'move-result-object', (2,)),
        I(12, 'invoke-virtual', (1,), ref=getter.ref), I(14, 'move-result-object', (3,)),
        I(16, 'invoke-virtual', (2,), ref=getter.ref), I(18, 'move-result-object', (4,)),
        I(20, 'return-void')])
    return constructor, factory, getter, caller


def test_known_capture_does_not_query_unbound_constructor_receiver():
    constructor, factory, getter, caller = fixture()
    analysis = analysis_for(constructor, factory, getter, caller)
    original = analysis.trace
    def guarded_trace(ref, reg, before, mode='value', ctx=0, depth=0):
        assert not (ref == constructor.ref and reg == 0 and ctx == 0), \
            'A known allocation must not expand all constructor receivers'
        return original(ref, reg, before, mode, ctx, depth)
    analysis.trace = guarded_trace
    assert {atom.value for atom in analysis.trace(caller.ref, 3, 20)} == {'first'}
    assert {atom.value for atom in analysis.trace(caller.ref, 4, 20)} == {'second'}


def test_constructor_from_other_allocation_cannot_supply_missing_capture():
    constructor, factory, getter, caller = fixture()
    missing = Method('Lcapture/Caller;->missing()V', 'public static', 2, 0,
        [I(0, 'new-instance', (0,), literal=BOX),
         I(2, 'invoke-virtual', (0,), ref=getter.ref), I(4, 'move-result-object', (1,)),
         I(6, 'return-void')])
    analysis = analysis_for(constructor, factory, getter, caller, missing)
    assert analysis.trace(missing.ref, 1, 6) == ()


def test_unbound_field_reader_still_discovers_compatible_constructor():
    constructor, _, getter, _ = fixture()
    caller = Method('Lcapture/Caller;->make()V', 'public static', 2, 0,
        [I(0, 'new-instance', (0,), literal=BOX), I(2, 'const-string', (1,), literal='direct'),
         I(4, 'invoke-direct', (0, 1), ref=constructor.ref), I(6, 'return-void')])
    analysis = analysis_for(constructor, getter, caller)
    assert {atom.value for atom in analysis.trace(getter.ref, 0, 2)} == {'direct'}


def local_writer_with_global_noise(different_object=False):
    # A global writer with an expensive receiver chain is indexed first.
    noise = Method('Lcapture/Noise;->write()V', 'public static', 24, 0,
        [I(0, 'new-instance', (0,), literal=BOX)] +
        [I(2 * n, 'move-object', (n, n - 1)) for n in range(1, 20)] +
        [I(40, 'const-string', (20,), literal='noise'),
         I(42, 'iput-object', (20, 19), ref=FIELD), I(44, 'return-void')])
    root = Method('Lcapture/Caller;->readLocal()V', 'public static', 4, 0,
        [I(0, 'new-instance', (0,), literal=BOX), I(2, 'new-instance', (3,), literal=BOX),
         I(4, 'const-string', (1,), literal='direct'),
         I(6, 'iput-object', (1, 3 if different_object else 0), ref=FIELD),
         I(8, 'iget-object', (2, 0), ref=FIELD), I(10, 'return-void')])
    analysis = analysis_for(noise, root)
    analysis.per_sink_limit = 8
    return analysis, root


def test_local_writer_is_not_starved_by_global_receiver_search():
    analysis, root = local_writer_with_global_noise()
    assert {atom.value for atom in analysis.trace(root.ref, 2, 10)} == {'direct'}
    # A proved local strong update makes earlier/global writers irrelevant;
    # it need not consume the budget exploring impossible stale definitions.
    assert any(':last_field_write:' in step for atom in analysis.trace(root.ref,2,10) for step in atom.path)
    assert not any(code == 'slice_query_limit' for code, _ in analysis.notes)


def test_local_writer_priority_does_not_merge_other_receiver():
    analysis, root = local_writer_with_global_noise(different_object=True)
    assert analysis.trace(root.ref, 2, 10) == ()


def test_later_local_writer_is_rejected_before_receiver_expansion():
    later = Method('Lcapture/Caller;->later()V', 'public static', 4, 0,
        [I(0, 'new-instance', (0,), literal=BOX),
         I(2, 'iget-object', (1, 0), ref=FIELD), I(4, 'const-string', (2,), literal='later'),
         I(6, 'iput-object', (2, 3), ref=FIELD), I(8, 'return-void')])
    analysis = analysis_for(later)
    original = analysis.trace
    def guarded_trace(ref, reg, before, mode='value', ctx=0, depth=0):
        assert not (ref == later.ref and reg == 3 and before == 6)
        return original(ref, reg, before, mode, ctx, depth)
    analysis.trace = guarded_trace
    assert analysis.trace(later.ref, 1, 4) == ()


def weak_receiver_fixture(wrong_object=False):
    from dotori.demand import Origin
    noise = Method('Lcapture/Noise;->writeWeak(' + BOX + ')V', 'public static', 24, 1,
        [I(0, 'const-string', (0,), literal='weak')] +
        [I(2 * n, 'move-object', (n, n - 1)) for n in range(1, 20)] +
        [I(40, 'iput-object', (19, 23), ref=FIELD), I(42, 'return-void')])
    root = Method('Lcapture/Caller;->readMixed(' + BOX + ')V', 'public static', 5, 1,
        [I(0, 'new-instance', (0,), literal=BOX), I(2, 'new-instance', (3,), literal=BOX),
         I(4, 'const-string', (1,), literal='direct'), I(6, 'iput-object', (1, 0), ref=FIELD),
         I(8, 'iget-object', (2, 4), ref=FIELD), I(10, 'return-void')])
    analysis = analysis_for(noise, root)
    weak = tuple(Origin('field_slot', 'slot:' + str(n), typ=BOX) for n in range(31))
    concrete = Origin('allocation', root.ref + ('@0002' if wrong_object else '@0000'), typ=BOX)
    analysis.context_origins[0] = {4:weak + (concrete,), 23:weak}
    analysis.per_sink_limit = 8
    return analysis, root


def test_concrete_field_base_precedes_many_weak_receiver_graphs():
    analysis, root = weak_receiver_fixture()
    assert {atom.value for atom in analysis.trace(root.ref, 2, 10)} == {'direct'}
    assert any(code == 'slice_query_limit' for code, _ in analysis.notes)


def test_concrete_priority_does_not_join_different_objects():
    analysis, root = weak_receiver_fixture(wrong_object=True)
    assert analysis.trace(root.ref, 2, 10) == ()


def test_concrete_priority_does_not_join_incompatible_receiver_guards():
    from dotori.demand import Origin
    writer = Method('Lcapture/Writer;->write(' + BOX + ')V', 'public static', 3, 1,
        [I(0, 'const-string', (0,), literal='guarded'),
         I(2, 'iput-object', (0, 2), ref=FIELD), I(4, 'return-void')])
    reader = Method('Lcapture/Reader;->read(' + BOX + ')' + 'Ljava/lang/String;', 'public static', 2, 1,
        [I(0, 'iget-object', (0, 1), ref=FIELD), I(2, 'return-object', (0,))])
    analysis = analysis_for(writer, reader)
    analysis.context_origins[0] = {2:(Origin('allocation', 'same-box', typ=BOX,
        guards=frozenset({('branch', 2, 4)})),)}
    analysis.context_origins[1] = {1:(Origin('allocation', 'same-box', typ=BOX,
        guards=frozenset({('branch', 2, 8)})),)}
    assert analysis.trace(reader.ref, 0, 2, ctx=1) == ()
