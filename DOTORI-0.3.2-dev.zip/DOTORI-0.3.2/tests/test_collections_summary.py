"""Element selection preserves allocation, index, order and iterator identity."""
from dotori.model import Instruction as I, Method
from dotori.collections_summary import ARRAYLIST, LIST, ITERATOR, OBJECT
from test_state_summaries import analysis_for

ROOT = 'Lcollection/Main;->main()Ljava/lang/Object;'
ADD = ARRAYLIST + f'->add({OBJECT})Z'
GET = LIST + f'->get(I){OBJECT}'
LAST = 'Lkotlin/collections/CollectionsKt;' + f'->last({LIST}){OBJECT}'
ITER = LIST + f'->iterator(){ITERATOR}'
NEXT = ITERATOR + f'->next(){OBJECT}'


def allocate(register=0):
    return [('new-instance', (register,), '', ARRAYLIST),
            ('invoke-direct', (register,), ARRAYLIST + '-><init>()V')]


def append(text, register=0):
    return [('const-string', (1,), '', text), ('invoke-virtual', (register, 1), ADD)]


def read(kind='get', register=0, index=0):
    if kind == 'last':
        rows = [('invoke-static', (register,), LAST)]
    elif kind == 'iterator':
        rows = [('invoke-interface', (register,), ITER), ('move-result-object', (3,)),
                ('invoke-interface', (3,), NEXT)]
    else:
        rows = [('const/4', (2,), '', index), ('invoke-interface', (register, 2), GET)]
    return rows + [('move-result-object', (4,)), ('return-object', (4,))]


def run(rows, *extra, ref=ROOT, ins_size=0, mode='value'):
    instructions = [I(n * 2, *row) for n, row in enumerate(rows)]
    m = Method(ref, 'public static', 10, ins_size, instructions)
    a = analysis_for(m, *extra)
    result = a.trace(ref, instructions[-1].regs[0], instructions[-1].offset, mode)
    return a, result


def values(result):
    return [r.value for r in result]


def test_get_selects_one_exact_element_not_union_of_adds():
    for index, expected in ((0, 'first'), (1, 'second')):
        a, result = run(allocate() + append('first') + append('second') + read(index=index))
        assert values(result) == [expected]
        assert any(s.startswith('collection_constant_index:') for s in result[0].path)
        assert not a.notes


def test_list_instances_do_not_cross_even_when_registers_are_reused():
    a, result = run(allocate() + allocate(5) + append('first') + append('other', 5) + read())
    assert values(result) == ['first']
    a, result = run(allocate() + append('first') + allocate() + append('new') + read())
    assert values(result) == ['new']


def test_last_selects_last_append_only():
    a, result = run(allocate() + append('first') + append('second') + read('last'))
    assert values(result) == ['second']


def test_iterator_selects_first_then_second_without_merging():
    rows = allocate() + append('first') + append('second') + [
        ('invoke-interface', (0,), ITER), ('move-result-object', (3,)),
        ('invoke-interface', (3,), NEXT), ('move-result-object', (4,)),
        ('invoke-interface', (3,), NEXT), ('move-result-object', (4,)), ('return-object', (4,))]
    a, result = run(rows)
    assert values(result) == ['second']
    assert 'collection_iterator_index:1' in result[0].path


def test_two_iterators_keep_independent_positions():
    rows = allocate() + append('first') + append('second') + [
        ('invoke-interface', (0,), ITER), ('move-result-object', (3,)),
        ('invoke-interface', (0,), ITER), ('move-result-object', (5,)),
        ('invoke-interface', (3,), NEXT), ('move-result-object', (4,)),
        ('invoke-interface', (5,), NEXT), ('move-result-object', (4,)), ('return-object', (4,))]
    _, result = run(rows)
    assert values(result) == ['first']


def test_iterator_mutation_and_remove_fail_closed():
    for mutation in append('third') + [] , [('invoke-interface', (3,), ITERATOR+'->remove()V')]:
        rows = allocate() + append('first') + [
            ('invoke-interface', (0,), ITER), ('move-result-object', (3,))] + mutation + [
            ('invoke-interface', (3,), NEXT), ('move-result-object', (4,)), ('return-object', (4,))]
        a, result = run(rows)
        assert result == ()
        assert any(code == 'collection_iterator_mutation_unresolved' for code, _ in a.notes)


def test_constant_set_remove_insert_and_clear_keep_exact_slots():
    set_rows = [('const/4', (2,), '', 0), ('const-string', (1,), '', 'replacement'),
                ('invoke-interface', (0, 2, 1), LIST + f'->set(I{OBJECT}){OBJECT}')]
    _, result = run(allocate() + append('first') + append('second') + set_rows + read())
    assert values(result) == ['replacement']
    remove = [('const/4', (2,), '', 0), ('invoke-interface', (0, 2), LIST+f'->remove(I){OBJECT}')]
    _, result = run(allocate() + append('first') + append('second') + remove + read())
    assert values(result) == ['second']
    insert = [('const/4', (2,), '', 0), ('const-string', (1,), '', 'inserted'),
              ('invoke-interface', (0, 2, 1), LIST+f'->add(I{OBJECT})V')]
    _, result = run(allocate() + append('first') + insert + read(index=1))
    assert values(result) == ['first']
    _, result = run(allocate() + append('first') + [('invoke-interface', (0,), LIST+'->clear()V')] + append('new') + read())
    assert values(result) == ['new']


def test_unknown_mutation_index_is_not_old_value():
    ref = 'Lcollection/Main;->main(I)Ljava/lang/Object;'
    for method in (f'->set(I{OBJECT}){OBJECT}', f'->add(I{OBJECT})V'):
        a, result = run(allocate() + append('first') + [
            ('invoke-interface', (0, 9, 1), LIST+method)] + read(), ref=ref, ins_size=1)
        assert result == ()
        assert any(code == 'collection_index_unresolved' for code, _ in a.notes)


def test_unknown_read_index_does_not_merge_elements():
    ref = 'Lcollection/Main;->main(I)Ljava/lang/Object;'
    a, result = run(allocate() + append('first') + append('second') + [
        ('invoke-interface', (0, 9), GET), ('move-result-object', (4,)), ('return-object', (4,))],
        ref=ref, ins_size=1)
    assert result == ()
    assert any(code == 'collection_index_unresolved' for code, _ in a.notes)


def test_bulk_remove_object_and_unknown_calls_are_gaps():
    for call in (('invoke-interface', (0, 1), LIST+f'->remove({OBJECT})Z'),
                 ('invoke-interface', (0, 1), LIST+'->addAll(Ljava/util/Collection;)Z'),
                 ('invoke-static', (0,), 'Lcollection/Unknown;->escape(Ljava/util/List;)V')):
        a, result = run(allocate() + append('first') + [call] + read())
        assert result == ()
        assert any(code in ('collection_mutation_unresolved', 'collection_escape_unresolved') for code, _ in a.notes)


def test_field_storage_and_self_containment_are_escapes():
    for row in (('sput-object', (0,), 'Lcollection/Holder;->list'+LIST),
                ('invoke-virtual', (0, 0), ADD)):
        a, result = run(allocate() + append('first') + [row] + read())
        assert result == ()
        assert any(code == 'collection_escape_unresolved' for code, _ in a.notes)


def test_conditional_append_and_iterator_loop_are_not_definite_selection():
    for kind in ('get', 'iterator', 'last'):
        rows = allocate() + [('if-eqz', (9,), '', None, 10)] + append('first') + read(kind)
        a, result = run(rows, ref='Lcollection/Main;->main(Z)Ljava/lang/Object;', ins_size=1)
        assert result == ()
        assert any(code == 'collection_control_flow_unresolved' for code, _ in a.notes)


def test_alias_moves_and_casts_preserve_list_identity():
    _, result = run(allocate() + [('move-object', (5, 0)), ('check-cast', (5,), '', LIST)] + append('first', 5) + read(register=5))
    assert values(result) == ['first']


def test_cast_cannot_manufacture_arraylist_identity():
    rows = [('new-instance', (0,), '', 'Ljava/lang/Object;'), ('check-cast', (0,), '', LIST)]
    a, result = run(rows + read())
    assert result == ()
    assert any(code == 'collection_receiver_alias_unresolved' for code, _ in a.notes)


def test_bound_static_writer_and_reader_helpers_preserve_tuple():
    writer = Method('Lcollection/Helper;->add'+f'({LIST}{OBJECT})V', 'public static', 2, 2,
        [I(0, 'invoke-interface', (0, 1), LIST+f'->add({OBJECT})Z'), I(2, 'return-void')])
    reader = Method('Lcollection/Helper;->read'+f'({LIST}){OBJECT}', 'public static', 3, 1,
        [I(0, 'const/4', (0,), literal=0), I(2, 'invoke-interface', (2, 0), GET),
         I(4, 'move-result-object', (1,)), I(6, 'return-object', (1,))])
    _, result = run(allocate() + allocate(5) + [('const-string', (1,), '', 'selected'),
        ('invoke-static', (0, 1), writer.ref), ('const-string', (1,), '', 'other'),
        ('invoke-static', (5, 1), writer.ref), ('invoke-static', (0,), reader.ref),
        ('move-result-object', (4,)), ('return-object', (4,))], writer, reader)
    assert values(result) == ['selected']
    assert any(s.startswith('collection_helper:') for s in result[0].path)


def test_unknown_replacement_value_blocks_earlier_external_value():
    ref = 'Lcollection/Main;->main(Ljava/lang/Object;)Ljava/lang/Object;'
    a, result = run(allocate() + append('first') + [('const/4', (2,), '', 0),
        ('invoke-interface', (0, 2, 9), LIST+f'->set(I{OBJECT}){OBJECT}')] + read(), ref=ref, ins_size=1)
    assert result == ()
    assert any(code == 'collection_value_unresolved' for code, _ in a.notes)


def test_negative_or_out_of_range_index_never_selects_python_negative_index():
    for index in (-1, 1):
        a, result = run(allocate() + append('first') + read(index=index))
        assert result == ()
        assert any(code == 'collection_index_out_of_bounds' for code, _ in a.notes)


def test_empty_last_and_uninitialized_collection_fail_closed():
    for rows in (allocate() + read('last'), [allocate()[0]] + append('first') + read()):
        a, result = run(rows)
        assert result == ()
        assert any(code in ('collection_index_out_of_bounds', 'collection_initialization_unresolved') for code, _ in a.notes)


def test_external_value_and_object_identity_survive_exact_selection():
    from dotori.demand import Origin
    ref = 'Lcollection/Main;->main(Ljava/lang/Object;)Ljava/lang/Object;'
    rows = allocate() + [('invoke-virtual', (0, 9), ADD)] + read()
    m = Method(ref, 'public static', 10, 1, [I(n * 2, *row) for n, row in enumerate(rows)])
    a = analysis_for(m)
    a.context_origins[0] = {9: (Origin('external_value', 'source:test', path=('source',)),)}
    result = a.trace(ref, 4, m.instructions[-1].offset, 'value')
    assert result[0].kind == 'external_value' and result[0].path[0] == 'source'
    _, result = run(allocate() + [('new-instance', (1,), '', 'Landroid/webkit/WebView;'),
        ('invoke-virtual', (0, 1), ADD)] + read(), mode='object')
    assert result[0].kind == 'allocation' and result[0].key == ROOT+'@0004'


def test_binary_fixture_connects_only_the_selected_values_and_receivers():
    from pathlib import Path
    from dotori.apk import load_apk
    from dotori.demand import Backward
    from dotori.engine import Limits
    p = load_apk(Path(__file__).parent / 'fixtures' / 'collections.apk')
    result = Backward(p, Limits(max_depth=64, max_steps=200000, timeout_seconds=30)).run()
    def case(path):
        return path['load']['site'].split('Lcollections/', 1)[1].split(';', 1)[0]
    linked = {case(path) for path in result['input_webview_paths']}
    candidates = {case(path) for path in result['candidates']}
    assert linked == {'GetFirst', 'Last', 'IteratorSecond', 'BoundHelpers', 'ObjectReceiver', 'WrongObjectReceiver'}
    assert candidates == linked - {'WrongObjectReceiver'}
    assert not any(d['code'].endswith(('_limit', '_timeout')) for d in result['diagnostics'])
    assert {'collection_control_flow_unresolved', 'collection_index_unresolved',
            'collection_escape_unresolved', 'collection_iterator_mutation_unresolved'} <= {
                d['code'] for d in result['diagnostics']}


def test_factory_and_field_lifecycle_lists_are_not_unordered_appends():
    factory = Method('Lcollection/Factory;->make()'+LIST, 'public static', 1, 0,
        [I(0, 'new-instance', (0,), literal=ARRAYLIST),
         I(2, 'invoke-direct', (0,), ARRAYLIST+'-><init>()V'), I(4, 'return-object', (0,))])
    a, result = run([('invoke-static', (), factory.ref), ('move-result-object', (0,))] + append('value') + read(), factory)
    assert result == ()
    assert any(code == 'collection_lifecycle_order_unresolved' for code, _ in a.notes)
    field = 'Lcollection/Holder;->list'+LIST
    setup = Method('Lcollection/Holder;->setup()V', 'public static', 1, 0,
        [I(0, 'new-instance', (0,), literal=ARRAYLIST), I(2, 'invoke-direct', (0,), ARRAYLIST+'-><init>()V'),
         I(4, 'sput-object', (0,), field), I(6, 'return-void')])
    a, result = run([('sget-object', (0,), field)] + append('value') + read(), setup)
    assert result == ()
    assert any(code == 'collection_lifecycle_order_unresolved' for code, _ in a.notes)


def test_iterator_bound_reader_keeps_position_and_object():
    helper = Method('Lcollection/Helper;->next'+f'({ITERATOR}){OBJECT}', 'public static', 2, 1,
        [I(0, 'invoke-interface', (1,), NEXT), I(2, 'move-result-object', (0,)), I(4, 'return-object', (0,))])
    _, result = run(allocate() + append('first') + append('second') + [
        ('invoke-interface', (0,), ITER), ('move-result-object', (3,)),
        ('invoke-interface', (3,), NEXT), ('invoke-static', (3,), helper.ref),
        ('move-result-object', (4,)), ('return-object', (4,))], helper)
    assert values(result) == ['second']


def test_helper_dead_code_after_return_cannot_overwrite_selected_element():
    helper = Method('Lcollection/Helper;->dead'+f'({LIST})V', 'public static', 2, 1,
        [I(0, 'return-void'), I(2, 'invoke-interface', (1,), LIST+'->clear()V')])
    _, result = run(allocate() + append('first') + [('invoke-static', (0,), helper.ref)] + read(), helper)
    assert values(result) == ['first']


def test_unmodeled_virtual_helper_and_lookalike_get_have_no_list_summary():
    fake = Method('Lcollection/Fake;->get(I)'+OBJECT, 'public', 3, 2,
        [I(0, 'const-string', (0,), literal='fixed'), I(2, 'return-object', (0,))])
    _, result = run([('new-instance', (0,), '', 'Lcollection/Fake;'), ('const/4', (1,), '', 0),
        ('invoke-virtual', (0, 1), fake.ref), ('move-result-object', (4,)), ('return-object', (4,))], fake)
    assert values(result) == ['fixed']
    assert not any(s.startswith('collection_') for s in result[0].path)


def test_conditional_helper_mutation_and_exception_regions_fail_closed():
    helper = Method('Lcollection/Helper;->conditional'+f'({LIST})V', 'public static', 2, 1,
        [I(0, 'if-eqz', (0,), target=4), I(2, 'invoke-interface', (1,), LIST+'->clear()V'), I(4, 'return-void')])
    a, result = run(allocate() + append('first') + [('invoke-static', (0,), helper.ref)] + read(), helper)
    assert result == ()
    assert any(code == 'collection_control_flow_unresolved' for code, _ in a.notes)
    helper.instructions = [I(0, 'return-void')]
    helper.has_exceptions = True
    a, result = run(allocate() + append('first') + [('invoke-static', (0,), helper.ref)] + read(), helper)
    assert result == ()
    assert any(code == 'collection_control_flow_unresolved' for code, _ in a.notes)
