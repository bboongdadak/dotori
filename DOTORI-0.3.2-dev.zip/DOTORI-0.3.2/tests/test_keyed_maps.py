"""Exact table entries transfer operands; table/API co-occurrence does not."""
from dataclasses import replace

from dotori.demand import Backward
from dotori.engine import Limits
from dotori.keyed_maps import GET, HASHMAP, LINKED, MAP, OBJECT, PUT
from dotori.model import Component, Instruction as I, Method
from test_webview_callbacks import ACTIVITY, BRIDGE, WEBVIEW, catalog_program

STRING='Ljava/lang/String;'
INTENT='Landroid/content/Intent;'
HOLDER='Lmaptest/Metadata;'
TARGET='Lmaptest/Internal;'
OTHER='Lmaptest/Other;'


def scenario(*, wrong_map=False, wrong_key=False, unknown_key=False, integer_key=False,
             overwrite=False, remove=False, clear=False, putall=False,
             escape=False, field_escape=False, conditional=False, fake=False,
             metadata=False, route=False, linked=False, construct=True):
    method=Method(ACTIVITY+'->onCreate(Landroid/os/Bundle;)V','public',12,2)
    ins=[]
    def add(op,regs=(),ref='',literal=None,target=None):
        ins.append(I(len(ins)*2,op,regs,ref,literal,target))
    add('new-instance',(0,),literal=WEBVIEW)
    add('new-instance',(1,),literal=BRIDGE)
    add('const-string',(2,),literal='Native')
    add('invoke-virtual',(0,1,2),WEBVIEW+'->addJavascriptInterface('+OBJECT+STRING+')V')
    impl='Lmaptest/FakeMap;' if fake else LINKED if linked else HASHMAP
    add('new-instance',(3,),literal=impl)
    if construct:add('invoke-direct',(3,),impl+'-><init>()V')
    add('new-instance',(4,),literal=impl)
    add('invoke-direct',(4,),impl+'-><init>()V')
    add('invoke-virtual',(10,),ACTIVITY+'->getIntent()'+INTENT)
    add('move-result-object',(5,))
    add('invoke-virtual',(5,),INTENT+'->getDataString()'+STRING)
    add('move-result-object',(5,))
    add('const-string',(6,),literal='/screen')
    value=5
    init=Method(HOLDER+'-><init>('+OBJECT+')V','public constructor',2,2,
        [I(0,'iput-object',(1,0),HOLDER+'->value'+OBJECT),I(2,'return-void')])
    if route:
        add('const-class',(8,),literal=TARGET)
        value=8
    if metadata or route:
        add('new-instance',(7,),literal=HOLDER)
        add('invoke-direct',(7,value),init.ref)
        value=7
    if integer_key:
        add('const/4',(6,),literal=1)
    if unknown_key:
        add('move-object',(6,5))
    add('invoke-interface',(4 if wrong_map else 3,6,value),MAP+'->put'+PUT)
    if overwrite:
        if route:
            add('const-class',(8,),literal=OTHER)
            add('new-instance',(7,),literal=HOLDER)
            add('invoke-direct',(7,8),init.ref)
            value=7
        else:
            add('const-string',(5,),literal='https://trusted.invalid')
            value=5
        add('invoke-interface',(3,6,value),MAP+'->put'+PUT)
    if remove:add('invoke-interface',(3,6),MAP+'->remove'+GET)
    if clear:add('invoke-interface',(3,),MAP+'->clear()V')
    if putall:add('invoke-interface',(3,4),MAP+'->putAll('+MAP+')V')
    if escape:add('invoke-static',(3,),'Lmaptest/Opaque;->modify('+MAP+')V')
    if field_escape:add('sput-object',(3,),'Lmaptest/State;->map'+MAP)
    if conditional:add('if-eqz',(11,),target=200)
    if wrong_key:add('const-string',(6,),literal='/other')
    if integer_key:add('const-string',(6,),literal='1')
    add('invoke-interface',(3,6),MAP+'->get'+GET)
    add('move-result-object',(8,))
    if metadata or route:
        add('check-cast',(8,),literal=HOLDER)
        add('iget-object',(8,8),HOLDER+'->value'+OBJECT)
    if route:
        add('check-cast',(8,),literal='Ljava/lang/Class;')
        add('new-instance',(7,),literal=INTENT)
        add('invoke-direct',(7,10,8),INTENT+'-><init>(Landroid/content/Context;Ljava/lang/Class;)V')
        add('const-string',(6,),literal='url')
        add('invoke-virtual',(7,6,5),INTENT+'->putExtra('+STRING+STRING+')'+INTENT)
        add('invoke-virtual',(10,7),ACTIVITY+'->startActivity('+INTENT+')V')
    else:
        add('check-cast',(8,),literal=STRING)
        add('invoke-virtual',(0,8),WEBVIEW+'->loadUrl('+STRING+')V')
    add('return-void')
    if conditional:ins.append(I(200,'return-void'))
    method.instructions=ins
    bridge=Method(BRIDGE+'->call()V','public',1,1,[I(0,'return-void')],('Landroid/webkit/JavascriptInterface;',))
    methods=[method,init,bridge]
    if route:
        for target in (TARGET,OTHER):
            methods.append(Method(target+'->onCreate(Landroid/os/Bundle;)V','public',6,2,
                [I(0,'new-instance',(0,),literal=WEBVIEW),I(2,'new-instance',(1,),literal=BRIDGE),
                 I(4,'const-string',(2,),literal='Native'),
                 I(6,'invoke-virtual',(0,1,2),WEBVIEW+'->addJavascriptInterface('+OBJECT+STRING+')V'),
                 I(8,'invoke-virtual',(4,),target+'->getIntent()'+INTENT),I(10,'move-result-object',(1,)),
                 I(12,'const-string',(2,),literal='url'),I(14,'invoke-virtual',(1,2),INTENT+'->getStringExtra('+STRING+')'+STRING),
                 I(16,'move-result-object',(1,)),I(18,'invoke-virtual',(0,1),WEBVIEW+'->loadUrl('+STRING+')V'),I(20,'return-void')]))
    p=catalog_program(methods,{HOLDER:'Ljava/lang/Object;',TARGET:'Landroid/app/Activity;',OTHER:'Landroid/app/Activity;',
                              'Lmaptest/FakeMap;':HASHMAP})
    if route:
        p.components.extend(Component(t[1:-1].replace('/','.'),t,'activity',False) for t in (TARGET,OTHER))
    return p


def analyze(p):
    return Backward(p,Limits(max_depth=64,max_steps=100000,timeout_seconds=10)).run()


def test_exact_local_map_value_and_metadata_field_transfer():
    for kwargs in ({},{'metadata':True},{'linked':True}):
        result=analyze(scenario(**kwargs))
        assert len(result['candidates'])==1
        assert any(s.startswith('map_same_allocation:') for s in result['candidates'][0]['source']['path'])


def test_map_does_not_join_different_map_or_key_or_old_value():
    for kwargs in ({'wrong_map':True},{'wrong_key':True},{'overwrite':True},{'unknown_key':True},
                   {'integer_key':True},{'remove':True},{'clear':True},{'putall':True}):
        assert analyze(scenario(**kwargs))['input_webview_paths']==[], kwargs


def test_unmodeled_map_escapes_and_implementations_stay_unresolved():
    for kwargs in ({'escape':True},{'field_escape':True},{'conditional':True},{'fake':True},{'construct':False}):
        assert analyze(scenario(**kwargs))['input_webview_paths']==[],kwargs


def test_registered_literal_destination_reaches_exact_explicit_intent_target():
    result=analyze(scenario(route=True))
    assert {p['load']['method'].split('->')[0] for p in result['input_webview_paths']}=={TARGET}
    assert any(f.get('target_class')==TARGET for f in result['intent_forwarding_paths'])
    assert not any(f.get('target_class')==OTHER for f in result['intent_forwarding_paths'])


def test_route_overwrite_changes_destination_instead_of_merging_previous_entry():
    result=analyze(scenario(route=True,overwrite=True))
    assert {p['load']['method'].split('->')[0] for p in result['input_webview_paths']}=={OTHER}


def test_missing_route_and_wrong_registry_never_create_intent_delivery():
    for kwargs in ({'wrong_key':True},{'wrong_map':True},{'remove':True},{'clear':True}):
        result=analyze(scenario(route=True,**kwargs))
        assert result['input_webview_paths']==[],kwargs


def test_compiled_registry_map_fixture_connects_only_exact_last_destination():
    from pathlib import Path
    from dotori.apk import load_apk
    result=analyze(load_apk(Path(__file__).parent/'fixtures'/'keyed_maps.apk'))
    pairs={(p['entry_component'],p['load']['method'].split('->')[0]) for p in result['input_webview_paths']}
    assert pairs=={('mp.Exact','Lmp/Target;'),('mp.Replaced','Lmp/Other;')}
    assert len(result['candidates'])==2


def test_forwarding_report_retains_actual_map_destination_operand_proof():
    result=analyze(scenario(route=True))
    record=next(f for f in result['intent_forwarding_paths'] if f.get('target_class')==TARGET)
    assert record['payload_type']==STRING
    assert record['target_evidence']
    evidence=record['target_evidence'][0]
    assert evidence['operand_index']==2
    assert evidence['origin']['value']==TARGET
    assert 'branch_choices' in evidence['origin']
    assert any(s.startswith('map_get_key:/screen:') for s in evidence['origin']['path'])
    assert any(':field_read:' in s for s in evidence['origin']['path'])
