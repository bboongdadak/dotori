from dotori.demand import WV, Origin
from dotori.model import Method, Instruction as I
from test_context_identity import analysis_for

OWNER='Lowned/Holder;';FIELD=OWNER+'->web'+WV


def fixture(invoke=True):
    writer=Method(OWNER+'->initialize()V','private',2,1,[I(0,'new-instance',(0,),literal=WV),I(2,'iput-object',(0,1),FIELD),I(4,'return-void')])
    ctor=Method(OWNER+'-><init>()V','public constructor',1,1,([I(0,'invoke-direct',(0,),writer.ref)] if invoke else [])+[I(2,'return-void')])
    reader=Method(OWNER+'->read()'+WV,'public',2,1,[I(0,'iget-object',(0,1),FIELD),I(2,'return-object',(0,))])
    root=Method('Lowned/Entry;->use()V','public static',3,0,[
        I(0,'new-instance',(0,),literal=OWNER),I(2,'invoke-direct',(0,),ctor.ref),
        I(4,'new-instance',(1,),literal=OWNER),I(6,'invoke-direct',(1,),ctor.ref),
        I(8,'invoke-virtual',(0,),reader.ref),I(10,'move-result-object',(2,)),I(12,'return-void')])
    a=analysis_for(writer,ctor,reader,root);a.p.supers[OWNER]='Landroid/view/View;'
    return a,reader,root


def test_constructor_helper_uses_the_allocated_owner():
    a,reader,root=fixture()
    values=a.trace(root.ref,2,12,'object')
    assert values and all(v.kind=='allocation' for v in values)
    assert not any('field_owner_instance_unproven' in s for v in values for s in v.path)


def test_different_framework_roots_do_not_share_initialized_child():
    a,reader,_=fixture()
    keys=[]
    for key in ('root-one:7','root-two:7'):
        a.reset();a.context_origins[0]={1:(Origin('view_lookup',key,OWNER,path=('view_lookup_nonnull_assumed',)),)}
        values=a.trace(reader.ref,0,2,'object')
        assert values and all(v.kind=='allocation' for v in values)
        keys.append({v.key for v in values})
        assert all(any('framework_constructor_assumed:' in s for s in v.path) for v in values)
    assert keys[0].isdisjoint(keys[1])


def test_uninvoked_initializer_is_not_a_constructor_edge():
    a,reader,root=fixture(False)
    values=a.trace(root.ref,2,12,'object')
    assert not any(':owned_initializer_field:' in s for v in values for s in v.path)
    assert a.receiver_resolution(values)=='possible_identity'
