"""Build inert List/ArrayList selection DEX regression cases with apktool.

Usage: python tests/build_collection_fixtures.py /path/to/apktool.jar
"""
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).parent / 'fixtures' / 'collections'
SMALI = ROOT / 'smali' / 'collections'
SMALI.mkdir(parents=True, exist_ok=True)
(ROOT / 'apktool.yml').write_text((ROOT.parent / 'apktool.yml').read_text())
(SMALI / 'Bridge.smali').write_text('''.class public Lcollections/Bridge;
.super Ljava/lang/Object;
.method public call()V
 .registers 1
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 return-void
.end method
''')

cases = ('GetFirst', 'GetFixed', 'Last', 'IteratorSecond', 'IteratorFirst', 'WrongList',
         'Overwritten', 'Removed', 'Cleared', 'UnknownIndex', 'Conditional', 'Escaped',
         'IteratorMutated', 'ObjectReceiver', 'WrongObjectReceiver', 'BoundHelpers')
manifest = ['''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dotori.collections">
<uses-sdk android:minSdkVersion="21" android:targetSdkVersion="34"/>
<application android:label="Collection selection regression cases">''']
for name in cases:
    code = f'''.class public Lcollections/{name};
.super Landroid/app/Activity;
.method public onCreate(Landroid/os/Bundle;)V
 .locals 9
 invoke-virtual {{p0}},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v1
 invoke-virtual {{v1}},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v1
 const-string v2,"https://fixed.invalid/"
 new-instance v3,Landroid/webkit/WebView;
 invoke-direct {{v3,p0}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v4,Lcollections/Bridge;
 invoke-direct {{v4}},Ljava/lang/Object;-><init>()V
 const-string v5,"Native"
 invoke-virtual {{v3,v4,v5}},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
 new-instance v0,Ljava/util/ArrayList;
 invoke-direct {{v0}},Ljava/util/ArrayList;-><init>()V
'''
    if name in ('ObjectReceiver', 'WrongObjectReceiver'):
        code += ''' invoke-virtual {v0,v3},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
 new-instance v2,Landroid/webkit/WebView;
 invoke-direct {v2,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 invoke-virtual {v0,v2},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
'''
    elif name in ('Last', 'IteratorSecond', 'IteratorFirst'):
        code += ''' invoke-virtual {v0,v2},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
 invoke-virtual {v0,v1},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
'''
    elif name == 'Conditional':
        code += ''' if-eqz p1,:after_add
 invoke-virtual {v0,v1},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
 :after_add
'''
    elif name == 'BoundHelpers':
        code += ''' invoke-static {v0,v1},Lcollections/Helpers;->add(Ljava/util/List;Ljava/lang/Object;)V
'''
    else:
        code += ''' invoke-virtual {v0,v1},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
 invoke-virtual {v0,v2},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
'''
    code += ' const/4 v5,0x0\n'
    if name == 'WrongList':
        code += ''' new-instance v0,Ljava/util/ArrayList;
 invoke-direct {v0},Ljava/util/ArrayList;-><init>()V
 invoke-virtual {v0,v2},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
'''
    if name == 'Overwritten':
        code += ' invoke-virtual {v0,v5,v2},Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;\n'
    if name == 'Removed':
        code += ' invoke-virtual {v0,v5},Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;\n'
    if name == 'Cleared':
        code += ''' invoke-virtual {v0},Ljava/util/ArrayList;->clear()V
 invoke-virtual {v0,v2},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
'''
    if name == 'UnknownIndex':
        code += ' invoke-static {},Lcollections/Unknown;->index()I\n move-result v5\n'
    if name == 'Escaped':
        code += ' invoke-static {v0},Lcollections/Unknown;->escape(Ljava/util/List;)V\n'
    if name in ('GetFixed', 'WrongObjectReceiver'):
        code += ' const/4 v5,0x1\n'
    if name in ('IteratorFirst', 'IteratorSecond', 'IteratorMutated'):
        code += ''' invoke-interface {v0},Ljava/util/List;->iterator()Ljava/util/Iterator;
 move-result-object v8
'''
        if name == 'IteratorSecond':
            code += ' invoke-interface {v8},Ljava/util/Iterator;->next()Ljava/lang/Object;\n'
        if name == 'IteratorMutated':
            code += ' invoke-virtual {v0,v2},Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z\n'
        code += ' invoke-interface {v8},Ljava/util/Iterator;->next()Ljava/lang/Object;\n'
    elif name == 'Last':
        code += ' invoke-static {v0},Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;\n'
    elif name == 'BoundHelpers':
        code += ' invoke-static {v0},Lcollections/Helpers;->first(Ljava/util/List;)Ljava/lang/Object;\n'
    else:
        code += ' invoke-interface {v0,v5},Ljava/util/List;->get(I)Ljava/lang/Object;\n'
    code += ' move-result-object v6\n'
    if name in ('ObjectReceiver', 'WrongObjectReceiver'):
        code += ''' check-cast v6,Landroid/webkit/WebView;
 invoke-virtual {v6,v1},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
'''
    else:
        code += ''' check-cast v6,Ljava/lang/String;
 invoke-virtual {v3,v6},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
'''
    code += ' return-void\n.end method\n'
    (SMALI / (name + '.smali')).write_text(code)
    manifest.append(f'<activity android:name="collections.{name}" android:exported="true"/>')
(SMALI / 'Helpers.smali').write_text('''.class public Lcollections/Helpers;
.super Ljava/lang/Object;
.method public static add(Ljava/util/List;Ljava/lang/Object;)V
 .registers 2
 invoke-interface {p0,p1},Ljava/util/List;->add(Ljava/lang/Object;)Z
 return-void
.end method
.method public static first(Ljava/util/List;)Ljava/lang/Object;
 .locals 1
 const/4 v0,0x0
 invoke-interface {p0,v0},Ljava/util/List;->get(I)Ljava/lang/Object;
 move-result-object v0
 return-object v0
.end method
''')
manifest.append('</application></manifest>')
(ROOT / 'AndroidManifest.xml').write_text('\n'.join(manifest))
if len(sys.argv) > 1:
    output = ROOT.parent / 'collections.apk'
    subprocess.run(['java', '-jar', sys.argv[1], 'b', str(ROOT), '-o', str(output)], check=True)
    with tempfile.TemporaryDirectory(prefix='dotori-collection-build-') as tmp:
        tmp = Path(tmp)
        with zipfile.ZipFile(sys.argv[1]) as archive:
            aapt = tmp / 'aapt2'
            aapt.write_bytes(archive.read('prebuilt/linux/aapt2_64'))
            aapt.chmod(0o755)
            framework = tmp / 'android-framework.jar'
            framework.write_bytes(archive.read('prebuilt/android-framework.jar'))
        packed = tmp / 'manifest.apk'
        subprocess.run([str(aapt), 'link', '--manifest', str(ROOT / 'AndroidManifest.xml'),
                        '-I', str(framework), '-o', str(packed)], check=True)
        with zipfile.ZipFile(output) as archive:
            files = {name: archive.read(name) for name in archive.namelist()}
        with zipfile.ZipFile(packed) as archive:
            files['AndroidManifest.xml'] = archive.read('AndroidManifest.xml')
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name, content in files.items():
                archive.writestr(name, content)
