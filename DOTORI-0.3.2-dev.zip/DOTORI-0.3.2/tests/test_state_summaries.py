"""Precise state-slot transfer tests over the same IR consumed from DEX."""
from collections import defaultdict
from types import SimpleNamespace

from dotori.demand import Backward
from dotori.engine import Limits
from dotori.index import Site
from dotori.model import Instruction as I, Method, Program, split_ref
from dotori.state_summaries import MUTABLE, STATE, OBJECT, POLICY

FACTORY = 'Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf' + f'({OBJECT}{POLICY}){MUTABLE}'
SET = MUTABLE + '->setValue(Ljava/lang/Object;)V'
GET = STATE + '->getValue()Ljava/lang/Object;'
WEBVIEW = 'Landroid/webkit/WebView;'
ROOT = 'Ltest/Main;->main()Ljava/lang/Object;'
HELPER = 'Ltest/Helpers;->put' + f'({MUTABLE}{OBJECT})V'
READER = 'Ltest/Helpers;->get' + f'({MUTABLE}){OBJECT}'


def analysis_for(*methods):
    callers, signatures, classes = defaultdict(list), defaultdict(set), defaultdict(list)
    writers = defaultdict(list)
    for method in methods:
        classes[method.owner].append(method.ref)
        for i in method.instructions:
            if i.op.startswith(('sput', 'iput')):
                writers[i.ref].append((method.ref, i.offset))
            if i.op.startswith('invoke-'):
                _, name, desc = split_ref(i.ref)
                callers[i.ref].append(Site(method.ref, i.offset, i.ref, i.op))
                signatures[name, desc].add(i.ref)
    catalog = SimpleNamespace(inventory=[], interfaces={MUTABLE: (STATE,)},
        call_signatures=signatures, by_class=classes, callers_of=lambda ref: callers[ref],
        writers_of=lambda ref: writers[ref], field_types={}, by_signature={})
    p = Program('test', None, None, [], {m.ref:m for m in methods}, {}, catalog=catalog)
    a = Backward(p, Limits(max_steps=100000, max_depth=64, timeout_seconds=30))
    return a


def factory(offset, register):
    return [I(offset, 'invoke-static', (6, 6), FACTORY),
            I(offset + 1, 'move-result-object', (register,))]


def helpers():
    return [Method(HELPER, 'public static', 2, 2, [I(0, 'invoke-interface', (0, 1), SET), I(1, 'return-void')]),
            Method(READER, 'public static', 1, 1, [I(0, 'invoke-interface', (0,), GET),
                I(1, 'move-result-object', (0,)), I(2, 'return-object', (0,))])]


def run(instructions, *extra, ref=ROOT, registers=8, ins_size=0):
    method = Method(ref, 'public static', registers, ins_size, instructions)
    a = analysis_for(method, *helpers(), *extra)
    result = a.trace(ref, instructions[-1].regs[0], instructions[-1].offset, 'object')
    return a, result


def read(offset, state=0):
    return [I(offset, 'invoke-static', (state,), READER),
            I(offset + 1, 'move-result-object', (4,)), I(offset + 2, 'return-object', (4,))]


def test_state_value_follows_same_object_through_accessor_helpers():
    a, result = run(factory(0, 0) + [I(2, 'new-instance', (1,), literal=WEBVIEW),
        I(3, 'invoke-static', (0, 1), HELPER)] + read(4))
    assert len(result) == 1 and result[0].key == ROOT + '@0002'
    assert any(s.startswith('state_object:') for s in result[0].path)
    assert any(s.startswith('state_writer_call:') for s in result[0].path)


def test_two_state_objects_and_setter_invocations_do_not_cross():
    a, result = run(factory(0, 0) + factory(2, 2) + [
        I(4, 'new-instance', (1,), literal=WEBVIEW), I(5, 'new-instance', (3,), literal=WEBVIEW),
        I(6, 'invoke-static', (0, 1), HELPER), I(7, 'invoke-static', (2, 3), HELPER)] + read(8))
    assert [r.key for r in result] == [ROOT + '@0004']


def test_last_write_replaces_previous_value_even_through_helper():
    a, result = run(factory(0, 0) + [
        I(2, 'new-instance', (1,), literal=WEBVIEW), I(3, 'invoke-static', (0, 1), HELPER),
        I(4, 'const/4', (1,), literal=0), I(5, 'invoke-static', (0, 1), HELPER)] + read(6))
    assert [r.kind for r in result] == ['constant']
    assert [r.value for r in result] == ['0']


def test_later_write_cannot_define_earlier_read():
    ins = factory(0, 0) + [I(2, 'new-instance', (1,), literal=WEBVIEW),
        I(3, 'invoke-static', (0,), READER), I(4, 'move-result-object', (4,)),
        I(5, 'invoke-static', (0, 1), HELPER), I(6, 'return-object', (4,))]
    a, result = run(ins)
    assert result == ()
    assert any(code == 'state_write_unresolved' for code, _ in a.notes)


def test_conditional_write_does_not_become_definite_value():
    a, result = run(factory(0, 0) + [I(2, 'new-instance', (1,), literal=WEBVIEW),
        I(3, 'if-eqz', (7,), target=5), I(4, 'invoke-static', (0, 1), HELPER)] + read(5),
        ref='Ltest/Main;->main(Z)Ljava/lang/Object;', ins_size=1)
    assert result == ()
    assert any(code == 'conditional_state_write' for code, _ in a.notes)


def test_unknown_alias_overwrite_blocks_previous_value():
    ref = 'Ltest/Main;->main' + f'({MUTABLE}){OBJECT}'
    a, result = run(factory(0, 0) + [I(2, 'new-instance', (1,), literal=WEBVIEW),
        I(3, 'invoke-static', (0, 1), HELPER), I(4, 'invoke-interface', (7, 1), SET)] + read(5),
        ref=ref, ins_size=1)
    assert result == ()
    assert any(code == 'state_writer_alias_unresolved' for code, _ in a.notes)


def test_unknown_value_overwrite_blocks_previous_value():
    a, result = run(factory(0, 0) + [I(2, 'new-instance', (1,), literal=WEBVIEW),
        I(3, 'invoke-static', (0, 1), HELPER), I(4, 'invoke-static', (0, 7), HELPER)] + read(5),
        ref='Ltest/Main;->main(Ljava/lang/Object;)Ljava/lang/Object;', ins_size=1)
    assert result == ()
    assert any(code == 'state_value_unresolved' for code, _ in a.notes)


def test_same_factory_two_calls_have_distinct_state_identity():
    factory_ref = 'Ltest/Helpers;->make()' + MUTABLE
    method = Method(factory_ref, 'public static', 2, 0, [I(0, 'const/4', (0,), literal=0),
        I(1, 'invoke-static', (0, 0), FACTORY), I(2, 'move-result-object', (0,)), I(3, 'return-object', (0,))])
    a, result = run([I(0, 'invoke-static', (), factory_ref), I(1, 'move-result-object', (0,)),
        I(2, 'invoke-static', (), factory_ref), I(3, 'move-result-object', (2,)),
        I(4, 'new-instance', (1,), literal=WEBVIEW), I(5, 'new-instance', (3,), literal=WEBVIEW),
        I(6, 'invoke-static', (0, 1), HELPER), I(7, 'invoke-static', (2, 3), HELPER)] + read(8), method)
    assert [r.key for r in result] == [ROOT + '@0004']


def test_lookalike_get_value_is_not_a_compose_summary():
    fake = Method('Ltest/Box;->getValue()Ljava/lang/Object;', 'public', 2, 1,
                  [I(0, 'const-string', (0,), literal='fixed'), I(1, 'return-object', (0,))])
    a, result = run([I(0, 'new-instance', (0,), literal='Ltest/Box;'),
        I(1, 'invoke-virtual', (0,), fake.ref), I(2, 'move-result-object', (1,)),
        I(3, 'return-object', (1,))], fake)
    assert [r.value for r in result] == ['fixed']
    assert not any(s.startswith('state_') for r in result for s in r.path)


def test_multiple_writes_inside_one_helper_respect_inner_order():
    helper = Method(HELPER, 'public static', 3, 2, [
        I(0, 'invoke-interface', (1, 2), SET), I(1, 'const/4', (0,), literal=0),
        I(2, 'invoke-interface', (1, 0), SET), I(3, 'return-void')])
    a, result = run(factory(0, 0) + [I(2, 'new-instance', (1,), literal=WEBVIEW),
        I(3, 'invoke-static', (0, 1), HELPER)] + read(4), helper)
    assert [r.value for r in result] == ['0']


def test_conditional_factory_relation_retains_diagnostic():
    ref = 'Ltest/Main;->main(Z)Ljava/lang/Object;'
    a, result = run([I(0, 'if-eqz', (7,), target=8)] + factory(1, 0) + [
        I(3, 'new-instance', (1,), literal=WEBVIEW), I(4, 'invoke-static', (0, 1), HELPER)] +
        read(5) + [I(8, 'return-object', (6,))], ref=ref, ins_size=1)
    assert any(code == 'conditional_state_identity' for code, _ in a.notes) is False
    # Query the reachable conditional arm explicitly, rather than the exit arm.
    a.trace(ref, 4, 7, 'object')
    assert any(code == 'conditional_state_identity' for code, _ in a.notes)
    assert any(code == 'conditional_state_write' for code, _ in a.notes)


def test_cast_cannot_manufacture_state_allocation_identity():
    a, result = run([I(0, 'new-instance', (0,), literal='Ljava/lang/Object;'),
        I(1, 'check-cast', (0,), literal=STATE), I(2, 'new-instance', (1,), literal=WEBVIEW),
        I(3, 'invoke-interface', (0, 1), SET)] + read(4))
    assert result == ()
    assert any(code == 'state_receiver_alias_unresolved' for code, _ in a.notes)


def test_state_value_mode_preserves_external_value_provenance():
    from dotori.demand import Origin
    ref = 'Ltest/Main;->main(Ljava/lang/Object;)Ljava/lang/Object;'
    method = Method(ref, 'public static', 8, 1, factory(0, 0) +
        [I(2, 'invoke-static', (0, 7), HELPER)] + read(3))
    a = analysis_for(method, *helpers())
    a.context_origins[0] = {7: (Origin('external_value', 'external:test', path=('test_source',)),)}
    result = a.trace(ref, 4, 5, 'value')
    assert len(result) == 1 and result[0].kind == 'external_value'
    assert result[0].path[0] == 'test_source'


def state_callbacks(two_publishers=False):
    slot = 'Ltest/Holder;->state' + MUTABLE
    setup = Method('Ltest/Holder;->setup()V', 'public static', 8, 0,
        factory(0, 0) + [I(2, 'sput-object', (0,), slot), I(3, 'return-void')])
    publishers = [Method(f'Ltest/Publisher{n};->publish()V', 'public static', 2, 0,
        [I(0, 'sget-object', (0,), slot), I(1, 'new-instance', (1,), literal=WEBVIEW),
         I(2, 'invoke-static', (0, 1), HELPER), I(3, 'return-void')])
         for n in range(2 if two_publishers else 1)]
    reader = Method(ROOT, 'public static', 8, 0, [I(0, 'sget-object', (0,), slot)] + read(1))
    a = analysis_for(setup, reader, *publishers, *helpers())
    return a, a.trace(ROOT, 4, 3, 'object')


def test_cross_callback_state_relation_explicitly_keeps_ordering_gap():
    a, result = state_callbacks()
    assert len(result) == 1 and result[0].key == 'Ltest/Publisher0;->publish()V@0001'
    assert 'state_read_after_write_assumed' in result[0].path
    assert any(code == 'state_lifecycle_order_unresolved' for code, _ in a.notes)


def test_unordered_publishers_do_not_merge_historical_values():
    a, result = state_callbacks(two_publishers=True)
    assert result == ()
    assert any(code == 'state_write_order_unresolved' for code, _ in a.notes)


def test_write_before_read_inside_same_bound_helper_is_not_a_later_call():
    ref = 'Ltest/Helpers;->initializeAndRead' + f'({MUTABLE}){OBJECT}'
    helper = Method(ref, 'public static', 2, 1, [
        I(0, 'new-instance', (0,), literal=WEBVIEW), I(1, 'invoke-static', (1, 0), HELPER),
        I(2, 'invoke-static', (1,), READER), I(3, 'move-result-object', (0,)),
        I(4, 'return-object', (0,))])
    a, result = run(factory(0, 0) + [I(2, 'invoke-static', (0,), ref),
        I(3, 'move-result-object', (4,)), I(4, 'return-object', (4,))], helper)
    assert len(result) == 1 and result[0].typ == WEBVIEW
    assert ':call_context:' in result[0].key
