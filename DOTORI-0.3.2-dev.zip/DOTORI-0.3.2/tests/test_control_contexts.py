from dotori.demand import compatible, WV
from dotori.model import Instruction as I, Method, Component
from test_context_identity import analysis_for


def test_guard_of_two_factory_invocations_is_not_one_execution_choice():
    factory=Method('Lcontexts/Factory;->choose(Z)'+WV,'public static',2,1,[
        I(0,'if-eqz',(1,),target=6),I(2,'new-instance',(0,),literal=WV),I(4,'return-object',(0,)),
        I(6,'new-instance',(0,),literal=WV),I(8,'return-object',(0,))])
    caller=Method('Lcontexts/Caller;->use(ZZ)V','public static',4,2,[
        I(0,'nop'),I(2,'invoke-static',(2,),factory.ref),I(4,'move-result-object',(1,)),
        I(6,'nop'),I(8,'invoke-static',(3,),factory.ref),I(10,'move-result-object',(2,)),I(12,'return-void')])
    a=analysis_for(factory,caller)
    left=a.trace(caller.ref,1,12,'object');right=a.trace(caller.ref,2,12,'object')
    assert all(compatible(x,y) for x in left for y in right)
    assert len({x.key for x in left}|{x.key for x in right})==4


def test_inherited_allocation_context_separates_component_owners():
    method=Method('Lcontexts/Base;->setup()V','public',2,1,[I(0,'new-instance',(0,),literal=WV),I(2,'return-void')])
    one=Component('contexts.One','Lcontexts/One;','activity',True)
    two=Component('contexts.Two','Lcontexts/Two;','activity',True)
    a=analysis_for(method,components=(one,two))
    a.p.supers.update({one.code_class:method.owner,two.code_class:method.owner})
    from dotori.demand import Origin
    keys=[]
    for c in (one,two):
        ctx=a.component_context(method,Origin('component','component:'+c.code_class,c.code_class,c.name))
        keys.append(a.trace(method.ref,0,2,'object',ctx)[0].key)
    assert len(set(keys))==2
