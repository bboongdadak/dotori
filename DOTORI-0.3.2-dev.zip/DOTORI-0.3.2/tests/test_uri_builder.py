"""Framework Uri.Builder provenance, object identity, and overwrite negatives."""
from collections import defaultdict
from types import SimpleNamespace

from dotori.demand import Backward, Origin
from dotori.engine import Limits
from dotori.index import Site
from dotori.model import Instruction as I, Method, Program, split_ref
from dotori.uri_builder import BUILDER as B, URI as U, STRING as S

ROOT = 'Ltest/UriCase;->test(' + S + ')' + S


def analysis(*methods):
    callers, signatures, classes = defaultdict(list), defaultdict(set), defaultdict(list)
    for m in methods:
        classes[m.owner].append(m.ref)
        for i in m.instructions:
            if i.op.startswith('invoke-'):
                _, name, desc = split_ref(i.ref)
                signatures[name, desc].add(i.ref)
                callers[i.ref].append(Site(m.ref, i.offset, i.ref, i.op))
    catalog = SimpleNamespace(inventory=[], interfaces={}, call_signatures=signatures,
        by_signature={}, by_class=classes, callers_of=lambda r: callers[r],
        writers_of=lambda r: [], field_types={})
    p = Program('test', None, None, [], {m.ref:m for m in methods}, {}, catalog=catalog)
    a = Backward(p, Limits(max_steps=100000, max_depth=64, timeout_seconds=10))
    a.context_origins[0] = {9: (Origin('external_value', 'source:test', path=('synthetic_source',)),)}
    return a


def run(ins, *methods, ref=ROOT, register=7, handlers=(), has_exceptions=False, before=None):
    m = Method(ref, 'public static', 10, 1, ins, has_exceptions=has_exceptions, exception_handlers=handlers)
    a = analysis(m, *methods)
    return a, a.trace(ref, register, ins[-1].offset if before is None else before, 'value')


def make(offset=0, reg=0):
    return [I(offset, 'new-instance', (reg,), literal=B),
            I(offset+1, 'invoke-direct', (reg,), B+'-><init>()V')]


def setter(offset, name, reg=0, value=9):
    return I(offset, 'invoke-virtual', (reg, value), B+'->'+name+'('+S+')'+B)


def append(offset, reg=0, key=1, value=9):
    return I(offset, 'invoke-virtual', (reg, key, value), B+'->appendQueryParameter('+S+S+')'+B)


def finish(offset, reg=0):
    return [I(offset, 'invoke-virtual', (reg,), B+'->build()'+U),
            I(offset+1, 'move-result-object', (6,)),
            I(offset+2, 'invoke-virtual', (6,), U+'->toString()'+S),
            I(offset+3, 'move-result-object', (7,)), I(offset+4, 'return-object', (7,))]


def external(values):
    return [v for v in values if v.kind == 'external_value']


def test_path_setter_transfers_external_value_with_identity_witness():
    a, values = run(make()+[setter(2, 'path')]+finish(3))
    assert len(external(values)) == 1
    assert any(s.startswith('uri_builder_object:') for s in external(values)[0].path)
    assert not a.notes


def test_fluent_mutator_returns_same_builder_object():
    _, values = run(make()+[setter(2, 'path'),I(3,'move-result-object',(2,))]+finish(4,reg=2))
    assert external(values)


def test_builder_to_string_is_a_snapshot():
    _, values=run(make()+[setter(2,'path'),I(3,'invoke-virtual',(0,),B+'->toString()'+S),
        I(4,'move-result-object',(7,)),I(5,'return-object',(7,))])
    assert external(values)


def test_replacement_removes_earlier_component_value():
    _, values=run(make()+[setter(2,'path'),I(3,'const-string',(2,),literal='fixed'),
        setter(4,'encodedPath',value=2)]+finish(5))
    assert not external(values)


def test_append_keeps_earlier_component_value():
    _, values=run(make()+[setter(2,'path'),I(3,'const-string',(2,),literal='tail'),
        setter(4,'appendPath',value=2)]+finish(5))
    assert external(values)


def test_query_clear_removes_query_but_not_path():
    common=make()+[I(2,'const-string',(1,),literal='key'),append(3),
                  I(4,'invoke-virtual',(0,),B+'->clearQuery()'+B)]
    _, cleared=run(common+finish(5))
    _, other=run(common+[setter(5,'path')]+finish(6))
    assert not external(cleared)
    assert external(other)


def test_query_replacement_removes_appended_value():
    _, values=run(make()+[I(2,'const-string',(1,),literal='key'),append(3),
        I(4,'const-string',(2,),literal='fixed=1'),setter(5,'query',value=2)]+finish(6))
    assert not external(values)


def test_two_builders_do_not_cross_values():
    _, values=run(make()+make(2,2)+[setter(4,'path',reg=2)]+finish(5))
    assert not external(values)


def test_calls_after_build_do_not_change_snapshot():
    ins=make()+[I(2,'const-string',(2,),literal='fixed'),setter(3,'path',value=2)]
    ins += finish(4)[:-1]+[setter(8,'path'),I(9,'return-object',(7,))]
    _, values=run(ins)
    assert not external(values)


def test_overwrite_after_build_does_not_erase_snapshot_source():
    ins=make()+[setter(2,'path')]+finish(3)[:-1]
    ins += [I(7,'const-string',(2,),literal='fixed'),setter(8,'path',value=2),I(9,'return-object',(7,))]
    _, values=run(ins)
    assert external(values)


def test_build_upon_preserves_unpartitioned_original_uri():
    _, values=run([I(0,'invoke-static',(9,),U+'->parse('+S+')'+U),I(1,'move-result-object',(3,)),
        I(2,'invoke-virtual',(3,),U+'->buildUpon()'+B),I(3,'move-result-object',(0,)),
        I(4,'const-string',(1,),literal='key'),I(5,'const-string',(2,),literal='fixed'),
        append(6,value=2)]+finish(7))
    assert external(values)
    assert any('uri_builder_base_components_unknown' in v.path for v in values)


def test_build_upon_copies_snapshot_components_clear_query_removes_only_query():
    ins=make()+[I(2,'const-string',(1,),literal='key'),append(3),
        I(4,'invoke-virtual',(0,),B+'->build()'+U),I(5,'move-result-object',(3,)),
        I(6,'invoke-virtual',(3,),U+'->buildUpon()'+B),I(7,'move-result-object',(2,)),
        I(8,'invoke-virtual',(2,),B+'->clearQuery()'+B)]
    _, values=run(ins+finish(9,2))
    assert not external(values)


def test_build_upon_copy_is_independent_of_original_builder_later_mutation():
    ins=make()+[setter(2,'path'),I(3,'invoke-virtual',(0,),B+'->build()'+U),
        I(4,'move-result-object',(3,)),I(5,'invoke-virtual',(3,),U+'->buildUpon()'+B),
        I(6,'move-result-object',(2,)),I(7,'const-string',(4,),literal='fixed'),setter(8,'path',value=4)]
    _, values=run(ins+finish(9,2))
    assert external(values)


def test_unknown_mutation_and_escaped_alias_are_not_assumed_safe():
    for mutation in [I(3,'invoke-virtual',(0,9),B+'->opaquePart('+S+')'+B),
                     I(3,'invoke-static',(0,),'Lunknown/Code;->mutate('+B+')V'),
                     I(3,'sput-object',(0,),'Ltest/Box;->builder'+B)]:
        a,values=run(make()+[setter(2,'path'),mutation]+finish(4))
        assert not values
        assert any(c.startswith('uri_builder_') for c,_ in a.notes)


def test_conditional_mutation_remains_unresolved():
    a,values=run(make()+[I(2,'if-eqz',(8,),target=4),setter(3,'path')]+finish(4))
    assert not values
    assert any(c in ('uri_builder_control_flow_unresolved', 'uri_builder_receiver_alias_unresolved') for c,_ in a.notes)


def test_cast_does_not_manufacture_a_builder():
    a,values=run([I(0,'new-instance',(0,),literal='Ljava/lang/Object;'),
        I(1,'check-cast',(0,),literal=B),setter(2,'path')]+finish(3))
    assert not values
    assert any(c=='uri_builder_receiver_alias_unresolved' for c,_ in a.notes)


def test_exact_helper_writer_and_reader_share_receiver():
    put='Ltest/Helper;->put('+B+S+')V'
    get='Ltest/Helper;->get('+B+')'+S
    writer=Method(put,'public static',2,2,[setter(0,'path',reg=0,value=1),I(1,'return-void')])
    reader=Method(get,'public static',10,1,finish(0,9))
    _,values=run(make()+[I(2,'invoke-static',(0,9),put),I(3,'invoke-static',(0,),get),
        I(4,'move-result-object',(7,)),I(5,'return-object',(7,))],writer,reader)
    assert external(values)


def test_same_helper_two_calls_keep_call_context_separate():
    encode='Ltest/Helper;->encode('+S+')'+S
    helper=Method(encode,'public static',10,1,make()+[setter(2,'path')]+finish(3))
    _,values=run([I(0,'invoke-static',(9,),encode),I(1,'move-result-object',(7,)),
        I(2,'const-string',(2,),literal='fixed'),I(3,'invoke-static',(2,),encode),
        I(4,'move-result-object',(7,)),I(5,'return-object',(7,))],helper)
    assert not external(values)
    _,values=run([I(0,'const-string',(2,),literal='fixed'),I(1,'invoke-static',(2,),encode),
        I(2,'move-result-object',(7,)),I(3,'invoke-static',(9,),encode),
        I(4,'move-result-object',(7,)),I(5,'return-object',(7,))],helper)
    assert external(values)
    assert any(':call_context:' in s for v in external(values) for s in v.path)


def test_unknown_overwrite_cannot_reuse_previous_external_value():
    a,values=run(make()+[setter(2,'path'),setter(3,'path',value=8)]+finish(4))
    assert not external(values)
    assert any(c=='uri_builder_value_unresolved' for c,_ in a.notes)


def test_lookalike_method_is_not_framework_summary():
    fake=Method('Ltest/Box;->build()'+U,'public',2,1,
        [I(0,'const-string',(0,),literal='fixed'),I(1,'return-object',(0,))])
    _,values=run([I(0,'new-instance',(0,),literal='Ltest/Box;'),I(1,'invoke-virtual',(0,),fake.ref),
        I(2,'move-result-object',(7,)),I(3,'return-object',(7,))],fake)
    assert [v.value for v in values]==['fixed']


def test_binary_uri_builder_fixture_has_only_expected_links():
    from pathlib import Path
    from dotori.apk import load_apk
    p = load_apk(Path(__file__).parent/'fixtures'/'uri-builder.apk')
    report = Backward(p, Limits(max_steps=100000, max_depth=48, timeout_seconds=30)).run()
    expected = {'uri.Path', 'uri.AppendQuery', 'uri.BuildUpon', 'uri.BoundHelpers', 'uri.SnapshotRetained'}
    assert {c['entry_component'] for c in report['candidates']} == expected
    assert {c['entry_component'] for c in report['input_webview_paths']} == expected
    assert report['completion']['loading_unvisited'] == 0
    assert all(any('uri_builder_snapshot:' in step for step in c['source']['path'])
               for c in report['candidates'])


def test_earlier_unrelated_branch_does_not_block_fresh_builder():
    ins=[I(0,'if-eqz',(8,),target=3),I(1,'const-string',(2,),literal='left'),
         I(2,'goto',target=4),I(3,'const-string',(2,),literal='right')]
    _, values=run(ins+make(4)+[setter(6,'path')]+finish(7))
    assert external(values)


def test_earlier_unrelated_try_does_not_block_fresh_builder():
    ins=[I(0,'invoke-static',(),'Ltest/Other;->work()V'),I(1,'goto',target=4),
         I(2,'return-object',(7,)),I(3,'move-exception',(2,))]
    a, values=run(ins+make(4)+[setter(6,'path')]+finish(7),
        has_exceptions=True,handlers=((0,1,3,'Ljava/lang/Exception;'),))
    assert external(values)
    assert not any(c=='uri_builder_exception_flow_unresolved' for c,_ in a.notes)


def test_protected_builder_mutation_with_exiting_catch_has_success_condition():
    ins=make()+[setter(2,'path')]+finish(3)
    ins += [I(8,'move-exception',(2,)), I(9,'const/4',(7,),literal=0), I(10,'return-object',(7,))]
    a, values=run(ins,has_exceptions=True,handlers=((2,4,8,'Ljava/lang/Exception;'),),before=7)
    assert external(values)
    assert any(c=='uri_builder_exception_success_assumed' for c,_ in a.notes)
    assert any('uri_builder_normal_success_assumed:' in step for v in external(values) for step in v.path)


def test_handler_entry_inside_builder_interval_is_not_replayed_linearly():
    ins=[I(0,'invoke-static',(),'Ltest/Other;->work()V'),I(1,'goto',target=4),
         I(2,'return-object',(7,)),I(3,'nop')]
    a, values=run(ins+make(4)+[setter(6,'path')]+finish(7),
        has_exceptions=True,handlers=((0,1,6,'Ljava/lang/Exception;'),))
    assert not external(values)
    assert any(c.startswith('uri_builder_') for c,_ in a.notes)


def test_later_backward_goto_to_return_is_not_a_builder_loop():
    ins=[I(0,'goto',target=4),I(1,'return-object',(7,)),
         I(4,'invoke-static',(9,),U+'->parse('+S+')'+U),I(5,'move-result-object',(3,)),
         I(6,'invoke-virtual',(3,),U+'->buildUpon()'+B),I(7,'move-result-object',(0,)),setter(8,'path')]
    ins+=finish(9)[:-1]+[I(13,'goto',target=1)]
    _, values=run(ins)
    assert external(values)


def test_later_actual_backedge_does_not_merge_builder_iterations():
    ins=make()+[setter(2,'path')]+finish(3)[:-1]
    ins += [I(7,'if-eqz',(8,),target=0),I(8,'return-object',(7,))]
    a, values=run(ins)
    assert not external(values)
    assert any(c in ('uri_builder_loop_unresolved','uri_builder_receiver_alias_unresolved',
                     'uri_builder_control_flow_unresolved') for c,_ in a.notes)


def test_catch_rejoining_read_is_not_a_success_only_witness():
    for mutation in (False, True):
        ins=make()+[setter(2,'path')]+finish(3)
        ins += [I(8,'move-exception',(2,))]
        if mutation:
            ins += [I(9,'const-string',(2,),literal='fallback'),setter(10,'path',value=2),I(11,'goto',target=3)]
        else:
            ins += [I(9,'goto',target=3)]
        a, values=run(ins,has_exceptions=True,handlers=((2,3,8,'Ljava/lang/Exception;'),),before=7)
        assert not external(values)
        assert any(c.startswith('uri_builder_') for c,_ in a.notes)


def test_throw_before_builder_definition_cannot_create_receiver():
    ins=[I(0,'invoke-virtual',(9,),U+'->buildUpon()'+B),I(1,'move-result-object',(0,)),
         I(2,'goto',target=5),I(3,'move-exception',(2,)),I(4,'goto',target=5)]
    ins+=finish(5)
    a, values=run(ins,has_exceptions=True,handlers=((0,1,3,'Ljava/lang/Exception;'),))
    assert not external(values)
    assert any(c.startswith('uri_builder_') for c,_ in a.notes)


def test_caught_writer_helper_return_rejoins_caller_and_remains_unresolved():
    put='Ltest/Helper;->put('+B+S+')V'
    writer=Method(put,'public static',3,2,[setter(0,'path',reg=1,value=2),I(1,'return-void'),
        I(2,'move-exception',(0,)),I(3,'return-void')],has_exceptions=True,
        exception_handlers=((0,1,2,'Ljava/lang/Exception;'),))
    a,values=run(make()+[I(2,'invoke-static',(0,9),put)]+finish(3),writer)
    assert not external(values)
    assert any(c=='uri_builder_exception_flow_unresolved' for c,_ in a.notes)
