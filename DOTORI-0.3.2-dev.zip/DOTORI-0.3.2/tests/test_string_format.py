from pathlib import Path
import pytest
from dotori.apk import load_apk
from dotori.demand import Backward
from dotori.engine import Limits

EXPECTED={'Sequential','Indexed','SecondArgument','EscapedPercent','Copied','CopySnapshot',
          'SourceRegisterOverwrite','CopyReallocatedOriginal'}


def test_binary_format_connects_only_used_slots_and_copy_snapshots():
    r=Backward(load_apk(Path(__file__).parent/'fixtures/string_format.apk'),Limits(max_depth=64)).run()
    for group in ('input_webview_paths','candidates'):
        assert {p['entry_component'].split('.')[-1] for p in r[group]}==EXPECTED
        assert all(p['load']['receiver'] for p in r[group])
        assert all(any(':format_argument:' in s for s in p['source']['path']) for p in r[group])
    assert {'string_format_template_unresolved','string_format_conversion_unresolved',
            'format_array_alias_unresolved','format_array_escape_unresolved'} <= {d['code'] for d in r['diagnostics']}


@pytest.mark.parametrize('fmt,indexes',[
    ('%s %s',(0,1)), ('%2$s %s %<s %1$S',(0,1)), ('%%s%n',()),
    ('%.0s %2$s',(1,)), ('%-8s',(0,)), ('%1$s %1$s',(0,)),
])
def test_format_argument_selection(fmt,indexes):
    from dotori.string_format import argument_indexes
    assert argument_indexes(fmt)==indexes


@pytest.mark.parametrize('fmt',['%d','%tF','%0$s','%<s','%1$<s','%q','%','%--2s','%-s'])
def test_unknown_or_invalid_formats_never_select_every_argument(fmt):
    from dotori.string_format import argument_indexes
    with pytest.raises(ValueError):argument_indexes(fmt)
