"""Generate independent smali examples and optionally assemble using apktool.
The expected labels live in expected.json, not in the analyzer's API rules.
No Gradle, emulator or app execution is involved.
"""

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent / "fixtures"
SOURCE = """
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;
    move-result-object v0
    const-string v1, "url"
    invoke-virtual {v0,v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2
"""
VIEW = """
    new-instance v3, Landroid/webkit/WebView;
    invoke-direct {v3,p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v4
    const/4 v5, 0x1
    invoke-virtual {v4,v5}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V
"""
BRIDGE = """
    new-instance v6, Llab/Bridge;
    invoke-direct {v6}, Llab/Bridge;-><init>()V
    const-string v7, "Native"
    invoke-virtual {v3,v6,v7}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
"""
LOAD = "    invoke-virtual {v3,v2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V\n"
HEADER = """.class public Llab/{name};
.super Landroid/app/Activity;
.field private web:Landroid/webkit/WebView;
.field private text:Ljava/lang/String;
.method public constructor <init>()V
 .registers 1
 invoke-direct {{p0}}, Landroid/app/Activity;-><init>()V
 return-void
.end method
.method protected onCreate(Landroid/os/Bundle;)V
 .registers 12
"""
FOOTER = "    return-void\n.end method\n"
HELPER = """
.method private identity(Ljava/lang/String;)Ljava/lang/String;
 .registers 2
 return-object p1
.end method
"""
scenarios = {
    "Direct": (SOURCE + VIEW + BRIDGE + LOAD, True),
    "Constant": (
        SOURCE
        + VIEW
        + BRIDGE
        + ' const-string v2, "https://example.invalid/"\n'
        + LOAD,
        False,
    ),
    "DifferentViews": (
        SOURCE
        + VIEW
        + BRIDGE
        + " new-instance v3, Landroid/webkit/WebView;\n invoke-direct {v3,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V\n"
        + LOAD,
        False,
    ),
    "Unexported": (SOURCE + VIEW + BRIDGE + LOAD, False),
    "Disabled": (SOURCE + VIEW + BRIDGE + LOAD, False),
    "NoAnnotation": (
        SOURCE + VIEW + BRIDGE.replace("Llab/Bridge;", "Llab/NoBridge;") + LOAD,
        False,
    ),
    "HelperReturn": (
        SOURCE
        + VIEW
        + BRIDGE
        + " invoke-direct {p0,v2}, Llab/HelperReturn;->identity(Ljava/lang/String;)Ljava/lang/String;\n move-result-object v2\n"
        + LOAD,
        True,
    ),
    "OverwriteHelper": (
        SOURCE
        + VIEW
        + BRIDGE
        + ' const-string v2, "fixed"\n invoke-direct {p0,v2}, Llab/OverwriteHelper;->identity(Ljava/lang/String;)Ljava/lang/String;\n move-result-object v2\n'
        + LOAD,
        False,
    ),
    "FieldFlow": (
        SOURCE
        + VIEW
        + BRIDGE
        + " iput-object v2,p0,Llab/FieldFlow;->text:Ljava/lang/String;\n const/4 v2,0x0\n iget-object v2,p0,Llab/FieldFlow;->text:Ljava/lang/String;\n"
        + LOAD,
        True,
    ),
    "FieldViews": (
        SOURCE
        + VIEW
        + " iput-object v3,p0,Llab/FieldViews;->web:Landroid/webkit/WebView;\n"
        + BRIDGE
        + " const/4 v3,0x0\n iget-object v3,p0,Llab/FieldViews;->web:Landroid/webkit/WebView;\n"
        + LOAD,
        True,
    ),
    "UnrelatedCall": (
        SOURCE
        + VIEW
        + BRIDGE
        + ' const-string v2,"fixed"\n invoke-virtual {p0}, Llab/UnrelatedCall;->unrelated()V\n'
        + LOAD,
        False,
    ),
    "BranchSplit": (
        SOURCE
        + VIEW
        + " if-eqz v2,:other\n"
        + BRIDGE
        + " goto :done\n :other\n"
        + LOAD
        + " :done\n",
        False,
    ),
    "DeadBranch": (
        SOURCE
        + VIEW
        + " const/4 v8,0x0\n if-eqz v8,:done\n"
        + BRIDGE
        + LOAD
        + " :done\n",
        False,
    ),
    "RemoveBeforeLoad": (
        SOURCE
        + VIEW
        + BRIDGE
        + " invoke-virtual {v3,v7}, Landroid/webkit/WebView;->removeJavascriptInterface(Ljava/lang/String;)V\n"
        + LOAD,
        False,
    ),
    "RegisterAfterLoad": (SOURCE + VIEW + LOAD + BRIDGE, True),
    "JavaScriptDisabled": (
        SOURCE + VIEW.replace("const/4 v5, 0x1", "const/4 v5, 0x0") + BRIDGE + LOAD,
        True,
    ),
    "JavaScriptReenabled": (
        SOURCE + VIEW.replace("const/4 v5, 0x1", "const/4 v5, 0x0")
        + " const/4 v5,0x1\n invoke-virtual {v4,v5},Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V\n"
        + BRIDGE + LOAD,
        True,
    ),
    "JavaScriptConditional": (
        SOURCE + VIEW.replace(" const/4 v5, 0x1\n invoke-virtual {v4,v5}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V\n", "")
        + " if-eqz v2,:after_settings\n const/4 v5,0x1\n"
        + " invoke-virtual {v4,v5},Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V\n :after_settings\n"
        + BRIDGE + LOAD,
        True,
    ),
    "ArrayElement": (
        SOURCE + VIEW + BRIDGE
        + " const/4 v8,0x1\n new-array v9,v8,[Ljava/lang/String;\n const/4 v10,0x0\n"
        + " aput-object v2,v9,v10\n aget-object v2,v9,v10\n" + LOAD,
        True,
    ),
    "ArrayWrongIndex": (
        SOURCE + VIEW + BRIDGE
        + " const/4 v8,0x2\n new-array v9,v8,[Ljava/lang/String;\n const/4 v10,0x0\n const/4 v11,0x1\n"
        + " aput-object v2,v9,v10\n aget-object v2,v9,v11\n" + LOAD,
        False,
    ),
    "ArrayOverwrite": (
        SOURCE + VIEW + BRIDGE
        + " const/4 v8,0x1\n new-array v9,v8,[Ljava/lang/String;\n const/4 v10,0x0\n"
        + ' aput-object v2,v9,v10\n const-string v2,"fixed"\n aput-object v2,v9,v10\n'
        + " aget-object v2,v9,v10\n" + LOAD,
        False,
    ),
    "BundleElement": (
        SOURCE + VIEW + BRIDGE
        + " new-instance v8,Landroid/os/Bundle;\n invoke-direct {v8},Landroid/os/Bundle;-><init>()V\n"
        + ' const-string v9,"url"\n invoke-virtual {v8,v9,v2},Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V\n'
        + " invoke-virtual {v8,v9},Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;\n move-result-object v2\n" + LOAD,
        True,
    ),
    "BundleWrongKey": (
        SOURCE + VIEW + BRIDGE
        + " new-instance v8,Landroid/os/Bundle;\n invoke-direct {v8},Landroid/os/Bundle;-><init>()V\n"
        + ' const-string v9,"url"\n const-string v10,"other"\n'
        + ' invoke-virtual {v8,v9,v2},Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V\n'
        + " invoke-virtual {v8,v10},Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;\n move-result-object v2\n" + LOAD,
        False,
    ),
    "BundleOverwrite": (
        SOURCE + VIEW + BRIDGE
        + " new-instance v8,Landroid/os/Bundle;\n invoke-direct {v8},Landroid/os/Bundle;-><init>()V\n"
        + ' const-string v9,"url"\n invoke-virtual {v8,v9,v2},Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V\n'
        + ' const-string v11,"fixed"\n invoke-virtual {v8,v9,v11},Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V\n'
        + " invoke-virtual {v8,v9},Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;\n move-result-object v2\n" + LOAD,
        False,
    ),
    "BundleTypeOverwrite": (
        SOURCE + VIEW + BRIDGE
        + " new-instance v8,Landroid/os/Bundle;\n invoke-direct {v8},Landroid/os/Bundle;-><init>()V\n"
        + ' const-string v9,"url"\n invoke-virtual {v8,v9,v2},Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V\n'
        + ' const/4 v11,0x1\n invoke-virtual {v8,v9,v11},Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V\n'
        + " invoke-virtual {v8,v9},Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;\n move-result-object v2\n" + LOAD,
        False,
    ),
    "BundleConditional": (
        SOURCE + VIEW + BRIDGE
        + " new-instance v8,Landroid/os/Bundle;\n invoke-direct {v8},Landroid/os/Bundle;-><init>()V\n"
        + ' const-string v9,"url"\n if-eqz v2,:after_put\n'
        + ' invoke-virtual {v8,v9,v2},Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V\n :after_put\n'
        + " invoke-virtual {v8,v9},Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;\n move-result-object v2\n" + LOAD,
        False,
    ),
    "RunnablePosted": (
        SOURCE + VIEW + BRIDGE
        + " new-instance v8,Llab/DeferredLoad;\n"
        + " invoke-direct {v8,v3,v2},Llab/DeferredLoad;-><init>(Landroid/webkit/WebView;Ljava/lang/String;)V\n"
        + " invoke-virtual {v3,v8},Landroid/webkit/WebView;->post(Ljava/lang/Runnable;)Z\n",
        True,
    ),
    "RunnableUnposted": (
        SOURCE + VIEW + BRIDGE
        + " new-instance v8,Llab/DeferredLoad;\n"
        + " invoke-direct {v8,v3,v2},Llab/DeferredLoad;-><init>(Landroid/webkit/WebView;Ljava/lang/String;)V\n",
        False,
    ),
    "RunnableDifferentView": (
        SOURCE + VIEW + BRIDGE
        + " new-instance v9,Landroid/webkit/WebView;\n invoke-direct {v9,p0},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V\n"
        + " new-instance v8,Llab/DeferredLoad;\n"
        + " invoke-direct {v8,v9,v2},Llab/DeferredLoad;-><init>(Landroid/webkit/WebView;Ljava/lang/String;)V\n"
        + " invoke-virtual {v9,v8},Landroid/webkit/WebView;->post(Ljava/lang/Runnable;)Z\n",
        False,
    ),
    "RunnableConditionalPost": (
        SOURCE + VIEW + BRIDGE
        + " new-instance v8,Llab/DeferredLoad;\n"
        + " invoke-direct {v8,v3,v2},Llab/DeferredLoad;-><init>(Landroid/webkit/WebView;Ljava/lang/String;)V\n"
        + " if-eqz v2,:skip_post\n invoke-virtual {v3,v8},Landroid/webkit/WebView;->post(Ljava/lang/Runnable;)Z\n :skip_post\n",
        False,
    ),
    "ClassCastIdentity": (
        SOURCE + VIEW + BRIDGE
        + " const-class v8,Ljava/lang/String;\n"
        + " invoke-virtual {v8,v2},Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;\n"
        + " move-result-object v2\n" + LOAD,
        True,
    ),
    "ClassCastOverwrite": (
        SOURCE + VIEW + BRIDGE
        + " const-class v8,Ljava/lang/String;\n const-string v2,\"fixed\"\n"
        + " invoke-virtual {v8,v2},Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;\n"
        + " move-result-object v2\n" + LOAD,
        False,
    ),
    "ConcreteVirtualOverride": (
        SOURCE + VIEW + BRIDGE
        + " new-instance v8,Llab/ChildPicker;\n invoke-direct {v8},Llab/ChildPicker;-><init>()V\n"
        + " invoke-virtual {v8,v2},Llab/BasePicker;->pick(Ljava/lang/String;)Ljava/lang/String;\n"
        + " move-result-object v2\n" + LOAD,
        True,
    ),
    "ConcreteVirtualBase": (
        SOURCE + VIEW + BRIDGE
        + " new-instance v8,Llab/BasePicker;\n invoke-direct {v8},Llab/BasePicker;-><init>()V\n"
        + " invoke-virtual {v8,v2},Llab/BasePicker;->pick(Ljava/lang/String;)Ljava/lang/String;\n"
        + " move-result-object v2\n" + LOAD,
        False,
    ),
    "Lifecycle": (
        SOURCE
        + VIEW
        + BRIDGE
        + " iput-object v2,p0,Llab/Lifecycle;->text:Ljava/lang/String;\n iput-object v3,p0,Llab/Lifecycle;->web:Landroid/webkit/WebView;\n",
        True,
    ),
    "ViewId": (
        SOURCE
        + " const/16 v8,0x1234\n invoke-virtual {p0,v8}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;\n move-result-object v3\n check-cast v3,Landroid/webkit/WebView;\n"
        + BRIDGE
        + " invoke-virtual {p0,v8}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;\n move-result-object v3\n check-cast v3,Landroid/webkit/WebView;\n"
        + LOAD,
        True,
    ),
    "DifferentViewIds": (
        SOURCE
        + " const/16 v8,0x1234\n invoke-virtual {p0,v8}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;\n move-result-object v3\n check-cast v3,Landroid/webkit/WebView;\n"
        + BRIDGE
        + " const/16 v8,0x5678\n invoke-virtual {p0,v8}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;\n move-result-object v3\n check-cast v3,Landroid/webkit/WebView;\n"
        + LOAD,
        False,
    ),
    "Forwarder": (
        SOURCE + """ new-instance v0,Landroid/content/Intent;
 const-class v8,Llab/Internal;
 invoke-direct {v0,p0,v8},Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
 const-string v1,"url"
 invoke-virtual {v0,v1,v2},Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
 invoke-virtual {p0,v0},Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
""",
        True,
    ),
    "Internal": (SOURCE + VIEW + BRIDGE + LOAD, False),
}
scenarios["StaticMethod"] = (
    SOURCE + VIEW + BRIDGE.replace("Llab/Bridge;", "Llab/StaticMethodBridge;") + LOAD,
    True,
)
scenarios.update(
    {
        "StaticBridge": (
            SOURCE
            + VIEW
            + ' sget-object v6,Llab/Singleton;->instance:Llab/Bridge;\n const-string v7,"Native"\n invoke-virtual {v3,v6,v7},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V\n'
            + LOAD,
            True,
        ),
        "InheritedBridge": (
            SOURCE + VIEW + BRIDGE.replace("Llab/Bridge;", "Llab/ChildBridge;") + LOAD,
            True,
        ),
        "WideArgument": (
            SOURCE
            + VIEW
            + BRIDGE
            + " const-wide/16 v8,0x1\n invoke-static {v8,v9,v2},Llab/WideArgument;->wide(JLjava/lang/String;)Ljava/lang/String;\n move-result-object v2\n"
            + LOAD,
            True,
        ),
        "WrongOwner": (
            SOURCE
            + " new-instance v3,Llab/Lookalike;\n invoke-direct {v3},Llab/Lookalike;-><init>()V\n"
            + BRIDGE.replace("Landroid/webkit/WebView;", "Llab/Lookalike;")
            + LOAD.replace("Landroid/webkit/WebView;", "Llab/Lookalike;"),
            False,
        ),
        "LayoutChange": (
            SOURCE
            + " const/16 v8,0x1234\n invoke-virtual {p0,v8},Landroid/app/Activity;->setContentView(I)V\n invoke-virtual {p0,v8},Landroid/app/Activity;->findViewById(I)Landroid/view/View;\n move-result-object v3\n check-cast v3,Landroid/webkit/WebView;\n"
            + BRIDGE
            + " const/16 v9,0x5678\n invoke-virtual {p0,v9},Landroid/app/Activity;->setContentView(I)V\n invoke-virtual {p0,v8},Landroid/app/Activity;->findViewById(I)Landroid/view/View;\n move-result-object v3\n check-cast v3,Landroid/webkit/WebView;\n"
            + LOAD,
            False,
        ),
        "OnNewIntent": (
            VIEW
            + BRIDGE
            + " iput-object v3,p0,Llab/OnNewIntent;->web:Landroid/webkit/WebView;\n",
            True,
        ),
        "HtmlInput": (
            SOURCE
            + VIEW
            + BRIDGE
            + ' move-object v4,v2\n const-string v5,"text/html"\n const-string v6,"UTF-8"\n const/4 v7,0x0\n move-object v2,v3\n const-string v3,"https://example.invalid/"\n invoke-virtual/range {v2 .. v7},Landroid/webkit/WebView;->loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V\n',
            True,
        ),
        "LoadData": (
            SOURCE
            + VIEW
            + BRIDGE
            + ' const-string v4,"text/html"\n const-string v5,"UTF-8"\n invoke-virtual {v3,v2,v4,v5},Landroid/webkit/WebView;->loadData(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V\n',
            True,
        ),
        "RepeatedAllocation": (
            SOURCE
            + " const/4 v8,0x0\n :loop\n"
            + VIEW
            + " if-nez v8,:load\n"
            + BRIDGE
            + " const/4 v8,0x1\n goto :loop\n :load\n"
            + LOAD,
            False,
        ),
        "CopiedIntent": (
            SOURCE
            + VIEW
            + BRIDGE
            + " invoke-virtual {p0},Landroid/app/Activity;->getIntent()Landroid/content/Intent;\n move-result-object v0\n new-instance v1,Landroid/content/Intent;\n invoke-direct {v1,v0},Landroid/content/Intent;-><init>(Landroid/content/Intent;)V\n invoke-virtual {v1},Landroid/content/Intent;->getDataString()Ljava/lang/String;\n move-result-object v2\n"
            + LOAD,
            True,
        ),
    }
)
scenarios["NewIntentFresh"] = (
    VIEW
    + BRIDGE
    + " iput-object v3,p0,Llab/NewIntentFresh;->web:Landroid/webkit/WebView;\n"
    + " invoke-virtual {p0},Landroid/app/Activity;->getIntent()Landroid/content/Intent;\n move-result-object v0\n"
    + ' const-string v1,"https://example.invalid/"\n invoke-static {v1},Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;\n move-result-object v1\n'
    + " invoke-virtual {v0,v1},Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;\n",
    True,
)
expected = {}
for name, (body, label) in scenarios.items():
    header=HEADER.format(name=name)
    if name.startswith(('Array','Bundle','Runnable')):header=header.replace('.registers 12','.registers 14')
    source = header + body + FOOTER
    if name in ("HelperReturn", "OverwriteHelper"):
        source += HELPER
    if name == "WideArgument":
        source += """.method public static wide(JLjava/lang/String;)Ljava/lang/String;
 .registers 3
 return-object p2
.end method
"""
    if name in ("OnNewIntent", "NewIntentFresh"):
        source += """.method protected onNewIntent(Landroid/content/Intent;)V
 .registers 4
 invoke-virtual {p1},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v0
 iget-object v1,p0,Llab/OnNewIntent;->web:Landroid/webkit/WebView;
 invoke-virtual {v1,v0},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
"""
    if name == "UnrelatedCall":
        source += """.method public unrelated()V
 .registers 3
 invoke-virtual {p0},Landroid/app/Activity;->getIntent()Landroid/content/Intent;
 move-result-object v0
 invoke-virtual {v0},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v1
 return-void
.end method
"""
    if name == "Lifecycle":
        source += """.method protected onResume()V
 .registers 3
 iget-object v0,p0,Llab/Lifecycle;->web:Landroid/webkit/WebView;
 iget-object v1,p0,Llab/Lifecycle;->text:Ljava/lang/String;
 invoke-virtual {v0,v1},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
"""
    if name == "NewIntentFresh":
        source = source.replace("Llab/OnNewIntent;->web", "Llab/NewIntentFresh;->web")
    (ROOT / "smali/lab" / f"{name}.smali").write_text(source)
    expected["lab." + name] = label
manifest = [
    '<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="lab"><uses-sdk android:minSdkVersion="21" android:targetSdkVersion="28"/><application android:label="DOTORI test cases">'
]
for name in scenarios:
    exported = "false" if name in ("Unexported", "Internal") else "true"
    enabled = "false" if name == "Disabled" else "true"
    manifest.append(
        f'<activity android:name=".{name}" android:exported="{exported}" android:enabled="{enabled}"/>'
    )
(ROOT / 'smali_classes2/lab/DeferredLoad.smali').write_text('''.class public Llab/DeferredLoad;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;
.field private view:Landroid/webkit/WebView;
.field private url:Ljava/lang/String;
.method public constructor <init>(Landroid/webkit/WebView;Ljava/lang/String;)V
 .registers 3
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 iput-object p1,p0,Llab/DeferredLoad;->view:Landroid/webkit/WebView;
 iput-object p2,p0,Llab/DeferredLoad;->url:Ljava/lang/String;
 return-void
.end method
.method public run()V
 .registers 3
 iget-object v0,p0,Llab/DeferredLoad;->view:Landroid/webkit/WebView;
 iget-object v1,p0,Llab/DeferredLoad;->url:Ljava/lang/String;
 invoke-virtual {v0,v1},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
''')
(ROOT / 'smali_classes2/lab/BasePicker.smali').write_text('''.class public Llab/BasePicker;
.super Ljava/lang/Object;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 return-void
.end method
.method public pick(Ljava/lang/String;)Ljava/lang/String;
 .registers 3
 const-string v0,"fixed"
 return-object v0
.end method
''')
(ROOT / 'smali_classes2/lab/ChildPicker.smali').write_text('''.class public Llab/ChildPicker;
.super Llab/BasePicker;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Llab/BasePicker;-><init>()V
 return-void
.end method
.method public pick(Ljava/lang/String;)Ljava/lang/String;
 .registers 2
 return-object p1
.end method
''')
# Handwritten callback cases use the Intent parameter, independent of Activity.getIntent.
for name, kind, signature, intentreg in [
    (
        "Receiver",
        "receiver",
        "onReceive(Landroid/content/Context;Landroid/content/Intent;)V",
        "p2",
    ),
    ("Service", "service", "onStartCommand(Landroid/content/Intent;II)I", "p1"),
]:
    superclass = (
        "Landroid/content/BroadcastReceiver;"
        if kind == "receiver"
        else "Landroid/app/Service;"
    )
    source = f".class public Llab/{name};\n.super {superclass}\n"
    source += f".method public constructor <init>()V\n .registers 1\n invoke-direct {{p0}},{superclass}-><init>()V\n return-void\n.end method\n"
    source += f".method public {signature}\n .registers 14\n"
    source += f' const-string v1,"url"\n invoke-virtual {{{intentreg},v1}},Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;\n move-result-object v2\n'
    context = "p0" if kind == "service" else "p1"
    source += (
        f" new-instance v3,Landroid/webkit/WebView;\n invoke-direct {{v3,{context}}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V\n"
        + BRIDGE
        + LOAD
    )
    source += (
        " const/4 v0,0x1\n return v0\n.end method\n" if kind == "service" else FOOTER
    )
    (ROOT / "smali/lab" / f"{name}.smali").write_text(source)
    if kind == "service":
        source += """.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
 .registers 3
 const/4 v0,0x0
 return-object v0
.end method
"""
    (ROOT / "smali/lab" / f"{name}.smali").write_text(source)
    expected["lab." + name] = True
    manifest.append(f'<{kind} android:name=".{name}" android:exported="true"/>')
# An inherited writer calls an abstract getter on this. Twenty unrelated
# subclasses ensure that selecting the first sixteen overrides cannot pass.
(ROOT / 'smali_classes2/lab/ContextBaseActivity.smali').write_text('''.class public abstract Llab/ContextBaseActivity;
.super Landroid/app/Activity;
.field private stored:Ljava/lang/String;
.method public abstract pick()Ljava/lang/String;
.end method
.method public setup()V
 .registers 2
 invoke-virtual {p0},Llab/ContextBaseActivity;->pick()Ljava/lang/String;
 move-result-object v0
 invoke-virtual {p0,v0},Llab/ContextBaseActivity;->setStored(Ljava/lang/String;)V
 return-void
.end method
.method public setStored(Ljava/lang/String;)V
 .registers 2
 iput-object p1,p0,Llab/ContextBaseActivity;->stored:Ljava/lang/String;
 return-void
.end method
.method public stored()Ljava/lang/String;
 .registers 2
 iget-object v0,p0,Llab/ContextBaseActivity;->stored:Ljava/lang/String;
 return-object v0
.end method
''')
for name in [f'AContextNoise{i:02d}' for i in range(20)]+['ZContextDispatchInput','ZContextDispatchFixed','ZContextOtherReceiver']:
    header=HEADER.format(name=name).replace('.super Landroid/app/Activity;', '.super Llab/ContextBaseActivity;')
    header=header.replace('Landroid/app/Activity;-><init>', 'Llab/ContextBaseActivity;-><init>')
    if name.startswith('Z'):
        body=' invoke-virtual {p0},Llab/ContextBaseActivity;->setup()V\n'
        if name=='ZContextOtherReceiver':
            header=header.replace('.registers 12','.registers 14')
            body+=SOURCE+''' new-instance v8,Llab/ZContextDispatchInput;
 invoke-direct {v8},Llab/ZContextDispatchInput;-><init>()V
 invoke-virtual {v8,v2},Llab/ContextBaseActivity;->setStored(Ljava/lang/String;)V
'''
        body+=''' invoke-virtual {p0},Llab/ContextBaseActivity;->stored()Ljava/lang/String;
 move-result-object v2
'''+VIEW+BRIDGE+LOAD
    else:body=''
    pick=SOURCE+' return-object v2\n' if name.endswith('Input') else ' const-string v2,"fixed"\n return-object v2\n'
    source=header+body+FOOTER+'.method public pick()Ljava/lang/String;\n .registers 4\n'+pick+'.end method\n'
    (ROOT/'smali/lab'/f'{name}.smali').write_text(source)
    manifest.append(f'<activity android:name=".{name}" android:exported="true"/>')
    expected['lab.'+name]=name.endswith('Input')
# Base constructor is separate so the scenario constructors preserve this.
with (ROOT/'smali_classes2/lab/ContextBaseActivity.smali').open('a') as out:
    out.write('''.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Landroid/app/Activity;-><init>()V
 return-void
.end method
''')
manifest.append("</application></manifest>")
(ROOT / "AndroidManifest.xml").write_text("\n".join(manifest))
# Two Activity lookups without a content root are not an identity witness.
# Keep the legacy label separately; it conflates a resource ID with an object.
demand_expected=dict(expected, **{'lab.ViewId': False})
(ROOT / "expected-demand.json").write_text(json.dumps(demand_expected, indent=2) + "\n")
# The retained legacy engine conflates array elements; its known false
# positive is excluded from the older engine's historical regression labels.
(ROOT / "expected.json").write_text(json.dumps({k:v for k,v in expected.items() if k!='lab.ArrayWrongIndex' and not k.startswith(('lab.Bundle','lab.Runnable','lab.ClassCast','lab.ConcreteVirtual','lab.AContext','lab.ZContext'))}, indent=2) + "\n")
if len(sys.argv) > 1:
    subprocess.run(
        ["java", "-jar", sys.argv[1], "b", str(ROOT), "-o", str(ROOT / "cases.apk")],
        check=True,
    )
