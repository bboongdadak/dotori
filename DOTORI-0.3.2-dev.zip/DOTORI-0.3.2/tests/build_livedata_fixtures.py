"""Compile independent LiveData allocation/observer regression cases, never run them.

Usage: python tests/build_livedata_fixtures.py /path/to/apktool.jar
"""
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).parent / 'fixtures' / 'livedata'
SMALI = ROOT / 'smali'
SMALI.mkdir(parents=True, exist_ok=True)
(ROOT / 'apktool.yml').write_text((ROOT.parent / 'apktool.yml').read_text())


def write(name, content):
    target = SMALI / (name + '.smali')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content)


write('androidx/lifecycle/MutableLiveData', '''.class public Landroidx/lifecycle/MutableLiveData;
.super Landroidx/lifecycle/LiveData;
.method public constructor <init>()V
 .registers 1
 invoke-direct {p0},Landroidx/lifecycle/LiveData;-><init>()V
 return-void
.end method
''')
write('ld/Bridge', '''.class public Lld/Bridge;
.super Ljava/lang/Object;
.method public call()V
 .registers 1
 .annotation runtime Landroid/webkit/JavascriptInterface;
 .end annotation
 return-void
.end method
''')
write('ld/Payload', '''.class public Lld/Payload;
.super Ljava/lang/Object;
.field public value:Ljava/lang/Object;
.method public constructor <init>(Ljava/lang/Object;)V
 .registers 2
 invoke-direct {p0},Ljava/lang/Object;-><init>()V
 iput-object p1,p0,Lld/Payload;->value:Ljava/lang/Object;
 return-void
.end method
''')
manifest = ['''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dotori.livedata">
<uses-sdk android:minSdkVersion="21" android:targetSdkVersion="34"/>
<application android:label="LiveData regression cases">''']
for name in ('Registered', 'WrongStream', 'WrongObserver', 'Unregistered', 'Wrapped', 'WrongPayload'):
    wrapped = name in ('Wrapped', 'WrongPayload')
    write('ld/' + name + 'Observer', f'''.class public Lld/{name}Observer;
.super Ljava/lang/Object;
.implements Landroidx/lifecycle/Observer;
.field private web:Landroid/webkit/WebView;
.method public constructor <init>(Landroid/webkit/WebView;)V
 .registers 2
 invoke-direct {{p0}},Ljava/lang/Object;-><init>()V
 iput-object p1,p0,Lld/{name}Observer;->web:Landroid/webkit/WebView;
 return-void
.end method
.method public onChanged(Ljava/lang/Object;)V
 .locals 1
 iget-object v0,p0,Lld/{name}Observer;->web:Landroid/webkit/WebView;
''' + (''' check-cast p1,Lld/Payload;
 iget-object p1,p1,Lld/Payload;->value:Ljava/lang/Object;
''' if wrapped else '') + ''' check-cast p1,Ljava/lang/String;
 invoke-virtual {v0,p1},Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
 return-void
.end method
''')
    setup = f'''.class public Lld/{name};
.super Landroid/app/Activity;
.implements Landroidx/lifecycle/LifecycleOwner;
.field private static first:Landroidx/lifecycle/MutableLiveData;
.field private static second:Landroidx/lifecycle/MutableLiveData;
.method static constructor <clinit>()V
 .registers 1
 new-instance v0,Landroidx/lifecycle/MutableLiveData;
 invoke-direct {{v0}},Landroidx/lifecycle/MutableLiveData;-><init>()V
 sput-object v0,Lld/{name};->first:Landroidx/lifecycle/MutableLiveData;
 new-instance v0,Landroidx/lifecycle/MutableLiveData;
 invoke-direct {{v0}},Landroidx/lifecycle/MutableLiveData;-><init>()V
 sput-object v0,Lld/{name};->second:Landroidx/lifecycle/MutableLiveData;
 return-void
.end method
.method public onCreate(Landroid/os/Bundle;)V
 .locals 5
 new-instance v0,Landroid/webkit/WebView;
 invoke-direct {{v0,p0}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1,Lld/{name}Observer;
 invoke-direct {{v1,v0}},Lld/{name}Observer;-><init>(Landroid/webkit/WebView;)V
 new-instance v2,Lld/Bridge;
 const-string v3,"Native"
 invoke-virtual {{v0,v2,v3}},Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
'''
    if name == 'WrongObserver':
        setup += f''' new-instance v4,Landroid/webkit/WebView;
 invoke-direct {{v4,p0}},Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
 new-instance v1,Lld/{name}Observer;
 invoke-direct {{v1,v4}},Lld/{name}Observer;-><init>(Landroid/webkit/WebView;)V
'''
    if name != 'Unregistered':
        setup += f''' sget-object v2,Lld/{name};->first:Landroidx/lifecycle/MutableLiveData;
 invoke-virtual {{v2,p0,v1}},Landroidx/lifecycle/MutableLiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V
'''
    setup += f''' return-void
.end method
.method public onNewIntent(Landroid/content/Intent;)V
 .locals 4
 sget-object v0,Lld/{name};->{'second' if name == 'WrongStream' else 'first'}:Landroidx/lifecycle/MutableLiveData;
 invoke-virtual {{p1}},Landroid/content/Intent;->getDataString()Ljava/lang/String;
 move-result-object v1
'''
    if wrapped:
        setup += ''' new-instance v2,Lld/Payload;
 invoke-direct {v2,v1},Lld/Payload;-><init>(Ljava/lang/Object;)V
'''
        if name == 'WrongPayload':
            setup += ''' const-string v1,"https://fixed.invalid"
 new-instance v3,Lld/Payload;
 invoke-direct {v3,v1},Lld/Payload;-><init>(Ljava/lang/Object;)V
 move-object v2,v3
'''
    setup += ' invoke-virtual {v0,' + ('v2' if wrapped else 'v1') + '''},Landroidx/lifecycle/MutableLiveData;->postValue(Ljava/lang/Object;)V
 return-void
.end method
'''
    write('ld/' + name, setup)
    manifest.append(f'<activity android:name="ld.{name}" android:exported="true"/>')
manifest.append('</application></manifest>')
(ROOT / 'AndroidManifest.xml').write_text('\n'.join(manifest))
if len(sys.argv) > 1:
    output = ROOT.parent / 'livedata.apk'
    subprocess.run(['java', '-jar', sys.argv[1], 'b', str(ROOT), '-o', str(output)], check=True)
    with tempfile.TemporaryDirectory(prefix='dotori-livedata-build-') as tmp:
        tmp = Path(tmp)
        with zipfile.ZipFile(sys.argv[1]) as archive:
            aapt = tmp / 'aapt2'
            aapt.write_bytes(archive.read('prebuilt/linux/aapt2_64'))
            aapt.chmod(0o755)
            framework = tmp / 'android-framework.jar'
            framework.write_bytes(archive.read('prebuilt/android-framework.jar'))
        packed = tmp / 'manifest.apk'
        subprocess.run([str(aapt), 'link', '--manifest', str(ROOT / 'AndroidManifest.xml'),
                        '-I', str(framework), '-o', str(packed)], check=True)
        with zipfile.ZipFile(output) as archive:
            files = {name: archive.read(name) for name in archive.namelist()}
        with zipfile.ZipFile(packed) as archive:
            files['AndroidManifest.xml'] = archive.read('AndroidManifest.xml')
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name, content in files.items():
                archive.writestr(name, content)
