import importlib.util
from pathlib import Path

spec=importlib.util.spec_from_file_location('corpus_runner',Path(__file__).parents[1]/'tools/evaluate_corpus.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)


def row():return {'index':'1','cve':'test','package':'test','versionName':'1','main_apk':'app.apk','main_apk_sha256':'wrong'}


def test_missing_apk_is_a_case_record_not_a_batch_exception(tmp_path):
    r=runner.run_case(row(),tmp_path,tmp_path,1,100)
    assert r['evaluation_status']=='input_missing' and not r['counted_success']


def test_mismatched_input_is_never_analyzed(tmp_path,monkeypatch):
    (tmp_path/'app.apk').write_bytes(b'unexpected input')
    def fail(*args,**kwargs):raise AssertionError('must not launch')
    monkeypatch.setattr(runner.subprocess,'run',fail)
    r=runner.run_case(row(),tmp_path,tmp_path,1,100)
    assert r['evaluation_status']=='input_hash_mismatch' and 'command' not in r


def test_source_snapshot_includes_content_and_nested_modules(tmp_path):
    (tmp_path/'one.py').write_text('first')
    (tmp_path/'nested').mkdir();(tmp_path/'nested/two.py').write_text('second')
    before=runner.source_hashes(tmp_path)
    (tmp_path/'one.py').write_text('changed')
    after=runner.source_hashes(tmp_path)
    assert before.keys()=={'one.py','nested/two.py'}
    assert before['one.py']!=after['one.py'] and before['nested/two.py']==after['nested/two.py']


def test_incomplete_cli_exit_code_is_a_collected_report(tmp_path,monkeypatch):
    import hashlib,json,subprocess
    data=b'input';(tmp_path/'app.apk').write_bytes(data)
    r=row();r['main_apk_sha256']=hashlib.sha256(data).hexdigest()
    def launch(command,**kwargs):
        (tmp_path/'01.json').write_text(json.dumps({'input':{'sha256':r['main_apk_sha256']},
            'status':'incomplete','coverage_status':'partial','candidates':[],
            'input_webview_paths':[],'bridge_javascript_paths':[],'metrics':{}}))
        return subprocess.CompletedProcess(command,3)
    monkeypatch.setattr(runner.subprocess,'run',launch)
    actual=runner.run_case(r,tmp_path,tmp_path,1,100)
    assert actual['evaluation_status']=='collected' and actual['status']=='incomplete'
    assert not actual['counted_success']
