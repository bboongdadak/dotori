# DOTORI 0.3.2

Android APK의 외부 입력, WebView 로딩, JavaScript Bridge 관계를 추적하는 정적 분석기입니다. WebView 피연산자에서 출발하는 수요 기반 역방향 슬라이싱을 사용합니다. APK를 실행하지 않습니다.

## 개발 환경

Python 3.12/WSL·Linux에서 검증했습니다. 패키지 선언은 Python 3.10 이상이며, 아래 명령은 프로젝트 루트에서 실행합니다.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[test]'
```

`requirements-lock.txt`는 이전 검증에 사용한 Python 3.12/Linux 의존성 버전 기록입니다. 다른 운영체제에서도 같은 환경을 보장하는 해시 lock은 아닙니다.

## 분석 실행

```bash
mkdir -p results
python -m dotori analyze target.apk \
  --timeout 120 --max-steps 300000 \
  -o results/result.json --text results/result.txt
```

기본적으로 APK 안의 전체 WebView API 위치를 선택합니다. `--focus-method`로 일부 메서드만 조사한 결과는 APK 전체의 결과와 구분합니다. `python -m dotori analyze --help`에서 옵션을 확인할 수 있습니다.

## 회귀 검사

```bash
python -m pytest -q
```

`tests/`에는 테스트 코드, 기대 레이블, 작은 테스트 APK, smali/manifest와 생성 스크립트가 포함됩니다. 일반 테스트는 포함된 APK를 읽으므로 APKtool이 필요하지 않습니다. 바이너리 fixture를 수정·재빌드할 때만 해당 생성 스크립트와 Java/APKtool을 사용합니다.

## 개발 파일

| 경로 | 용도 |
|---|---|
| `src/dotori/` | 분석기·CLI 소스 |
| `tests/` | 단위·통합 회귀 및 fixture 원본 |
| `tools/evaluate_corpus.py` | 별도 APK 코퍼스의 실행·해시·설정 기록 |
| `tools/compare_corpus.py` | 같은 APK·설정의 증거 경로 비교 |
| `evaluation/` | 실제 APK 평가용 입력 목록·해시·기대 흐름 |
| `pyproject.toml` | 패키지·의존성·테스트 설정 |
| `requirements-lock.txt` | 검증 환경의 의존성 버전 기록 |
| [DEVELOPMENT.md](DEVELOPMENT.md) | 모델 경계, 개발 규칙, 후속 과제 |
| `LICENSE` | 소스 라이선스 |

실제 CVE 평가 APK와 과거 배포본·wheel·실행 결과·대용량 보고서는 이 개발용 패키지에 포함하지 않습니다. 필요한 코퍼스와 새 실행 결과는 프로젝트 밖 또는 `corpus/`, `results/`에 둡니다.

## 결과 해석

`input_webview_paths`는 입력→WebView, `bridge_javascript_paths`는 Bridge→JavaScript 실행, `candidates`는 입력 로딩과 같은 추상 WebView의 Bridge 연계 후보입니다. 세 유형을 같은 성공으로 합산하지 않습니다.

`incomplete`는 전역 제한·미방문 위치·색인 누락 등이 남은 상태입니다. `completed_with_gaps`는 선택 위치를 시도했지만 모델·로컬 탐색 한계가 남은 상태입니다. `completed_with_model_limits` 역시 모델 범위 안의 수집 상태입니다. 경로 수, 종료 코드, 상태만으로 취약점이나 기대 흐름 복구를 확정하지 않습니다. `0 candidates`는 안전 판정이 아닙니다.
