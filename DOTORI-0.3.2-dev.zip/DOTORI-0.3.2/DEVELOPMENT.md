# 개발 기준

## 범위와 성공 근거

외부 출처→연속된 값 전달→호환되는 비-null WebView 수신 객체의 근거를 유지합니다. 전체 Bridge 연계에는 같은 WebView의 등록과 노출 메서드 근거가 추가로 필요합니다. 조건·가정·미해결 간선을 결과에 남기며, 부분 경로는 부분 회복으로 취급합니다. 목표는 분석가가 수동 검토할 정적 흐름 근거입니다.

네이티브 해석, 난독화 복원, 특정 앱·패키지·CVE 이름으로 탐지 결과를 바꾸는 예외는 추가하지 않습니다. Android/AndroidX/Kotlin 등 표준 API 요약은 객체·인자·호출 근거와 적용 조건을 명시합니다.

## 주요 소스

- `apk.py`, `index.py`, `model.py`, `manifest.py`: APK/DEX 입력, 압축 색인, IR 및 컴포넌트 모델.
- `demand.py`: CLI에서 사용하는 수요 기반 역방향 분석, 값·객체·호출 조건과 경로 생성.
- `heap_context.py`: 실제 수신 객체와 호출 묶음, 생성자→같은 객체의 helper 초기화 문맥.
- `compose_callbacks.py`, `compose_effects.py`, `state_summaries.py`: 등록된 AndroidView/LaunchedEffect, 실제 continuation 생성, 같은 상태 슬롯 전달.
- `view_lookup.py`, `view_state.py`, `webview_callbacks.py`: 화면 root/ID, 객체 상태 및 등록된 WebView 콜백.
- `intent_delivery.py`, `router_transfers.py`, `livedata.py`: 컴포넌트·컨테이너·관찰자 전달.
- `uri_builder.py`, `string_format.py`, `keyed_maps.py`, `collections_summary.py`: API별 값·객체 요약.
- `reporting.py`, `javascript.py`, `cli.py`: 결과 해석, JavaScript 관련 근거, CLI.
- `engine.py`: 공용 제한 및 유지 중인 기존 분석 API. 기존 회귀와 함께 보존합니다.

## 변경 순서

1. 작은 실패 fixture로 필요한 값·객체 관계를 고정합니다.
2. 앱 이름과 무관한 일반 규칙을 수정합니다.
3. 다른 객체·호출·등록·키·분기·덮어쓰기의 음성 사례를 확인합니다.
4. `python -m pytest -q`로 전체 회귀를 확인합니다.
5. 같은 APK 해시·최종 소스·설정으로 실제 코퍼스를 다시 평가하고 경로별로 판정합니다.

테스트 APK는 테스트 코드의 입력입니다. `tests/fixtures/`와 `tests/protocol_fixture/`의 APK, 기대 JSON, manifest, smali, 생성 스크립트를 함께 유지합니다. 테스트 개수를 늘리거나 레이블만 바꾸어 실제 APK 성능 개선으로 집계하지 않습니다.

## 코퍼스 재평가

`tools/evaluate_corpus.py`는 코퍼스 루트의 `manifest.csv`와 별도 main APK를 사용합니다. `evaluation/manifest.csv`에 파일 경로·해시가, `evaluation/expectations.json`에 고정된 사례별 기대 흐름이 있습니다. 실제 APK는 원래 코퍼스 레이아웃으로 별도 보관하고 manifest를 그 루트에 둡니다. 입력 CSV의 필수 열은 `index`, `cve`, `package`, `versionName`, `main_apk`, `main_apk_sha256`입니다. 출력 폴더는 비어 있어야 합니다.

```bash
python tools/evaluate_corpus.py /path/to/corpus results/current \
  --jobs 2 --timeout 120 --max-steps 300000
python tools/compare_corpus.py results/previous results/current results/comparison.json
```

수집기의 `counted_success: false`/`not_reviewed`는 수동 판정 전 기본값입니다. 경로별 출처, 수신 객체, 등록 근거, 조건과 미해결 경계를 검토해야 합니다. 비교 도구의 경로 개수와 semantic locator 역시 성공 수가 아닙니다.

## 남은 경계

- ViewBinding/XML의 실제 객체 소속과 ViewStub의 content 설치.
- 일반 콜백의 교체·등록·실행 순서와 관찰자/상태 객체 수명.
- 내부 Activity·Fragment·라우팅의 전달 및 인터셉터 조건.
- 큰 앱의 디스패치·방문·시간 제한과 독립된 일반화 평가.

0.3.2의 마지막 전체 코퍼스 기록에서 확인된 흐름 복구는 1/15였고 10/15 목표는 미달입니다. 이 개발용 정리는 분석 로직을 변경하지 않으며, 이전 APK 평가를 새 평가로 대체하지 않습니다.
