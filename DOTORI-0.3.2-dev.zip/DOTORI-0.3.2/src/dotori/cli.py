from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

from . import __version__
from .apk import InputError, load_apk
from .engine import Analyzer, Limits
from .demand import Backward


def write_atomic(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", dir=path.parent, delete=False
    ) as f:
        temp = f.name
        f.write(content)
    try:
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def text_report(report):
    if report["schema_version"].startswith("2."):
        return demand_text_report(report)
    lines = [
        f"DOTORI {__version__} — static path candidates",
        f"Package: {report['input']['package']}",
        f"Status: {report['status']}",
        f"Candidates: {len(report['candidates'])}",
        "No finding is a confirmed vulnerability. No candidates does not establish safety.",
        "",
    ]
    for c in report["candidates"]:
        lines += [
            c["id"],
            f"  Entry: {c['entry_component']}",
            f"  Load: {c['load']['site']} ({c['load']['api']} arg {c['load']['argument_index']})",
            f"  Bridge: {c['bridge']['site']}",
            f"  Interface names: {', '.join(c['bridge']['names']) or 'unresolved'}",
            f"  JavaScript: {c['load']['javascript_enabled']}",
            f"  Registration before load: {c['registration_before_load']}",
        ]
        for m in c["bridge"]["exposure"]["methods"]:
            lines.append("  Exposed native method: " + m)
        for a in c["assumptions"]:
            lines.append("  Review: " + a)
        lines.append("")
    lines.append(f"Unlinked external loads: {len(report['unlinked_external_loads'])}")
    lines.append(f"Diagnostics: {len(report['diagnostics'])}")
    for d in report["diagnostics"]:
        lines.append("  " + d["code"] + ": " + d["detail"])
    return "\n".join(lines) + "\n"


def demand_text_report(r):
    lines=[f"DOTORI {__version__} — demand-driven static candidates",f"Package: {r['input']['package']}",f"Status: {r['status']}",
           f"Candidates: {len(r['candidates'])}",f"Input-to-WebView paths: {len(r['input_webview_paths'])}",
           f"Bridge-to-JavaScript paths: {len(r['bridge_javascript_paths'])}",f"Intent forwarding paths: {len(r['intent_forwarding_paths'])}",
           f"WebView API sites: {len(r['api_inventory'])}","No finding is a confirmed vulnerability.",""]
    if 'completion' in r:
        c=r['completion']
        lines.extend((f"Loading sites fully sliced: {c['loading_sliced_complete']}/{c['loading_sites']}",
                      f"Loading sites incomplete: {c['loading_sliced_incomplete']}; unvisited: {c['loading_unvisited']}",
                      f"Bridge registrations fully sliced: {c['bridge_registrations_sliced_complete']}/{c['bridge_registration_sites']}",""))
    if 'review_summary' in r:
        lines.extend((f"Coverage: {r['coverage_status']}",f"Analyst handoff: {r['review_summary']['status']}",
                      "Status describes collection of flow evidence; coverage gaps remain listed separately.",""))
    for group in ('candidates','input_webview_paths','bridge_javascript_paths'):
        lines.append(group+':')
        for item in r[group]:
            lines.append('  '+item['id']+' '+item['classification'])
            lines.append('  Source: '+item['source']['entry'])
            lines.append('  Source kind: '+item['source']['kind'])
            sink=item.get('load',item.get('javascript_execution',{}))
            lines.append('  Sink: '+sink.get('site',''))
            if 'bridge' in item:
                lines.append('  Bridge: '+item['bridge']['site']+' names='+str(item['bridge']['names']))
                lines.extend('  Exposed bridge method: '+method for method in item['bridge']['exposure']['methods'])
            if 'review' in item:
                review=item['review']
                lines.append('  Review: '+review['status']+'; evidence: '+review['evidence_level'])
                lines.append('  Value flow:')
                lines.extend('    '+step for step in item['source']['path'])
                for owner,offset,target in item['source'].get('branch_choices',[]):
                    condition='Exceptional edge' if owner.endswith(':exception') else 'Branch choice'
                    lines.append(f'  {condition}: {owner.removesuffix(":exception")}@{offset:04x} -> {target:04x}')
                for relation in item.get('object_relations',[]):
                    lines.append('  Receiver relation: '+relation['relation']+' '+relation['key'])
                for check in item.get('callback_constraints',[]):
                    lines.append('  Callback condition: '+check['site']+' equals '+repr(check['value']))
                for gap in review['context_gaps']:
                    lines.append('  Slice gaps at '+gap['site']+': '+', '.join(gap['diagnostic_codes']))
                lines.extend('  Manual check: '+task for task in review['manual_checks'])
    lines.append('Diagnostics:')
    lines.extend('  '+d['code']+': '+d['detail'] for d in r['diagnostics'])
    return '\n'.join(lines)+'\n'


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Analyze Android APKs for external input / WebView / Bridge path candidates."
    )
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command", required=True)
    scan = sub.add_parser(
        "analyze", help="Read APK bytecode without installing or running the app"
    )
    scan.add_argument("apk", type=Path)
    scan.add_argument("--engine", choices=("demand","legacy"), default="demand")
    scan.add_argument("--focus-method",action="append",default=[],help="Limit loading seeds to methods containing this signature fragment (repeatable); still index the full APK")
    scan.add_argument(
        "-o", "--output", type=Path, help="Write JSON report; default: JSON on stdout"
    )
    scan.add_argument("--text", type=Path, help="Also write readable text report")
    scan.add_argument("--max-steps", type=int, default=100_000)
    scan.add_argument("--max-depth", type=int, default=48)
    scan.add_argument("--max-states", type=int, default=64)
    scan.add_argument(
        "--timeout",
        type=float,
        default=60,
        help="Analysis-only seconds; excludes APK parsing",
    )
    scan.add_argument("--max-icc-hops", type=int, default=3)
    scan.add_argument("--max-allocations-per-site", type=int, default=4)
    scan.add_argument(
        "--max-apk-mib",
        type=int,
        default=512,
        help="Maximum total declared ZIP uncompressed size",
    )
    options = parser.parse_args(argv)
    try:
        if options.max_apk_mib <= 0:
            raise ValueError("--max-apk-mib must be positive")
        limits = Limits(
            options.max_steps,
            options.max_depth,
            options.max_states,
            options.timeout,
            options.max_icc_hops,
            options.max_allocations_per_site,
        )
        if (
            options.output
            and options.output.resolve() == options.apk.resolve()
            or options.text
            and options.text.resolve() == options.apk.resolve()
        ):
            raise ValueError("Output must not replace input APK")
        if (
            options.output
            and options.text
            and options.output.resolve() == options.text.resolve()
        ):
            raise ValueError("JSON and text output paths must differ")
        import time

        started = time.monotonic()
        program = load_apk(options.apk, options.max_apk_mib * 1024 * 1024)
        parse_seconds = time.monotonic() - started
        if options.engine == "legacy" and options.focus_method:
            raise ValueError("--focus-method is only supported by the demand engine")
        report = (Backward(program, limits, focus_methods=options.focus_method)
                  if options.engine == "demand" else Analyzer(program, limits)).run()
        report["metrics"]["parse_seconds"] = round(parse_seconds, 6)
        report["metrics"]["total_seconds"] = round(time.monotonic() - started, 6)
        try:
            import resource

            rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            report["metrics"]["peak_rss_mib"] = round(
                rss / (1024 * 1024 if sys.platform == "darwin" else 1024), 3
            )
            report["metrics"]["peak_rss_scope"] = "process lifetime high-water mark"
        except ImportError:
            report["metrics"]["peak_rss_mib"] = None
        content = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
        if options.output:
            write_atomic(options.output, content)
        else:
            sys.stdout.write(content)
        if options.text:
            write_atomic(options.text, text_report(report))
        print(
            f"DOTORI: {len(report['candidates'])} candidates, {report['status']}",
            file=sys.stderr,
        )
        return 3 if report["status"] == "incomplete" else 0
    except (InputError, ValueError, OSError) as exc:
        print(f"DOTORI: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
