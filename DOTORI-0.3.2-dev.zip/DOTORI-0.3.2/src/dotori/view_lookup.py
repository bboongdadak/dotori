"""Bounded, nullable View lookup results, scoped to one lookup occurrence.

An ID is a selector, never an allocation identity. Two separate lookups do not
alias merely because their roots and IDs match. A returned reference can still
be followed through the caller's ordinary argument/field provenance.
"""
from dataclasses import replace
import json

from .model import split_ref
from .state_summaries import _guarded, _reader_frames
from .view_state import VIEW, WEBVIEW, _allocated_type, _custom_implementation

GROUP = 'Landroid/view/ViewGroup;'
ACTIVITY = 'Landroid/app/Activity;'
BINDINGS = 'Landroidx/viewbinding/ViewBindings;'
DESC = '(I)' + VIEW
CHILD = BINDINGS + '->findChildViewById(' + VIEW + 'I)' + VIEW
COUNT = GROUP + '->getChildCount()I'
CHILD_AT = GROUP + '->getChildAt(I)' + VIEW
FIND = VIEW + '->findViewById' + DESC
APPCOMPAT = 'Landroidx/appcompat/app/AppCompatActivity;'


def _content_setter_custom(a,method,call,ctx,roots):
    if not _custom_implementation(a,method,call,ctx,roots):return False
    owner,name,desc=split_ref(call.ref);target=a.p.resolve(owner,name,desc)
    if target is None or target.owner!=APPCOMPAT or desc!='(I)V' or target.has_exceptions:return True
    gets=[];sets=[]
    for ins in target.instructions:
        if ins.op.startswith(('iput','sput','aput','if-','goto','throw')):return True
        if not ins.op.startswith('invoke-'):continue
        actual=a.actuals(ins)
        if ins.ref==APPCOMPAT+'->getDelegate()Landroidx/appcompat/app/AppCompatDelegate;' and actual and _formal(a,target,actual[0],ins.offset)==0:gets.append(ins.offset)
        elif ins.ref=='Landroidx/appcompat/app/AppCompatDelegate;->setContentView(I)V' and len(actual)==2 and _formal(a,target,actual[1],ins.offset)==1:
            sources=_call_sources(a,target,actual[0],ins.offset)
            if not sources or not sources<=set(gets):return True
            sets.append(ins.offset)
        elif ins.ref==APPCOMPAT+'->initViewTreeOwners()V' and actual and _formal(a,target,actual[0],ins.offset)==0:continue
        else:return True
    if len(sets)!=1:return True
    for base in roots:
        delegate=a.p.resolve(base.typ,'getDelegate','()Landroidx/appcompat/app/AppCompatDelegate;')
        if delegate and delegate.owner!=APPCOMPAT:return True
    return False


def _lookup_custom(a,method,call,ctx,roots=None):
    if not _custom_implementation(a,method,call,ctx,roots or ()):return False
    owner,name,desc=split_ref(call.ref)
    target=a.p.resolve(owner,name,desc)
    if target is None or target.owner!=APPCOMPAT:return True
    # Validate the standard delegate-return wrapper; an application override
    # or a bundled lookalike returning unrelated objects retains normal tracing.
    if target.has_exceptions:return True
    gets=[];finds=[]
    for ins in target.instructions:
        if not ins.op.startswith('invoke-'):continue
        actual=a.actuals(ins)
        if ins.ref==APPCOMPAT+'->getDelegate()Landroidx/appcompat/app/AppCompatDelegate;' and actual and _formal(a,target,actual[0],ins.offset)==0:
            gets.append(ins.offset)
        elif ins.ref=='Landroidx/appcompat/app/AppCompatDelegate;->findViewById'+DESC and len(actual)==2 and _formal(a,target,actual[1],ins.offset)==1:
            sources=_call_sources(a,target,actual[0],ins.offset)
            if not sources or not sources<=set(gets):return True
            finds.append(ins.offset)
        else:return True
    returns=[i for i in target.instructions if i.op=='return-object']
    if not finds or not returns or any(not (sources:=_call_sources(a,target,i.regs[0],i.offset)) or not sources<=set(finds) for i in returns):return True
    for base in roots or ():
        delegate=a.p.resolve(base.typ,'getDelegate','()Landroidx/appcompat/app/AppCompatDelegate;')
        if delegate and delegate.owner!=APPCOMPAT:return True
    return False


def _formal(a, method, reg, before, seen=frozenset()):
    """Merge duplicate guard paths only when their actual definition agrees."""
    key = (reg, before)
    if key in seen or len(seen) > 16:
        return None
    definitions = {i.offset if i is not None else None: i
                   for i, _ in a.definitions(method.ref, reg, before)}
    if len(definitions) != 1:
        return None
    instruction = next(iter(definitions.values()))
    if instruction is None:
        formals = method.argument_registers()
        return formals.index(reg) if reg in formals else None
    if instruction.op == 'check-cast':
        return _formal(a, method, reg, instruction.offset, seen | {key})
    if instruction.op.startswith('move') and not instruction.op.startswith('move-result'):
        return _formal(a, method, instruction.regs[1], instruction.offset, seen | {key})
    return None


def _view_type(a, typ):
    return typ in (VIEW, GROUP, WEBVIEW) or any(a.p.is_subtype(typ, parent)
                                               for parent in (VIEW, GROUP, WEBVIEW))


def _activity_type(a, typ):
    return typ == ACTIVITY or a.p.is_subtype(typ, ACTIVITY)


def _call_sources(a, method, reg, before, seen=frozenset()):
    """Identify a local result register without following application calls."""
    key = (reg, before)
    if key in seen or len(seen) > 16:
        return None
    out = set()
    for instruction, _ in a.definitions(method.ref, reg, before):
        if instruction is None:
            return None
        if instruction.op.startswith('const') and instruction.literal == 0:
            out.add(None)
        elif instruction.op.startswith('move-result'):
            prior = [i for i in method.instructions if i.offset < instruction.offset]
            if not prior or not prior[-1].op.startswith('invoke-'):
                return None
            out.add(prior[-1].offset)
        elif instruction.op == 'check-cast' or instruction.op.startswith('move'):
            source = reg if instruction.op == 'check-cast' else instruction.regs[1]
            values = _call_sources(a, method, source, instruction.offset, seen | {key})
            if values is None:
                return None
            out |= values
        else:
            return None
    return out


def _standard_child_helper(a):
    """Validate bundled helper return provenance rather than trusting its name.

    Every non-null return must come from root.getChildAt(...).findViewById(id).
    External copies use the documented exact AndroidX signature. Bundled copies
    with writes, unknown calls, or different return sources use their real body.
    """
    method = a.p.methods.get(CHILD)
    if method is None:
        return True
    if 'static' not in method.access.split() or not method.instructions or method.has_exceptions:
        return False
    find_calls = set()
    child_calls = set()
    for call in method.instructions:
        if call.op.startswith(('iput', 'sput', 'aput', 'new-', 'filled-new', 'monitor-')):
            return False
        if not call.op.startswith('invoke-'):
            continue
        actual = a.actuals(call)
        if call.op not in ('invoke-virtual', 'invoke-virtual/range'):
            return False
        if call.ref in (COUNT, CHILD_AT):
            if not actual or _formal(a, method, actual[0], call.offset) != 0:
                return False
            if call.ref == CHILD_AT:
                child_calls.add(call.offset)
        elif call.ref == FIND:
            if len(actual) != 2 or _formal(a, method, actual[1], call.offset) != 1:
                return False
            sources = _call_sources(a, method, actual[0], call.offset)
            if not sources or not sources <= child_calls:
                return False
            find_calls.add(call.offset)
        else:
            return False
    returns = [i for i in method.instructions if i.op == 'return-object' and i.regs]
    if not find_calls or not returns:
        return False
    for ret in returns:
        sources = _call_sources(a, method, ret.regs[0], ret.offset)
        if not sources or not sources <= find_calls | {None}:
            return False
    return True


def _in_loop(method, offset):
    for instruction in method.instructions:
        targets = ([instruction.target] if instruction.target is not None else [])
        targets += [target for _, target in instruction.cases]
        if any(target <= offset <= instruction.offset for target in targets):
            return True
    return False


def _repeated_occurrence(a, method, offset, ctx):
    for ref, (before, _) in _reader_frames(a, method, offset, ctx).items():
        if _in_loop(a.p.methods[ref], before):
            return True
    return False


def _known_non_group(a, origin):
    typ = _allocated_type(a, origin) if origin.kind == 'allocation' else ''
    seen = set()
    while typ and typ not in seen:
        if typ in (GROUP, WEBVIEW):
            return False
        if typ == VIEW:
            return True
        seen.add(typ)
        typ = a.p.supers.get(typ, '')
    return False


def _content_roots(a, method, call, base, ctx, depth):
    """Require a local, same-receiver content generation for Activity lookup."""
    from .demand import Origin, compatible
    chosen = None
    for setter in method.instructions:
        if setter.offset >= call.offset:
            break
        if not setter.ref or '(' not in setter.ref or setter.op.startswith('invoke-static'):
            continue
        owner, name, desc = split_ref(setter.ref)
        if name != 'setContentView' or not _activity_type(a, owner):
            continue
        actual = a.actuals(setter)
        if len(actual) < 2:
            return ()
        receivers = a.trace(method.ref, actual[0], setter.offset, 'object', ctx, depth)
        if not receivers:
            return ()
        if all(v.key != base.key for v in receivers):
            continue
        if (len(receivers) != 1 or not compatible(receivers[0], base)
                or _content_setter_custom(a, method, setter, ctx, receivers)):
            return ()
        chosen = (setter, desc, actual[1], receivers[0])
    if chosen is None:
        # A lifecycle template can install content and invoke this helper on
        # the same component. Do not merge another Activity's layout or an
        # arbitrary writer merely because its resource ID matches.
        if base.kind!='component':return ()
        out=[]
        for site in a.callers(method.ref):
            caller=a.p.methods[site.method]
            if caller.name!='onCreate' or caller.descriptor not in ('(Landroid/os/Bundle;)V','(Landroid/os/Bundle;Landroid/os/PersistableBundle;)V'):continue
            if not a.p.is_subtype(base.typ,caller.owner):continue
            dispatch=a.instruction(site.method,site.offset)
            if not dispatch or not dispatch.regs or not a.is_local_this(caller,dispatch.regs[0],dispatch.offset):continue
            impl=a.p.resolve(base.typ,method.name,method.descriptor)
            if impl is None or impl.ref!=method.ref:continue
            parent=a.component_context(caller,base)
            for root in _content_roots(a,caller,dispatch,base,parent,depth+1):
                out.append(root.step('activity_content_before_helper:'+a.site(caller.ref,dispatch.offset)))
        return tuple(out)
    setter, desc, reg, receiver = chosen
    # Branches before a dominating setter do not invalidate the current tree.
    _,_,pred=a.cfg(method.ref)
    todo=[call.offset];seen=set();dominates=True
    while todo and len(seen)<2000:
        at=todo.pop()
        if at==setter.offset:continue
        if at in seen:continue
        seen.add(at)
        parents=pred.get(at,())
        if not parents:dominates=False;break
        todo.extend(source for source,_ in parents)
    if todo or not dominates:
        if todo:a.note('view_lookup_content_order_limit',a.site(method.ref,call.offset))
        return ()
    roots = a.trace(method.ref, reg, setter.offset, 'object' if desc == '(' + VIEW + ')V' else 'value', ctx, depth)
    if desc == '(' + VIEW + ')V':
        return tuple(replace(v, guards=v.guards | receiver.guards | base.guards,
                             callback_instances=v.callback_instances | receiver.callback_instances | base.callback_instances)
                     for v in roots if _root(a, v) and compatible(v, receiver) and compatible(v, base))
    if desc != '(I)V' or len(roots) != 1 or roots[0].kind != 'constant':
        return ()
    layout = roots[0]
    if (not layout.value.isdecimal() or int(layout.value) <= 0
            or not compatible(layout, receiver) or not compatible(layout, base)):
        return ()
    return (Origin('view', 'content_layout:' + a.allocation_key(method, setter, ctx)
                   + ':receiver:' + base.key + ':layout:' + layout.value, VIEW,
                   path=receiver.path + layout.path + (a.site(method.ref, setter.offset) + ':content_generation',),
                   guards=receiver.guards | layout.guards | base.guards,
                   callback_instances=receiver.callback_instances | layout.callback_instances | base.callback_instances),)


def _root(a, origin):
    if origin.kind in ('view', 'view_lookup'):
        return True
    return origin.kind == 'allocation' and _view_type(a, _allocated_type(a, origin))


def result(a, method, call, mode, ctx, depth):
    if not call.ref or '(' not in call.ref:
        return None
    owner, name, desc = split_ref(call.ref)
    child = call.ref == CHILD and call.op.startswith('invoke-static')
    framework = (name == 'findViewById' and desc == DESC
                 and not call.op.startswith('invoke-static')
                 and (_view_type(a, owner) or _activity_type(a, owner)))
    if not child and not framework:
        return None
    if child and not _standard_child_helper(a):
        return None
    if framework and _lookup_custom(a, method, call, ctx):
        return None
    actual = a.actuals(call)
    where = a.site(method.ref, call.offset)
    if len(actual) != 2:
        a.note('view_lookup_arguments_unresolved', where)
        return ()
    if _repeated_occurrence(a, method, call.offset, ctx):
        a.note('view_lookup_lifetime_unresolved', where)
        return ()
    roots = a.trace(method.ref, actual[0], call.offset, 'object', ctx, depth)
    if framework and _lookup_custom(a, method, call, ctx, roots):
        return None
    ids = a.trace(method.ref, actual[1], call.offset, 'value', ctx, depth)
    if len(ids) != 1 or ids[0].kind != 'constant' or not ids[0].value.lstrip('-').isdecimal():
        a.note('view_lookup_id_unresolved', where)
        return ()
    selector = ids[0]
    from .demand import Origin, compatible
    out = []
    for base in roots:
        if not compatible(base, selector):
            continue
        if base.kind == 'constant' and base.value == '0':
            a.note('view_lookup_null_root', where)
            if child:
                out.append(replace(base, guards=base.guards | selector.guards,
                                   callback_instances=base.callback_instances | selector.callback_instances))
            continue
        if selector.value == '-1' or child and _known_non_group(a, base):
            out.append(Origin('constant', '0', value='0', path=base.path + (where + ':lookup_null',),
                              guards=base.guards | selector.guards,
                              callback_instances=base.callback_instances | selector.callback_instances))
            continue
        if int(selector.value) < 0:
            a.note('view_lookup_id_unresolved', where)
            continue
        candidates = _content_roots(a, method, call, base, ctx, depth) if _activity_type(a, owner) else (base,)
        if not candidates:
            a.note('view_lookup_content_root_unresolved', where)
        for root in candidates:
            if not _root(a, root) or not compatible(root, selector):
                a.note('view_lookup_root_unresolved', where)
                continue
            typ = _allocated_type(a, root)
            if typ and a.p.resolve(typ, 'findViewTraversal', DESC):
                a.note('view_lookup_traversal_override_unresolved', where)
                continue
            if child and typ and (a.p.resolve(typ, 'getChildAt', '(I)' + VIEW)
                                  or a.p.resolve(typ, 'getChildCount', '()I')):
                a.note('view_lookup_traversal_override_unresolved', where)
                continue
            scope = 'descendants' if child else 'self_or_descendant'
            key = 'view_lookup:' + json.dumps((a.allocation_key(method, call, ctx), root.key,
                                              selector.value, scope), separators=(',', ':'))
            proof = (where + ':view_lookup:' + scope, 'view_lookup_root:' + root.key,
                     'view_lookup_id:' + selector.value, 'view_lookup_nonnull_assumed')
            if child and not (typ in (GROUP, WEBVIEW) or a.p.is_subtype(typ, GROUP)):
                proof += ('view_lookup_viewgroup_assumed',)
                a.note('view_lookup_root_type_unresolved', where)
            out.append(Origin('view_lookup', key, VIEW, root.entry, path=root.path + selector.path + proof,
                              guards=root.guards | selector.guards,
                              callback_instances=root.callback_instances | selector.callback_instances))
            a.note('view_lookup_nullable_result', where)
    if not roots:
        a.note('view_lookup_root_unresolved', where)
    return tuple(out)
