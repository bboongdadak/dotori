"""Bounded, context-specific android.net.Uri.Builder state transfers.

Only exact framework signatures and actual Builder allocations/buildUpon
factories qualify. Replay a known instance up to a build/toString snapshot;
replacement, append and clear operations act on separate component slots.
Unknown calls, escaping aliases, non-linear replay and lifecycle order remain
explicit gaps. An incoming, unpartitioned Uri is conservatively attributed to
all hierarchical components, never assumed to contain a particular field.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from .model import split_ref

URI = 'Landroid/net/Uri;'
BUILDER = 'Landroid/net/Uri$Builder;'
STRING = 'Ljava/lang/String;'
PARTS = ('scheme', 'authority', 'path', 'query', 'fragment')
SETTERS = {'scheme': 'scheme', 'authority': 'authority', 'encodedAuthority': 'authority',
           'path': 'path', 'encodedPath': 'path', 'query': 'query',
           'encodedQuery': 'query', 'fragment': 'fragment', 'encodedFragment': 'fragment'}
APPENDERS = {'appendPath': 'path', 'appendEncodedPath': 'path'}
BUILD_UPON = URI + '->buildUpon()' + BUILDER
MUTATORS = {(name, '(' + STRING + ')' + BUILDER) for name in SETTERS | APPENDERS}
MUTATORS |= {('appendQueryParameter', '(' + STRING + STRING + ')' + BUILDER),
             ('clearQuery', '()' + BUILDER)}
SNAPSHOTS = {('build', '()' + URI), ('toString', '()' + STRING)}
MAX_EVENTS = 512
MAX_HELPER_DEPTH = 8


@dataclass(frozen=True)
class Operand:
    method: str
    register: int
    before: int
    context: int
    write: str


class Unresolved(Exception):
    def __init__(self, code, detail):
        self.code, self.detail = 'uri_builder_' + code, detail


def _frames(a, method, call, ctx):
    frames = [(method, call.offset, ctx)]
    seen = set()
    while ctx and ctx not in seen:
        seen.add(ctx)
        bindings = list(a.contexts.get(ctx, {}).values())
        if not bindings:
            break
        ref, _, offset, ctx = bindings[0]
        method = a.p.methods.get(ref)
        if not method:
            break
        frames.append((method, offset, ctx))
    return list(reversed(frames))


def _creation(a, base):
    try:
        ref, offset = base.key.split(':call_context:', 1)[0].rsplit('@', 1)
        call = a.instruction(ref, int(offset, 16))
    except (ValueError, KeyError):
        return None
    if not call:
        return None
    if base.kind == 'allocation' and call.op == 'new-instance' and call.literal == BUILDER:
        return ref, call
    if base.kind == 'uri_builder' and call.ref == BUILD_UPON and call.op.startswith('invoke-virtual'):
        return ref, call
    return None


def _base(a, origins):
    return origins[0] if len(origins) == 1 and _creation(a, origins[0]) else None


class Replay:
    def __init__(self, a, base, method, call, ctx, depth):
        self.a, self.base, self.depth = a, base, depth
        self.frames = _frames(a, method, call, ctx)
        self.parts = {part: [] for part in PARTS}
        self.initialized = False
        self.events = 0
        self.proof = []

    def fail(self, code, where):
        raise Unresolved(code, where)

    def original(self, m, creation, ctx):
        reg = self.a.actuals(creation)[0]
        objects = self.a.trace(m.ref, reg, creation.offset, 'object', ctx, self.depth + 1)
        if len(objects) == 1 and objects[0].kind == 'uri_snapshot':
            snap = objects[0]
            location = self.a.allocation_contexts.get(snap.key)
            if not location:
                self.fail('snapshot_unresolved', snap.key)
            ref, off = snap.key.split(':call_context:', 1)[0].rsplit('@', 1)
            maker = self.a.instruction(ref, int(off, 16))
            replay = _snapshot(self.a, self.a.p.methods[ref], maker, location[1], self.depth + 1)
            self.parts = {part: list(values) for part, values in replay.parts.items()}
            self.proof.extend(replay.proof)
            self.base = replace(self.base, guards=self.base.guards | replay.base.guards,
                callback_instances=self.base.callback_instances | replay.base.callback_instances)
        else:
            # Exact component partition is unknown for external/parsed Uris.
            # Replacing or clearing one part cannot erase possible other parts.
            values = self.a.trace(m.ref, reg, creation.offset, 'value', ctx, self.depth + 1)
            if not values:
                self.fail('base_value_unresolved', self.a.site(m.ref, creation.offset))
            self.parts = {part: list(values) for part in PARTS}
            self.proof.append('uri_builder_base_components_unknown')
        self.initialized = True
        self.proof.append('uri_builder_copy:' + self.a.site(m.ref, creation.offset))

    def flow_graph(self, m, where):
        if len(m.instructions) > MAX_EVENTS or not self.a.allowed(self.depth):
            self.fail('control_flow_limit', where)
        successors, by_offset = {}, {i.offset:i for i in m.instructions}
        for n, i in enumerate(m.instructions):
            after = m.instructions[n + 1].offset if n + 1 < len(m.instructions) else None
            if i.op.startswith(('return', 'throw')):
                targets = []
            elif i.op.startswith('goto'):
                targets = [i.target]
            elif i.op.startswith('if-'):
                targets = [after, i.target]
            elif i.op in ('packed-switch', 'sparse-switch'):
                targets = [after] + [v for _, v in i.cases]
            else:
                targets = [after]
            targets += [handler for begin, end, handler, _ in m.exception_handlers
                        if begin <= i.offset < end and self.a.may_throw(i)]
            successors[i.offset] = [target for target in targets if target is not None]
        return successors, by_offset

    def handler_exits_before_read(self, handler, stop, graph, by_offset):
        # Require every reachable handler path to terminate outside the read.
        # Cycles and unknown/invalid targets do not constitute that proof.
        todo, colors = [(handler, False)], {}
        while todo:
            offset, finish = todo.pop()
            if offset == stop or offset not in by_offset:
                return False
            if finish:
                colors[offset] = 2
                continue
            if colors.get(offset) == 1:
                return False
            if colors.get(offset) == 2:
                continue
            colors[offset] = 1
            todo.append((offset, True))
            targets = graph.get(offset, ())
            if not targets and not by_offset[offset].op.startswith(('return', 'throw')):
                return False
            todo.extend((target, False) for target in targets)
        return True

    @staticmethod
    def reachable(graph, roots):
        todo, seen = list(roots), set()
        while todo:
            offset = todo.pop()
            if offset in seen:
                continue
            seen.add(offset)
            todo.extend(graph.get(offset, ()))
        return seen

    def check_interval(self, m, start, stop, instructions, level):
        """Replay one normal-success segment with bounded exception/loop proof."""
        where = self.a.site(m.ref, stop)
        if any(i.op.startswith(('if-', 'goto', 'throw', 'return')) or
                i.op in ('packed-switch', 'sparse-switch') for i in instructions
                if not (level and i.op.startswith('return-void'))):
            self.fail('control_flow_unresolved', where)
        selected = [i for i in m.instructions if start <= i.offset <= stop]
        if m.has_exceptions and not m.exception_handlers:
            self.fail('exception_flow_unresolved', where)
        covering = {handler for begin, end, handler, _ in m.exception_handlers
                    if start <= handler <= stop or any(
                        begin <= i.offset < end and self.a.may_throw(i) for i in selected)}
        graph, by_offset = None, None
        if covering:
            # A caught return inside a writer helper rejoins the caller's read;
            # interprocedural exception-sensitive mutation remains unsupported.
            if level:
                self.fail('exception_flow_unresolved', where)
            graph, by_offset = self.flow_graph(m, where)
            if any(not self.handler_exits_before_read(handler, stop, graph, by_offset)
                   for handler in covering):
                self.fail('exception_flow_unresolved', where)
            self.proof.append('uri_builder_normal_success_assumed:' + where)
            self.a.note('uri_builder_exception_success_assumed', where)
        backwards = []
        for i in m.instructions:
            targets = ([i.target] if i.target is not None else []) + [v for _, v in i.cases]
            if any(start < target <= stop for target in targets):
                self.fail('control_flow_unresolved', where)
            if i.offset > stop:
                backwards.extend((i.offset, target) for target in targets if target <= stop)
        if not backwards:
            return
        if graph is None:
            graph, by_offset = self.flow_graph(m, where)
        following = self.reachable(graph, [stop])
        destinations = [target for source, target in backwards if source in following]
        revisited = self.reachable(graph, destinations)
        if any(start <= offset <= stop for offset in revisited):
            # Reject true cycles rather than merging separate allocation
            # iterations or claiming a cross-iteration builder lifetime.
            self.fail('loop_unresolved', where)

    def scan(self, m, start, stop, ctx, aliases, level=0, pending=False):
        if level > MAX_HELPER_DEPTH:
            self.fail('helper_depth_limit', m.ref)
        instructions = [i for i in m.instructions if start < i.offset < stop]
        self.check_interval(m, start, stop, instructions, level)
        for i in instructions:
            self.events += 1
            where = self.a.site(m.ref, i.offset)
            if self.events > MAX_EVENTS or not self.a.allowed(self.depth + level):
                self.fail('replay_limit', where)
            if i.op.startswith('invoke-'):
                args = self.a.actuals(i)
                carried = [n for n, reg in enumerate(args) if reg in aliases]
                pending = False
                if not carried:
                    continue
                if not i.ref or '(' not in i.ref:
                    self.fail('escape_unresolved', where)
                owner, name, desc = split_ref(i.ref)
                static = i.op.startswith('invoke-static')
                if owner == BUILDER and not static and carried == [0]:
                    if name == '<init>' and desc == '()V' and i.op.startswith('invoke-direct'):
                        if self.initialized:
                            self.fail('initialization_unresolved', where)
                        self.initialized = True
                    elif not self.initialized:
                        self.fail('initialization_unresolved', where)
                    elif (name, desc) in MUTATORS:
                        values = [Operand(m.ref, reg, i.offset, ctx, where) for reg in args[1:]]
                        if name in SETTERS:
                            self.parts[SETTERS[name]] = values
                        elif name in APPENDERS:
                            self.parts[APPENDERS[name]].extend(values)
                        elif name == 'appendQueryParameter':
                            self.parts['query'].extend(values)
                        else:
                            self.parts['query'] = []
                        self.proof.append('uri_builder_write:' + where + ':' + name)
                        pending = True
                    elif (name, desc) in SNAPSHOTS:
                        pass  # A prior immutable snapshot does not alias Builder.
                    else:
                        self.fail('mutation_unresolved', where + ':' + i.ref)
                else:
                    # Only exact static/direct helpers with no returned alias.
                    target = self.a.p.methods.get(i.ref) if i.op.startswith(('invoke-static', 'invoke-direct')) else None
                    if not target or {'abstract', 'native'}.intersection(target.access.split()):
                        self.fail('escape_unresolved', where + ':' + i.ref)
                    child = self.a.binding(m.ref, i, target, ctx)
                    formals = target.argument_registers()
                    mapping = {formals[n] for n in carried if n < len(formals)}
                    self.proof.append('uri_builder_helper:' + where)
                    self.scan(target, -1, max((j.offset for j in target.instructions), default=-1) + 1,
                              child, mapping, level + 1)
            elif i.op.startswith(('iput', 'sput', 'aput', 'return')):
                if i.regs and i.regs[0] in aliases:
                    self.fail('escape_unresolved', where)
                if i.op.startswith('iput') and len(i.regs) > 1 and i.regs[1] in aliases:
                    self.fail('mutation_unresolved', where)
                if i.op.startswith('return'):
                    break
            elif i.op.startswith('iget') and len(i.regs) > 1 and i.regs[1] in aliases:
                self.fail('escape_unresolved', where)
            elif i.op.startswith('filled-new-array') and any(reg in aliases for reg in i.regs):
                self.fail('escape_unresolved', where)
            elif i.op == 'check-cast':
                pass
            elif i.op.startswith('move-result'):
                if i.regs:
                    aliases.discard(i.regs[0])
                    if pending:
                        aliases.add(i.regs[0])
                pending = False
            elif i.op.startswith('move') and len(i.regs) > 1:
                same = i.regs[1] in aliases
                aliases.discard(i.regs[0])
                if same:
                    aliases.add(i.regs[0])
            elif i.regs and self.a.defines(i, i.regs[0]):
                aliases.discard(i.regs[0])
        return aliases

    def run(self, method, call, ctx):
        ref, creation = _creation(self.a, self.base)
        location = self.a.allocation_contexts.get(self.base.key)
        root = next((n for n, (m, _, c) in enumerate(self.frames)
                     if m.ref == ref and location == (ref, c)), None)
        if root is None:
            self.fail('lifecycle_order_unresolved', self.base.key)
        if creation.ref == BUILD_UPON:
            self.original(self.frames[root][0], creation, self.frames[root][2])
            aliases = set()
            pending = True
        else:
            aliases = {creation.regs[0]}
            pending = False
        for n, (m, stop, context) in enumerate(self.frames[root:], root):
            aliases = self.scan(m, creation.offset if n == root else -1, stop,
                                context, aliases, pending=pending if n == root else False)
            if n + 1 < len(self.frames):
                invocation = self.a.instruction(m.ref, stop)
                child = self.frames[n + 1][0]
                actual = self.a.actuals(invocation)
                aliases = {formal for formal, reg in zip(child.argument_registers(), actual) if reg in aliases}
        actual = self.a.actuals(call)
        if not actual or actual[0] not in aliases:
            self.fail('receiver_alias_unresolved', self.a.site(method.ref, call.offset))
        if not self.initialized:
            self.fail('initialization_unresolved', self.a.site(method.ref, call.offset))
        self.proof += ['uri_builder_object:' + self.base.key,
                       'uri_builder_snapshot:' + self.a.site(method.ref, call.offset)]
        return self

    def values(self):
        from .demand import compatible
        out = []
        for part, operands in self.parts.items():
            for operand in operands:
                values = (self.a.trace(operand.method, operand.register, operand.before,
                                      'value', operand.context, self.depth + 1)
                          if isinstance(operand, Operand) else (operand,))
                if not values:
                    self.a.note('uri_builder_value_unresolved', self.base.key + ':' + part)
                for value in values:
                    if compatible(value, self.base):
                        out.append(replace(value, path=value.path + tuple(self.proof) + ('uri_component:' + part,),
                            guards=value.guards | self.base.guards,
                            callback_instances=value.callback_instances | self.base.callback_instances))
        return tuple(out)


def _snapshot(a, method, call, ctx, depth):
    if not a.allowed(depth):
        raise Unresolved('replay_limit', a.site(method.ref, call.offset))
    actual = a.actuals(call)
    bases = a.trace(method.ref, actual[0], call.offset, 'object', ctx, depth + 1) if actual else ()
    base = _base(a, bases)
    if not base:
        raise Unresolved('receiver_alias_unresolved', a.site(method.ref, call.offset))
    return Replay(a, base, method, call, ctx, depth).run(method, call, ctx)


def result(a, method, call, mode, ctx, depth):
    if not call.ref or '(' not in call.ref or not call.op.startswith('invoke-virtual'):
        return None
    owner, name, desc = split_ref(call.ref)
    actual = a.actuals(call)
    if not actual:
        return None
    # Never replace app-provided implementations with an API-name guess.
    if a.p.methods.get(call.ref) is not None:
        return None
    if call.ref == BUILD_UPON and any(
            a.p.resolve(typ, name, desc) is not None
            for typ in a.known_receiver_types(method, actual[0], call.offset, ctx)):
        return None
    where = a.site(method.ref, call.offset)
    if call.ref == BUILD_UPON:
        from .demand import Origin
        key = a.allocation_key(method, call, ctx)
        return (Origin('uri_builder', key, BUILDER, path=('uri_builder_factory:' + where,)),)
    if owner != BUILDER:
        return None
    if (name, desc) in MUTATORS:
        origins = a.trace(method.ref, actual[0], call.offset, 'object', ctx, depth + 1)
        base = _base(a, origins)
        if not base:
            a.note('uri_builder_receiver_alias_unresolved', where)
            return ()
        return (base.step('uri_builder_fluent_alias:' + where),)
    if (name, desc) not in SNAPSHOTS:
        return None
    try:
        replay = _snapshot(a, method, call, ctx, depth)
    except Unresolved as gap:
        a.note(gap.code, gap.detail)
        return ()
    if mode == 'object' and name == 'build':
        from .demand import Origin
        key = a.allocation_key(method, call, ctx)
        return (Origin('uri_snapshot', key, URI, path=tuple(replay.proof),
                       guards=replay.base.guards, callback_instances=replay.base.callback_instances),)
    return replay.values()
