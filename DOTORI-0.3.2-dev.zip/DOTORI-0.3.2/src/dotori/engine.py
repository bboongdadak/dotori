"""Bounded, context-sensitive symbolic DEX execution with object-sensitive heap.

Only explicit library summaries propagate values. Unknown code never acquires an
invented taint-return edge. Branch states remain separate; bounds are reported.
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field, replace
from itertools import pairwise

from .model import (
    Component,
    Program,
    dex_name,
    parameters,
    split_ref,
)

WV = "Landroid/webkit/WebView;"
INTENT = "Landroid/content/Intent;"
JS = "Landroid/webkit/JavascriptInterface;"


@dataclass(frozen=True)
class Value:
    objects: frozenset[str] = frozenset()
    constants: frozenset[str | int] = frozenset()
    sources: frozenset[str] = frozenset()
    proof: frozenset[str] = frozenset()
    unknown: bool = False

    def signature(self):
        return (
            tuple(sorted(self.objects)),
            tuple(sorted(self.constants, key=str)),
            tuple(sorted(self.sources)),
            self.unknown,
        )


UNKNOWN = Value(unknown=True)


def combine(values):
    values = list(values)
    return Value(
        frozenset().union(*(v.objects for v in values)),
        frozenset().union(*(v.constants for v in values)),
        frozenset().union(*(v.sources for v in values)),
        frozenset().union(*(v.proof for v in values)),
        any(v.unknown for v in values),
    )


@dataclass(frozen=True)
class Limits:
    max_steps: int = 100_000
    max_depth: int = 16
    max_states: int = 64
    timeout_seconds: float = 60.0
    max_icc_hops: int = 3
    max_allocations_per_site: int = 4

    def __post_init__(self):
        if (
            min(
                self.max_steps,
                self.max_depth,
                self.max_states,
                self.max_allocations_per_site,
            )
            < 1
            or self.timeout_seconds <= 0
            or self.max_icc_hops < 0
        ):
            raise ValueError("Analysis bounds must be positive (ICC hops may be zero)")


@dataclass
class State:
    heap: dict[tuple[str, str], Value] = field(default_factory=dict)
    events: tuple[dict, ...] = ()
    pending: tuple[tuple[str, Value], ...] = ()
    callbacks: tuple[tuple[str, Value], ...] = ()
    allocations: dict[str, int] = field(default_factory=dict)
    initialized: frozenset[str] = frozenset()

    def copy(self):
        return State(
            self.heap.copy(),
            self.events,
            self.pending,
            self.callbacks,
            self.allocations.copy(),
            self.initialized,
        )

    def signature(self):
        return (
            tuple(sorted((k, v.signature()) for k, v in self.heap.items())),
            tuple(e["id"] for e in self.events),
            tuple((x, v.signature()) for x, v in self.pending),
            tuple((x, v.signature()) for x, v in self.callbacks),
            tuple(sorted(self.allocations.items())),
            tuple(sorted(self.initialized)),
        )


class Analyzer:
    def __init__(self, program: Program, limits: Limits | None = None):
        self.p = program
        self.limits = limits or Limits()
        self.notes = {(d["code"], d.get("detail", "")) for d in program.diagnostics}
        self.incomplete = any(
            d["code"] in {"manifest_resource_unresolved", "duplicate_method"}
            for d in program.diagnostics
        )
        self.evidence = {}
        self.objects = {}
        self.candidates = {}
        self.loads = {}
        self.registrations = {}
        self.steps = 0
        self.calls = set()
        self.started = time.monotonic()
        self.current_entry = ""
        self.current_component: Component | None = None

    def note(self, code, detail="", incomplete=False):
        self.notes.add((code, detail))
        self.incomplete |= incomplete

    def budget(self):
        if self.steps >= self.limits.max_steps:
            self.note("step_limit", str(self.limits.max_steps), True)
            return False
        if time.monotonic() - self.started >= self.limits.timeout_seconds:
            self.note("timeout", str(self.limits.timeout_seconds), True)
            return False
        return True

    def proof(self, kind, site, detail, values=()):
        parents = sorted(frozenset().union(*(v.proof for v in values)))
        payload = {"kind": kind, "site": site, "detail": detail, "parents": parents}
        ident = (
            "e"
            + hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()[
                :16
            ]
        )
        self.evidence[ident] = payload
        return frozenset((ident,))

    def traced(self, val, kind, site, detail):
        return replace(val, proof=self.proof(kind, site, detail, [val]))

    def obj(self, ident, typ, val=UNKNOWN):
        self.objects[ident] = typ
        return Value(objects=frozenset((ident,)), sources=val.sources, proof=val.proof)

    def read(self, state, receiver, key):
        return (
            combine(state.heap.get((o, key), UNKNOWN) for o in receiver.objects)
            if receiver.objects
            else UNKNOWN
        )

    def write(self, state, receiver, key, val):
        for o in receiver.objects:
            state.heap[o, key] = (
                val
                if len(receiver.objects) == 1
                else combine([state.heap.get((o, key), UNKNOWN), val])
            )

    def source(self, receiver, site, api):
        if not receiver.sources:
            return UNKNOWN
        source = f"{self.current_entry}|{site}|{api}"
        return Value(
            sources=frozenset((source,)),
            proof=self.proof("external_input", site, api, [receiver]),
        )

    def inherited_methods(self, typ):
        result, seen, signatures = [], set(), set()
        while typ and typ not in seen:
            seen.add(typ)
            for m in self.p.methods.values():
                if m.owner != typ or (m.name, m.descriptor) in signatures:
                    continue
                signatures.add((m.name, m.descriptor))
                if "public" in m.access.split() and not m.name.startswith("<"):
                    result.append(m)
            typ = self.p.supers.get(typ, "")
        return result

    def exposure(self, bridge):
        modern, legacy = set(), set()
        unresolved = False
        for o in bridge.objects:
            typ = self.objects.get(o, "")
            if typ not in self.p.supers:
                unresolved = True
            for m in self.inherited_methods(typ):
                legacy.add(m.ref)
                if JS in m.annotations:
                    modern.add(m.ref)
        target, minimum = self.p.target_sdk, self.p.min_sdk
        if target is None:
            methods, mode = legacy, "unknown_target_public_methods_conditional"
        elif target < 17:
            methods, mode = legacy, "legacy_target_all_public"
        else:
            methods, mode = modern, "public_annotated_runtime_api_17_plus"
        legacy_runtime = minimum is None or minimum < 17
        return {
            "methods": sorted(methods),
            "mode": mode,
            "legacy_runtime_possible": legacy_runtime,
            "legacy_public_methods": sorted(legacy) if legacy_runtime else [],
            "legacy_framework_inherited_methods_unenumerated": legacy_runtime
            or (target is not None and target < 17),
            "unresolved_type": unresolved or not bridge.objects or bridge.unknown,
        }

    def record(self, state, event):
        # Repeated loop visits to the same semantic event need no duplicate entry.
        payload = {
            k: v for k, v in event.items() if k not in ("proof", "entry_permission")
        }
        event = dict(
            event,
            id="a"
            + hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()[
                :16
            ],
        )
        if event["id"] not in {e["id"] for e in state.events}:
            state.events += (event,)
        if event["kind"] == "load":
            self.loads[event["id"]] = event
        if event["kind"] == "bridge":
            self.registrations[event["id"]] = event
        self.connect(state)

    def connect(self, state):
        loads = [
            (i, e)
            for i, e in enumerate(state.events)
            if e["kind"] == "load" and e["sources"]
        ]
        bridges = [(i, e) for i, e in enumerate(state.events) if e["kind"] == "bridge"]
        for li, load in loads:
            for bi, bridge in bridges:
                shared = set(load["objects"]) & set(bridge["objects"])
                if not shared:
                    continue
                # A later removal or same-name replacement before the load kills registration.
                if bi < li and any(
                    e["kind"] in ("remove_bridge", "bridge")
                    and set(e["objects"]) & shared
                    and set(e.get("names", [])) & set(bridge["names"])
                    for e in state.events[bi + 1 : li]
                ):
                    continue
                exposure = bridge["exposure"]
                if (
                    not exposure["methods"]
                    and not exposure["legacy_public_methods"]
                    and not exposure["unresolved_type"]
                    and not exposure["legacy_framework_inherited_methods_unenumerated"]
                ):
                    continue
                identity = f"{load['id']}|{bridge['id']}|{','.join(sorted(shared))}"
                cid = "DOTORI-" + hashlib.sha256(identity.encode()).hexdigest()[:16]
                assumptions = [
                    "Static candidate; URL validation and branch predicates are not proven safe or unsafe.",
                    "Network access, content control, authentication, native impact and exploit success are unverified.",
                ]
                if bi > li:
                    assumptions.append(
                        "Registration follows observed loading; a subsequent reload is required and was not established."
                    )
                if load["javascript_enabled"] != "true":
                    assumptions.append(
                        "JavaScript enablement at loading is "
                        + load["javascript_enabled"]
                        + "."
                    )
                assumptions.append(
                    "Runtime API and targetSdk determine Bridge exposure; see exposure fields."
                )
                self.candidates[cid] = {
                    "id": cid,
                    "classification": "static_path_candidate",
                    "entry_component": self.current_entry,
                    "entry_permission": (
                        asdict(self.current_component)
                        if self.current_component
                        else None
                    ),
                    "sources": load["sources"],
                    "load": load,
                    "bridge": bridge,
                    "shared_webview_objects": sorted(shared),
                    "relation": "same_abstract_object",
                    "object_model": "call-context and allocation-occurrence identity; resource views additionally scoped by receiver and layout generation",
                    "registration_before_load": bi < li,
                    "assumptions": assumptions,
                    "evidence_roots": sorted(set(load["proof"]) | set(bridge["proof"])),
                }

    def run(self):
        entries = [c for c in self.p.components if c.enabled and c.exported]
        for component in entries:
            if not self.budget():
                break
            self.current_component, self.current_entry = component, component.name
            self.execute_component(component, State(), None, 0)
        connected = {c["load"]["id"] for c in self.candidates.values()}
        diagnostics = [{"code": c, "detail": d} for c, d in sorted(self.notes)]
        return {
            "schema_version": "1.0",
            "tool": {"name": "DOTORI", "version": "0.1.0"},
            "input": {
                "package": self.p.package,
                "sha256": self.p.sha256,
                "target_sdk": self.p.target_sdk,
                "min_sdk": self.p.min_sdk,
                "dex_count": self.p.dex_count,
            },
            "status": (
                "incomplete" if self.incomplete else "completed_with_model_limits"
            ),
            "scope": "Only modeled lifecycle, explicit calls, selected APIs and selected callbacks. Absence of candidates does not establish safety.",
            "limits": asdict(self.limits),
            "entry_points": [asdict(c) for c in entries],
            "candidates": sorted(self.candidates.values(), key=lambda c: c["id"]),
            "unlinked_external_loads": [
                e for k, e in sorted(self.loads.items()) if k not in connected
            ],
            "bridge_registrations": sorted(
                self.registrations.values(), key=lambda e: e["id"]
            ),
            "evidence": dict(sorted(self.evidence.items())),
            "diagnostics": diagnostics,
            "metrics": {
                "analysis_seconds": round(time.monotonic() - self.started, 6),
                "instructions_executed": self.steps,
                "methods_visited": len(self.calls),
                "methods_indexed": len(self.p.methods),
                "candidate_count": len(self.candidates),
                "entry_count": len(entries),
            },
        }

    def execute_component(self, component, initial_state, incoming, hop):
        if hop > self.limits.max_icc_hops:
            self.note("icc_hop_limit", component.name, True)
            return
        base = f"component:{self.current_entry}:{hop}:{component.name}"
        this = self.obj(base, component.code_class)
        if incoming is None:
            proof = self.proof(
                "manifest_entry", component.name, "exported=" + str(component.exported)
            )
            incoming = self.obj(
                base + ":intent",
                INTENT,
                Value(sources=frozenset((self.current_entry,)), proof=proof),
            )
        # onNewIntent receives a new parcel, independent of mutations to getIntent()
        # during initialization. getIntent() itself changes only through setIntent().
        next_intent = self.obj(base + ":next-intent", INTENT, incoming)
        for (obj, key), val in list(initial_state.heap.items()):
            if obj in incoming.objects:
                self.write(initial_state, next_intent, key, val)
        self.write(initial_state, this, "$intent", incoming)
        states = [initial_state]
        for name, desc in [("<clinit>", "()V"), ("<init>", "()V")]:
            method = self.p.resolve(component.code_class, name, desc)
            if method:
                if name == "<clinit>":
                    for s in states:
                        s.initialized |= frozenset((component.code_class,))
                states = self.sequence(
                    states, method, [] if name == "<clinit>" else [this], base
                )
        kind = "activity" if component.kind == "activity-alias" else component.kind
        if kind == "activity":
            lifecycle = [
                ("onCreate", "(Landroid/os/Bundle;)V", [this, UNKNOWN]),
                ("onStart", "()V", [this]),
                ("onResume", "()V", [this]),
            ]
        elif kind == "service":
            lifecycle = [
                ("onCreate", "()V", [this]),
                (
                    "onStartCommand",
                    "(Landroid/content/Intent;II)I",
                    [this, incoming, UNKNOWN, UNKNOWN],
                ),
            ]
        elif kind == "receiver":
            lifecycle = [
                (
                    "onReceive",
                    "(Landroid/content/Context;Landroid/content/Intent;)V",
                    [this, UNKNOWN, incoming],
                )
            ]
        else:
            self.note("unsupported_provider_entry", component.name, True)
            return
        for name, desc, args in lifecycle:
            method = self.p.resolve(component.code_class, name, desc)
            if method:
                states = self.sequence(states, method, args, base)
        if kind == "activity":
            # New external Intent is delivered to an existing, initialized instance.
            method = self.p.resolve(
                component.code_class, "onNewIntent", "(Landroid/content/Intent;)V"
            )
            if method:
                states += self.sequence(
                    [s.copy() for s in states], method, [this, next_intent], base
                )
        if len(states) > self.limits.max_states:
            self.note("state_limit", component.name, True)
        for state in states[: self.limits.max_states]:
            for typ, obj in state.callbacks:
                callback = self.p.resolve(typ, "onClick", "(Landroid/view/View;)V")
                if callback:
                    self.execute(
                        callback, [obj, UNKNOWN], state.copy(), (base, "callback"), 0
                    )
            for target, intent in state.pending:
                dest = next(
                    (
                        c
                        for c in self.p.components
                        if c.code_class == target
                        and c.enabled
                        and c.kind in ("activity", "activity-alias")
                    ),
                    None,
                )
                if dest:
                    forwarded = state.copy()
                    forwarded.pending = ()
                    forwarded.callbacks = ()
                    self.execute_component(dest, forwarded, intent, hop + 1)
                else:
                    self.note("unresolved_explicit_component", target, True)

    def sequence(self, states, method, args, scope=""):
        result = []
        for state in states:
            result.extend(s for s, _ in self.execute(method, args, state, (scope,), 0))
            if len(result) > self.limits.max_states:
                self.note("state_limit", method.ref, True)
                return result[: self.limits.max_states]
        return result

    def allocation(self, state, site):
        occurrence = state.allocations.get(site, 0) + 1
        if occurrence > self.limits.max_allocations_per_site:
            self.note("allocation_occurrence_limit", site, True)
            return None
        state.allocations[site] = occurrence
        return site + ":occurrence:" + str(occurrence)

    def execute(self, method, args, state, stack, depth):
        if depth >= self.limits.max_depth:
            self.note("call_depth_limit", method.ref, True)
            return [(state, UNKNOWN)]
        if not method.instructions:
            if "native" in method.access.split() or "abstract" in method.access.split():
                self.note("unresolved_method_body", method.ref, True)
            return [(state, UNKNOWN)]
        self.calls.add(method.ref)
        if method.has_exceptions:
            self.note("exception_edges_unmodeled", method.ref, True)
        regs = dict(zip(method.argument_registers(), args))
        insns = {i.offset: i for i in method.instructions}
        offsets = list(insns)
        nexts = dict(pairwise(offsets))
        todo = [(offsets[0], regs, state, UNKNOWN)]
        seen, outcomes = set(), []
        context = stack + (method.ref,)
        while todo and self.budget():
            pc, regs, state, result = todo.pop()
            if pc not in insns:
                continue
            signature = (
                pc,
                tuple(sorted((r, v.signature()) for r, v in regs.items())),
                state.signature(),
                result.signature(),
            )
            if signature in seen:
                continue
            seen.add(signature)
            self.steps += 1
            ins = insns[pc]
            op, r = ins.op, ins.regs
            site = f"{method.ref}@{pc:04x}"
            get = lambda n, regs=regs: regs.get(n, UNKNOWN)
            init_owner = (
                str(ins.literal)
                if op == "new-instance"
                else (
                    ins.ref.split("->")[0]
                    if op.startswith(("sget", "sput", "invoke-static")) and ins.ref
                    else ""
                )
            )
            clinit = self.p.methods.get(init_owner + "-><clinit>()V")
            if clinit and init_owner not in state.initialized:
                state.initialized |= frozenset((init_owner,))
                for initialized, _ in self.execute(
                    clinit, [], state, context + (site,), depth + 1
                ):
                    todo.append((pc, regs.copy(), initialized, result))
                continue
            states_results = [(state, result)]
            if op.startswith("move-result"):
                regs[r[0]] = result
            elif op.startswith("move-exception"):
                regs[r[0]] = UNKNOWN
            elif op.startswith("move") and len(r) > 1:
                regs[r[0]] = self.traced(get(r[1]), "move", site, op)
            elif op.startswith("const"):
                regs[r[0]] = (
                    Value(constants=frozenset((ins.literal,)))
                    if ins.literal is not None
                    else UNKNOWN
                )
            elif op == "new-instance":
                ident = self.allocation(
                    state, "alloc:" + ("|".join(context)) + ":" + str(pc)
                )
                if ident is None:
                    continue
                regs[r[0]] = self.obj(
                    ident,
                    str(ins.literal),
                    Value(proof=self.proof("allocation", site, str(ins.literal))),
                )
            elif op.startswith("new-array"):
                ident = self.allocation(
                    state, "array:" + "|".join(context) + ":" + str(pc)
                )
                if ident is None:
                    continue
                regs[r[0]] = self.obj(ident, "[Ljava/lang/Object;")
            elif op.startswith("iget"):
                regs[r[0]] = self.traced(
                    self.read(state, get(r[1]), ins.ref), "field_read", site, ins.ref
                )
            elif op.startswith("iput"):
                self.write(
                    state,
                    get(r[1]),
                    ins.ref,
                    self.traced(get(r[0]), "field_write", site, ins.ref),
                )
            elif op.startswith("sget"):
                regs[r[0]] = self.traced(
                    state.heap.get(("$static", ins.ref), UNKNOWN),
                    "field_read",
                    site,
                    ins.ref,
                )
            elif op.startswith("sput"):
                state.heap["$static", ins.ref] = self.traced(
                    get(r[0]), "field_write", site, ins.ref
                )
            elif op.startswith("aput"):
                self.write(state, get(r[1]), "$array", get(r[0]))
                self.note("array_index_insensitive", site)
            elif op.startswith("aget"):
                regs[r[0]] = self.traced(
                    self.read(state, get(r[1]), "$array"), "array_read", site, op
                )
            elif op.startswith("invoke-"):
                states_results = self.invoke(ins, regs, state, context, depth, site)
            elif op == "check-cast":
                for obj in get(r[0]).objects:
                    if self.objects.get(obj) == "Landroid/view/View;":
                        self.objects[obj] = str(ins.literal)
                regs[r[0]] = self.traced(get(r[0]), "cast", site, str(ins.literal))
            elif op.startswith("return"):
                outcomes.append(
                    (
                        state,
                        (
                            self.traced(get(r[0]), "return", site, method.ref)
                            if r
                            else UNKNOWN
                        ),
                    )
                )
                if len(outcomes) >= self.limits.max_states and todo:
                    self.note("state_limit", method.ref, True)
                    break
                continue
            elif op == "throw":
                continue
            elif op in (
                "packed-switch",
                "sparse-switch",
                "nop",
                "check-cast",
            ) or op.startswith(
                (
                    "if-",
                    "goto",
                    "monitor-",
                    "packed-switch-payload",
                    "sparse-switch-payload",
                    "fill-array-data-payload",
                )
            ):
                pass
            elif r:
                # Unsupported definitions KILL prior register facts, preventing stale taint/identity.
                regs[r[0]] = UNKNOWN
                self.note("unsupported_instruction", op, True)
            else:
                self.note("unsupported_instruction", op, True)
            targets = [nexts[pc]] if pc in nexts else []
            if op.startswith("goto"):
                targets = [ins.target] if ins.target is not None else []
            elif op.startswith("if-"):
                decision = self.condition(op, [get(x) for x in r])
                if decision is not False and ins.target is not None:
                    targets.append(ins.target)
                if decision is True:
                    targets = [ins.target]
            elif op in ("packed-switch", "sparse-switch"):
                val = get(r[0])
                if len(val.constants) == 1 and not val.unknown:
                    key = next(iter(val.constants))
                    targets = (
                        [dict(ins.cases)[key]] if key in dict(ins.cases) else targets
                    )
                else:
                    targets += [target for _, target in ins.cases]
            for next_state, next_result in states_results:
                for target in dict.fromkeys(targets):
                    todo.append((target, regs.copy(), next_state.copy(), next_result))
            if len(todo) > self.limits.max_states:
                self.note("state_limit", method.ref, True)
                todo = todo[: self.limits.max_states]
        return outcomes

    @staticmethod
    def condition(op, values):
        constants = []
        for v in values:
            if v.unknown or v.sources or v.objects or len(v.constants) != 1:
                return None
            constants.append(next(iter(v.constants)))
        if len(constants) == 1:
            constants.append(0)
        if len(constants) != 2:
            return None
        a, b = constants
        try:
            return {
                "eq": lambda: a == b,
                "ne": lambda: a != b,
                "lt": lambda: a < b,
                "ge": lambda: a >= b,
                "gt": lambda: a > b,
                "le": lambda: a <= b,
            }[op[3:5]]()
        except (KeyError, TypeError):
            return None

    def invoke(self, ins, regs, state, context, depth, site):
        if not ins.ref or "(" not in ins.ref:
            self.note("unsupported_invocation", site, True)
            return [(state, UNKNOWN)]
        owner, name, desc = split_ref(ins.ref)
        raw = [regs.get(r, UNKNOWN) for r in ins.regs]
        static = ins.op.startswith("invoke-static")
        receiver = UNKNOWN if static or not raw else raw[0]
        args = []
        cursor = 0 if static else 1
        for typ in parameters(desc):
            args.append(raw[cursor] if cursor < len(raw) else UNKNOWN)
            cursor += 2 if typ in ("J", "D") else 1
        # Dispatch application code before framework summaries (overrides matter).
        targets = {}
        if ins.op.startswith(("invoke-direct", "invoke-static", "invoke-super")):
            target = self.p.resolve(owner, name, desc)
            if target:
                targets[target.ref] = target
        else:
            for o in receiver.objects:
                target = self.p.resolve(self.objects.get(o, owner), name, desc)
                if target:
                    targets[target.ref] = target
            if not targets:
                target = self.p.resolve(owner, name, desc)
                if target:
                    targets[target.ref] = target
        if targets:
            results = []
            callargs = args if static else [receiver] + args
            callargs = [self.traced(v, "argument", site, ins.ref) for v in callargs]
            for target in targets.values():
                results.extend(
                    self.execute(
                        target, callargs, state.copy(), context + (site,), depth + 1
                    )
                )
            return results
        out = self.summary(owner, name, desc, receiver, args, state, site, context)
        return [(state, out)]

    def summary(self, owner, name, desc, receiver, args, state, site, context):
        arg = lambda n: args[n] if n < len(args) else UNKNOWN
        iswv = self.p.is_subtype(owner, WV)
        isactivity = owner.endswith("/Activity;") or any(
            self.read(state, Value(objects=frozenset((o,))), "$intent").objects
            for o in receiver.objects
        )
        if name == "getIntent" and desc == "()Landroid/content/Intent;" and isactivity:
            return self.traced(
                self.read(state, receiver, "$intent"), "intent_access", site, name
            )
        if name == "setIntent" and isactivity:
            self.write(state, receiver, "$intent", arg(0))
            return UNKNOWN
        if owner == INTENT:
            if name in (
                "getData",
                "getDataString",
                "getStringExtra",
                "getCharSequenceExtra",
                "getBundleExtra",
                "getExtras",
                "getParcelableExtra",
            ):
                origin = combine(
                    [receiver, self.read(state, receiver, "$copied_source")]
                )
                val = self.source(origin, site, name)
                stored = self.read(
                    state,
                    receiver,
                    (
                        "$data"
                        if name in ("getData", "getDataString")
                        else "$extra:" + str(sorted(arg(0).constants, key=str))
                    ),
                )
                if not stored.unknown:
                    val = stored
                if name in ("getExtras", "getBundleExtra"):
                    return self.obj(
                        "bundle:" + site + ":" + ",".join(sorted(receiver.objects)),
                        "Landroid/os/Bundle;",
                        val,
                    )
                return val
            if name in ("setData", "setDataAndType"):
                self.write(state, receiver, "$data", arg(0))
                return receiver
            if name == "putExtra":
                self.write(
                    state,
                    receiver,
                    "$extra:" + str(sorted(arg(0).constants, key=str)),
                    arg(1),
                )
                return receiver
            if name == "<init>" and parameters(desc) == [INTENT]:
                for src in arg(0).objects:
                    for (obj, key), val in list(state.heap.items()):
                        if obj == src:
                            self.write(state, receiver, key, val)
                # Intent copy preserves incoming external data provenance.
                for obj in receiver.objects:
                    self.write(
                        state,
                        Value(objects=frozenset((obj,))),
                        "$copied_source",
                        arg(0),
                    )
                return UNKNOWN
            if (
                name in ("setClass", "setClassName", "setComponent")
                or name == "<init>"
                and "Ljava/lang/Class;" in desc
            ):
                target = arg(len(args) - 1)
                if name == "setComponent":
                    target = self.read(state, target, "$component")
                self.write(state, receiver, "$target", target)
                return receiver
            if name == "<init>":
                return UNKNOWN
        if owner == "Landroid/content/ComponentName;" and name == "<init>":
            self.write(state, receiver, "$component", arg(len(args) - 1))
            return UNKNOWN
        if owner == "Landroid/os/Bundle;" and name in (
            "getString",
            "getCharSequence",
            "getParcelable",
            "getBundle",
        ):
            return self.source(receiver, site, "Bundle." + name)
        if owner == "Landroid/net/Uri;" and name in (
            "parse",
            "toString",
            "getQueryParameter",
            "getFragment",
            "getHost",
            "getPath",
            "getScheme",
            "decode",
            "encode",
            "normalizeScheme",
        ):
            val = combine(args if name in ("parse", "decode", "encode") else [receiver])
            # Preserves input dependence; does not imply an unconstrained whole URL.
            return self.traced(
                replace(val, objects=frozenset()), "uri_transform", site, name
            )
        if owner == "Ljava/lang/String;" and name in (
            "valueOf",
            "concat",
            "substring",
            "replace",
            "replaceAll",
            "trim",
            "toString",
            "toLowerCase",
            "toUpperCase",
        ):
            val = combine(args if name == "valueOf" else [receiver] + args)
            return self.traced(
                replace(val, objects=frozenset(), constants=frozenset()),
                "string_transform",
                site,
                name,
            )
        if owner in ("Ljava/lang/StringBuilder;", "Ljava/lang/StringBuffer;"):
            if name in ("<init>", "append"):
                val = combine([self.read(state, receiver, "$text")] + args)
                self.write(state, receiver, "$text", val)
                return receiver
            if name == "toString":
                return self.traced(
                    self.read(state, receiver, "$text"), "string_transform", site, name
                )
        if name == "setContentView" and desc in ("(I)V", "(Landroid/view/View;)V"):
            token = self.allocation(
                state, "layout:" + site + ":" + ",".join(sorted(receiver.objects))
            )
            self.write(
                state,
                receiver,
                "$layout",
                Value(constants=frozenset((token or "unknown",))),
            )
            return UNKNOWN
        if name == "findViewById" and desc == "(I)Landroid/view/View;":
            ids = sorted(arg(0).constants, key=str)
            layout = self.read(state, receiver, "$layout").signature()
            ident = (
                "view:"
                + ",".join(sorted(receiver.objects))
                + ":"
                + str(ids)
                + ":"
                + str(layout)
                if ids and receiver.objects
                else self.allocation(
                    state, "view_unresolved:" + site + ":" + "|".join(context)
                )
            )
            if ident is None:
                return UNKNOWN
            if not ids or not receiver.objects:
                self.note("view_identity_unresolved", site, True)
            return self.obj(ident, "Landroid/view/View;")
        if iswv and name in ("loadUrl", "postUrl", "loadData", "loadDataWithBaseURL"):
            if not receiver.objects:
                self.note("unresolved_webview_receiver", site, True)
            indexes = {
                "loadUrl": [0],
                "postUrl": [0, 1],
                "loadData": [0],
                "loadDataWithBaseURL": [0, 1],
            }[name]
            for idx in indexes:
                val = arg(idx)
                if not val.sources:
                    continue
                js = self.read(state, receiver, "$javascript")
                enabled = (
                    "true"
                    if js.constants == frozenset((1,))
                    else "false" if js.constants == frozenset((0,)) else "unknown"
                )
                proof = self.proof(
                    "webview_loading", site, f"{name} argument {idx}", [val, receiver]
                )
                self.record(
                    state,
                    {
                        "kind": "load",
                        "entry": self.current_entry,
                        "site": site,
                        "api": name,
                        "argument_index": idx,
                        "objects": sorted(receiver.objects),
                        "sources": sorted(val.sources),
                        "proof": sorted(proof),
                        "javascript_enabled": enabled,
                    },
                )
            if name == "loadDataWithBaseURL":
                self.note("base_url_dependency_not_html_control", site)
            return UNKNOWN
        if (
            iswv
            and name == "addJavascriptInterface"
            and desc == "(Ljava/lang/Object;Ljava/lang/String;)V"
        ):
            bridge = arg(0)
            if not receiver.objects or self.exposure(bridge)["unresolved_type"]:
                self.note("unresolved_bridge_or_webview_object", site, True)
            proof = self.proof(
                "bridge_registration", site, name, [receiver, bridge, arg(1)]
            )
            self.record(
                state,
                {
                    "kind": "bridge",
                    "entry": self.current_entry,
                    "site": site,
                    "objects": sorted(receiver.objects),
                    "bridge_objects": sorted(bridge.objects),
                    "bridge_types": sorted(
                        {self.objects.get(o, "unknown") for o in bridge.objects}
                    ),
                    "names": sorted(str(c) for c in arg(1).constants),
                    "proof": sorted(proof),
                    "exposure": self.exposure(bridge),
                },
            )
            return UNKNOWN
        if iswv and name == "removeJavascriptInterface":
            self.record(
                state,
                {
                    "kind": "remove_bridge",
                    "site": site,
                    "objects": sorted(receiver.objects),
                    "names": sorted(str(c) for c in arg(0).constants),
                },
            )
            return UNKNOWN
        if iswv and name == "getSettings":
            val = self.obj(
                "settings:" + ",".join(sorted(receiver.objects)),
                "Landroid/webkit/WebSettings;",
            )
            self.write(state, val, "$webview", receiver)
            return val
        if owner == "Landroid/webkit/WebSettings;" and name == "setJavaScriptEnabled":
            self.write(
                state, self.read(state, receiver, "$webview"), "$javascript", arg(0)
            )
            return UNKNOWN
        if (
            name == "setOnClickListener"
            and desc == "(Landroid/view/View$OnClickListener;)V"
        ):
            listener = self.traced(arg(0), "callback_registration", site, name)
            state.callbacks += tuple(
                (self.objects[o], listener) for o in arg(0).objects if o in self.objects
            )
            self.note("callback_user_interaction_required", site)
            return UNKNOWN
        if name == "startActivity" and desc.startswith("(Landroid/content/Intent;"):
            targets = self.read(state, arg(0), "$target")
            if not targets.constants:
                self.note("implicit_or_unresolved_icc", site, True)
            snapshot = self.obj(
                "icc_snapshot:" + site + ":" + str(len(state.pending)), INTENT, arg(0)
            )
            for obj in arg(0).objects:
                for (source, key), val in list(state.heap.items()):
                    if source == obj:
                        self.write(state, snapshot, key, val)
            for const in targets.constants:
                target = str(const)
                if not target.startswith("L"):
                    target = dex_name(target)
                state.pending += ((target, snapshot),)
            return UNKNOWN
        if name == "<init>" and owner in (
            "Ljava/lang/Object;",
            WV,
            "Landroid/app/Activity;",
            "Landroid/app/Service;",
            "Landroid/content/BroadcastReceiver;",
        ):
            return UNKNOWN
        # Casting refines a view's type in execute(); unmatched framework calls do
        # not magically transfer arguments into return values or expose Bridges.
        if desc.endswith("V") and name in (
            "setContentView",
            "onCreate",
            "onStart",
            "onResume",
            "onNewIntent",
            "onReceive",
        ):
            return UNKNOWN
        self.note("unmodeled_call", owner + "->" + name + desc, True)
        return UNKNOWN
