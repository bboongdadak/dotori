"""Exact discovered Intent payload delivery, including exported destinations."""
from dataclasses import replace

DATA_GETTERS = {'getData', 'getDataString'}
EXTRA_TYPES = {
    'getStringExtra': {'Ljava/lang/String;'},
    'getCharSequenceExtra': {'Ljava/lang/String;', 'Ljava/lang/CharSequence;'},
    'getBundleExtra': {'Landroid/os/Bundle;'},
    'getParcelableExtra': {'Landroid/os/Parcelable;'},
}


def values(analysis, origin, getter, keys, where, required_types=None):
    from .demand import Origin, compatible
    target = origin.key.removeprefix('intent:')
    out = []
    for forwarder in analysis.forwarders:
        whole = (forwarder.get('classification') == 'conditional_intent_forwarding'
                 and 'payload' not in forwarder and 'extra_key' not in forwarder)
        declared = forwarder.get('target_class')
        if declared and declared != target:
            continue
        if whole:
            # Preserve the existing conditional nested-Intent model for an
            # internal destination. An exported target needs an explicit edge.
            if origin.kind == 'external_intent' and declared != target:
                continue
            selected = (None,)
        else:
            if declared != target:
                continue
            payload = forwarder.get('payload')
            if getter in DATA_GETTERS:
                if payload != 'data':
                    continue
                selected = (None,)
            elif getter in EXTRA_TYPES:
                if payload != 'extra' or 'extra_key' not in forwarder:
                    continue
                # Unknown/mixed key values cannot justify one exact delivery.
                if not keys or any(key.kind != 'constant' for key in keys):
                    analysis.note('intent_payload_key_unresolved', where)
                    continue
                selected = tuple(key for key in keys if key.value == forwarder['extra_key'])
                value_type = forwarder.get('payload_type')
                accepted = EXTRA_TYPES[getter]
                if value_type and value_type not in accepted and not any(
                        analysis.p.is_subtype(value_type, typ) for typ in accepted):
                    continue
                if required_types is not None:
                    if len(required_types) != 1 or required_types[0].kind != 'constant':
                        analysis.note('intent_payload_type_unresolved', where)
                        continue
                    required = required_types[0]
                    if not value_type or not analysis.p.is_subtype(value_type, required.value):
                        continue
                    selected = tuple(replace(key, guards=key.guards | required.guards)
                                     for key in selected if compatible(key, required))
            else:
                # getExtras needs a key-preserving container summary; do not
                # flatten one structured extra into the whole Bundle/selector.
                continue
        source = forwarder['source']
        atom = Origin('external_value', source['key'], entry=source['entry'],
            path=tuple(source['path']) + (forwarder['site'] + ':intent_forwarding',),
            guards=frozenset(tuple(g) for g in source.get('branch_choices', ())),
            callback_instances=frozenset(source.get('callback_instances', ())))
        for key in selected:
            if not compatible(atom, origin) or key is not None and (
                    not compatible(atom, key) or not compatible(origin, key)):
                continue
            guards = atom.guards | origin.guards | (key.guards if key else frozenset())
            condition = ':conditional_internal_intent_target' if whole else ':explicit_intent_target:' + target
            out.append(replace(atom, guards=guards,
                callback_instances=atom.callback_instances | origin.callback_instances |
                    (key.callback_instances if key else frozenset())).step(where + condition).step(where + ':' + getter))
    return tuple(out)
