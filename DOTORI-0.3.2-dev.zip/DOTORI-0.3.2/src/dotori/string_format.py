"""Exact String.format string-slot provenance, with bounded local array snapshots.

Only supported constant templates select arguments. An unknown template never
makes every array element an input. The summary describes output contribution,
not URL trust or successful runtime formatting of arbitrary Java objects.
"""
from dataclasses import replace
import re
from .model import split_ref

STRING='Ljava/lang/String;'
OBJECTS='[Ljava/lang/Object;'
COPY='Ljava/util/Arrays;->copyOf('+OBJECTS+'I)'+OBJECTS
FORMATS={
    'Ljava/lang/String;->format('+STRING+OBJECTS+')'+STRING:(0,1),
    'Ljava/lang/String;->format(Ljava/util/Locale;'+STRING+OBJECTS+')'+STRING:(1,2),
}
SPEC=re.compile(r'%(?:(\d+)\$)?([-#+ 0,(<]*)(\d+)?(?:\.(\d+))?([tT])?([a-zA-Z%])')


class Unresolved(Exception):
    def __init__(self,code,detail):self.code,self.detail=code,detail


def argument_indexes(template):
    """Java's ordinary, explicit and previous-argument indexes stay separate."""
    used=set();ordinary=0;last=None;pos=0
    while pos<len(template):
        if template[pos]!='%':pos+=1;continue
        match=SPEC.match(template,pos)
        if not match:raise ValueError('invalid format')
        explicit,flags,width,precision,date,conversion=match.groups();pos=match.end()
        if date or len(set(flags))!=len(flags):raise ValueError('unsupported format')
        if conversion in ('%','n'):
            if explicit or flags or width or precision:raise ValueError('unsupported literal format')
            continue
        if conversion not in ('s','S') or set(flags)-{'-','<'}:raise ValueError('unsupported conversion')
        if '-' in flags and width is None:raise ValueError('missing width')
        if '<' in flags:
            if explicit or last is None:raise ValueError('invalid relative index')
            index=last
        elif explicit:
            index=int(explicit)-1
        else:
            index=ordinary;ordinary+=1
        if index<0 or index>=128:raise ValueError('argument index bound')
        last=index
        # A precision of zero emits no characters from the argument.
        if precision is None or int(precision)>0:used.add(index)
    return tuple(sorted(used))


def _constant(a,m,reg,before,ctx,depth):
    values=a.trace(m.ref,reg,before,'value',ctx,depth+1)
    if len(values)!=1 or values[0].kind!='constant':return None
    return values[0]


def _integer(a,m,reg,before,ctx,depth):
    value=_constant(a,m,reg,before,ctx,depth)
    if value is None or not value.value.lstrip('-').isdecimal():return None
    return int(value.value)


def _element(a,m,reg,before,index,ctx,depth,seen=frozenset()):
    from .demand import Origin, compatible
    where=a.site(m.ref,before)
    if len(seen)>8 or not a.allowed(depth):raise Unresolved('format_array_depth_limit',where)
    objects=a.trace(m.ref,reg,before,'object',ctx,depth+1)
    if len(objects)!=1 or objects[0].kind not in ('allocation','format_array_copy'):
        raise Unresolved('format_array_alias_unresolved',where)
    base=objects[0]
    if base.key in seen:raise Unresolved('format_array_cycle_unresolved',where)
    # The local replay never guesses writes in unrelated caller/lifecycle frames.
    location=a.allocation_contexts.get(base.key)
    if location is None or location[0]!=m.ref or location[1]!=ctx:
        raise Unresolved('format_array_context_unresolved',where)
    try:creation=a.instruction(m.ref,int(base.key.split(':call_context:',1)[0].rsplit('@',1)[1],16))
    except (ValueError,IndexError):creation=None
    if creation is None:raise Unresolved('format_array_creation_unresolved',where)
    segment=[i for i in m.instructions if creation.offset<i.offset<before]
    if len(segment)>512:raise Unresolved('format_array_replay_limit',where)
    if any(i.op.startswith(('if-','goto','throw')) or i.op in ('packed-switch','sparse-switch') for i in segment):
        raise Unresolved('format_array_control_flow_unresolved',where)
    if any(start<before and end>creation.offset for start,end,_,_ in m.exception_handlers):
        raise Unresolved('format_array_exception_unresolved',where)
    if creation.op=='new-array':
        size=_integer(a,m,creation.regs[1],creation.offset,ctx,depth)
    elif creation.ref==COPY:
        size=_integer(a,m,a.actuals(creation)[1],creation.offset,ctx,depth)
    else:raise Unresolved('format_array_creation_unresolved',where)
    if size is None:raise Unresolved('format_array_size_unresolved',where)
    if index>=size or size<0:raise Unresolved('format_array_index_out_of_bounds',where)
    chosen=None
    for event in segment:
        # Stores/unknown calls can mutate or leak the selected array. Trace
        # identity at the event, before register reassignment or a later copy.
        if event.op.startswith('aput'):
            stored=a.trace(m.ref,event.regs[0],event.offset,'object',ctx,depth+1)
            if any(v.key==base.key for v in stored):
                raise Unresolved('format_array_escape_unresolved',where)
            targets=a.trace(m.ref,event.regs[1],event.offset,'object',ctx,depth+1)
            if not any(v.key==base.key for v in targets):
                if not targets:raise Unresolved('format_array_alias_unresolved',where)
                continue
            if len(targets)!=1:raise Unresolved('format_array_alias_unresolved',where)
            slot=_integer(a,m,event.regs[2],event.offset,ctx,depth)
            if slot is None:raise Unresolved('format_array_index_unresolved',where)
            if slot<0 or slot>=size:raise Unresolved('format_array_index_out_of_bounds',where)
            if slot==index:chosen=event
        elif event.op.startswith(('invoke-','iput','sput','filled-new-array')):
            actual=a.actuals(event) if event.op.startswith('invoke-') else event.regs[:1]
            aliases=[]
            for operand in actual:
                values=a.trace(m.ref,operand,event.offset,'object',ctx,depth+1)
                aliases.extend(v for v in values if v.key==base.key)
            if aliases and event.ref!=COPY:
                raise Unresolved('format_array_escape_unresolved',where)
    if chosen is not None:
        values=a.trace(m.ref,chosen.regs[0],chosen.offset,'value',ctx,depth+1)
        proof='format_array_last_write:'+a.site(m.ref,chosen.offset)
    elif creation.ref==COPY:
        source=a.actuals(creation)[0]
        values=_element(a,m,source,creation.offset,index,ctx,depth+1,seen|{base.key})
        proof='format_array_copy_snapshot:'+a.site(m.ref,creation.offset)
    else:
        values=(Origin('constant','null',value='null',path=(a.site(m.ref,creation.offset)+':array_default_null',)),)
        proof='format_array_default_null'
    return tuple(replace(v,guards=v.guards|base.guards,
        callback_instances=v.callback_instances|base.callback_instances,
        path=v.path+base.path+(proof,)) for v in values if compatible(v,base))


def result(a,m,call,mode,ctx,depth):
    if call.ref==COPY and call.op.startswith('invoke-static'):
        from .demand import Origin
        return (Origin('format_array_copy',a.allocation_key(m,call,ctx),OBJECTS,
                       path=(a.site(m.ref,call.offset)+':array_copy_object',)),)
    if call.ref not in FORMATS or not call.op.startswith('invoke-static'):return None
    where=a.site(m.ref,call.offset)
    if mode=='object':
        # Formatting constructs a String, never aliases an argument WebView.
        return ()
    actual=a.actuals(call);fmtpos,arraypos=FORMATS[call.ref]
    if len(actual)<=arraypos:a.note('string_format_arguments_unresolved',where);return ()
    template=_constant(a,m,actual[fmtpos],call.offset,ctx,depth)
    if template is None:a.note('string_format_template_unresolved',where);return ()
    try:indexes=argument_indexes(template.value)
    except ValueError:a.note('string_format_conversion_unresolved',where);return ()
    out=[]
    from .demand import compatible
    for index in indexes:
        try:values=_element(a,m,actual[arraypos],call.offset,index,ctx,depth+1)
        except Unresolved as exc:a.note(exc.code,exc.detail);continue
        for v in values:
            if compatible(v,template):out.append(replace(v,guards=v.guards|template.guards,
                callback_instances=v.callback_instances|template.callback_instances,
                path=v.path+template.path+(where+':format_argument:'+str(index),)))
    return tuple(out)
