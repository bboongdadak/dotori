"""Value delivery supported by a LiveData allocation and its exact observer.

This models a possible framework delivery, not scheduling, observer liveness,
postValue ordering/coalescing, or execution of application branches.  It never
matches a postValue and onChanged merely because they occur in the same APK.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

from .model import split_ref
from .webview_callbacks import allocation_type

LIVE = 'Landroidx/lifecycle/LiveData;'
MUTABLE = 'Landroidx/lifecycle/MutableLiveData;'
OBSERVER = 'Landroidx/lifecycle/Observer;'
OWNER = 'Landroidx/lifecycle/LifecycleOwner;'
OBJECT = 'Ljava/lang/Object;'
CHANGED = '(' + OBJECT + ')V'
OBSERVE = '(' + OWNER + OBSERVER + ')V'
FOREVER = '(' + OBSERVER + ')V'


@dataclass(frozen=True)
class Registration:
    observer: object
    live: object
    method: str
    offset: int
    site: str
    token: str
    guards: frozenset
    owner: str = ''


def framework_call(analysis, ref, name, descriptor):
    """Do not summarize an application override of the framework operation."""
    owner, actual_name, actual_descriptor = split_ref(ref)
    if actual_name != name or actual_descriptor != descriptor:
        return False
    if not (owner in (LIVE, MUTABLE) or analysis.p.is_subtype(owner, LIVE)):
        return False
    target = analysis.p.resolve(owner, name, descriptor)
    return target is None or target.owner in (LIVE, MUTABLE)


def callback(analysis, method):
    return ('static' not in method.access.split()
            and 'public' in method.access.split()
            and method.name == 'onChanged' and method.descriptor == CHANGED
            and analysis.p.is_subtype(method.owner, OBSERVER))


def control_guards(analysis, method, offset, depth):
    """Enumerate feasible local CFG witnesses, preserving unknown branches.

    Branch choices preceding a local new-instance otherwise disappear from its
    reaching definition. Loops and exception edges are intentionally unresolved.
    """
    key = ('livedata_control_guards', method.ref, offset)
    if key in analysis.memo:
        return analysis.memo[key]
    if method.has_exceptions:
        analysis.note('livedata_exception_flow_unresolved', analysis.site(method.ref, offset))
        return ()
    instructions, _, predecessors = analysis.cfg(method.ref)
    if not instructions:
        return ()
    first = instructions[0].offset
    todo = [(offset, frozenset(), frozenset())]
    found = set()
    visited = set()
    while todo and len(visited) < 4096 and len(found) < 32:
        if not analysis.allowed(depth):
            break
        at, guards, path = todo.pop()
        state = (at, guards)
        if state in visited:
            continue
        visited.add(state)
        if at == first:
            found.add(guards)
            continue
        if at in path:
            analysis.note('livedata_loop_flow_unresolved', analysis.site(method.ref, offset))
            continue
        for parent, edge in predecessors.get(at, ()):
            merged = guards | frozenset((edge,)) if edge else guards
            if len({(r, b) for r, b, _ in merged}) != len(merged):
                continue
            todo.append((parent, merged, path | {at}))
    if todo:
        analysis.note('livedata_control_flow_limit', analysis.site(method.ref, offset))
    result = tuple(sorted(found, key=lambda g: (len(g), sorted(g))))
    analysis.memo[key] = result
    return result


def unique_allocation(origins):
    """Branch alternatives can share an exact allocation; slots cannot prove it."""
    return bool(origins) and all(o.kind == 'allocation' for o in origins) and len({o.key for o in origins}) == 1


def operand(analysis, method, reg, offset, mode, depth):
    """Keep one unknown framework operand from exhausting the entire slice."""
    previous = analysis.branch_query_limit
    analysis.branch_query_limit = min(previous if previous is not None else analysis.per_sink_limit,
                                      analysis.sink_queries + 96)
    try:
        return analysis.trace(method, reg, offset, mode, 0, depth)
    finally:
        analysis.branch_query_limit = previous


def registrations(analysis, method, depth):
    key = ('livedata_registrations', method.ref)
    if key in analysis.memo:
        return analysis.memo[key]
    if key in analysis.active:
        return ()
    analysis.active.add(key)
    found = []
    from .demand import compatible
    try:
        sites = []
        for name, desc in (('observe', OBSERVE), ('observeForever', FOREVER)):
            for ref in sorted(analysis.c.call_signatures.get((name, desc), ())):
                if framework_call(analysis, ref, name, desc):
                    sites.extend(analysis.c.callers_of(ref))
        if len(sites) > 256:
            analysis.note('livedata_registration_fanout_limit', method.ref)
        for site in sites[:256]:
            if not analysis.allowed(depth):
                break
            call = analysis.instruction(site.method, site.offset)
            caller = analysis.p.methods.get(site.method)
            if not call or not caller or call.op.startswith('invoke-static'):
                continue
            args = analysis.actuals(call)
            if len(args) not in (2, 3):
                continue
            types = analysis.known_receiver_types(caller, args[-1], call.offset, 0)
            if types and not any((target := analysis.p.resolve(typ, method.name, method.descriptor))
                                 and target.ref == method.ref for typ in types):
                continue
            observers = operand(analysis, caller.ref, args[-1], call.offset, 'object', depth)
            if not unique_allocation(observers):
                analysis.note('livedata_observer_alias_unresolved', analysis.site(caller.ref, call.offset))
                continue
            concrete = allocation_type(analysis, observers[0])
            target = analysis.p.resolve(concrete, method.name, method.descriptor) if concrete else None
            if not target or target.ref != method.ref or not analysis.p.is_subtype(concrete, OBSERVER):
                continue
            live = operand(analysis, caller.ref, args[0], call.offset, 'object', depth)
            if not unique_allocation(live):
                analysis.note('livedata_receiver_alias_unresolved', analysis.site(caller.ref, call.offset))
                continue
            live_type = allocation_type(analysis, live[0])
            if not analysis.p.is_subtype(live_type, LIVE):
                continue
            _, call_name, call_desc = split_ref(call.ref)
            if not framework_call(analysis, live_type + '->' + call_name + call_desc, call_name, call_desc):
                analysis.note('livedata_override_unresolved', analysis.site(caller.ref, call.offset))
                continue
            guards = control_guards(analysis, caller, call.offset, depth)
            if not guards:
                continue
            lifecycle = ''
            if len(args) == 3:
                owners = operand(analysis, caller.ref, args[1], call.offset, 'object', depth)
                if (not owners or len({o.key for o in owners}) != 1
                        or any(o.kind not in ('component', 'allocation') for o in owners)):
                    analysis.note('livedata_lifecycle_owner_unresolved', analysis.site(caller.ref, call.offset))
                    continue
                lifecycle = owners[0].key
            where = analysis.site(caller.ref, call.offset)
            token = 'livedata_observer:' + observers[0].key + ':registration:' + where + ':live:' + live[0].key
            for observer in observers:
                for stream in live:
                    if not compatible(observer, stream):
                        continue
                    for choice in guards:
                        guard = observer.guards | stream.guards | choice
                        if len({(r, b) for r, b, _ in guard}) != len(guard):
                            continue
                        found.append(Registration(replace(observer, typ=concrete), stream,
                            caller.ref, call.offset, where, token, guard, lifecycle))
    finally:
        analysis.active.remove(key)
    result = tuple(found)
    analysis.memo[key] = result
    return result


def removed(analysis, registration, emitter, call, depth):
    """Reject a definite remove before this same-method delivery opportunity.

    Cross-method lifetime and conditional removals remain explicit model gaps.
    No arbitrary global registration-order claim is made.
    """
    if registration.method != emitter.ref or call.offset <= registration.offset:
        return False
    for ins in emitter.instructions:
        if not registration.offset < ins.offset < call.offset or not ins.op.startswith('invoke-') or not ins.ref:
            continue
        owner, name, desc = split_ref(ins.ref)
        if name not in ('removeObserver', 'removeObservers') or not framework_call(analysis, ins.ref, name, desc):
            continue
        args = analysis.actuals(ins)
        if len(args) != 2:
            continue
        streams = analysis.trace(emitter.ref, args[0], ins.offset, 'object', 0, depth)
        targets = analysis.trace(emitter.ref, args[1], ins.offset, 'object', 0, depth)
        wanted = registration.observer.key if name == 'removeObserver' else registration.owner
        if any(s.key == registration.live.key for s in streams) and wanted and any(t.key == wanted for t in targets):
            # A remove on any feasible intervening path makes this model unable
            # to prove a retained registration; avoid guessing the active path.
            analysis.note('livedata_observer_removed', analysis.site(emitter.ref, ins.offset))
            return True
    return False


def parameter(analysis, method, index, mode, depth):
    """None = no summary; empty = callback recognized, delivery unverified."""
    if not callback(analysis, method):
        return None
    registered = registrations(analysis, method, depth)
    if not registered:
        analysis.note('livedata_registration_unresolved', method.ref)
        return ()
    if index == 0:
        return tuple(replace(r.observer, guards=r.guards,
            callback_instances=r.observer.callback_instances | {r.token},
            path=r.observer.path + ('livedata_observer_registered:' + r.site,
                                   'livedata_callback_dispatch:' + method.ref)) for r in registered)
    if index != 1:
        return ()
    from .demand import compatible
    sites = []
    for name in ('setValue', 'postValue'):
        for ref in sorted(analysis.c.call_signatures.get((name, CHANGED), ())):
            if framework_call(analysis, ref, name, CHANGED):
                sites.extend(analysis.c.callers_of(ref))
    registration_owners = {split_ref(r.method)[0] for r in registered}
    # Preserve concrete Intent-entry emissions before guard-heavy startup
    # alternatives, without relying on application names or vulnerability IDs.
    def priority(site):
        owner, name, desc = split_ref(site.method)
        intent_entry = (name in ('onNewIntent', 'onReceive', 'onStartCommand')
                        and 'Landroid/content/Intent;' in desc)
        return (not intent_entry, owner not in registration_owners,
                analysis.source_distance(site.method), site.method, site.offset)
    sites.sort(key=priority)
    if len(sites) > 256:
        analysis.note('livedata_emission_fanout_limit', method.ref)
    found = []
    for site in sites[:256]:
        if not analysis.allowed(depth):
            break
        call = analysis.instruction(site.method, site.offset)
        emitter = analysis.p.methods.get(site.method)
        if (not call or not emitter or call.op.startswith('invoke-static')
                or emitter.owner in (LIVE, MUTABLE)):
            continue
        args = analysis.actuals(call)
        if len(args) != 2:
            continue
        streams = operand(analysis, emitter.ref, args[0], call.offset, 'object', depth)
        if not unique_allocation(streams):
            analysis.note('livedata_emission_alias_unresolved', analysis.site(emitter.ref, call.offset))
            continue
        live_type = allocation_type(analysis, streams[0])
        if not live_type:
            continue
        _, call_name, call_desc = split_ref(call.ref)
        if (call.op.startswith(('invoke-virtual', 'invoke-interface'))
                and not framework_call(analysis, live_type + '->' + call_name + call_desc, call_name, call_desc)):
            analysis.note('livedata_override_unresolved', analysis.site(emitter.ref, call.offset))
            continue
        matches = [r for r in registered if r.live.key == streams[0].key]
        if not matches:
            continue
        guards = control_guards(analysis, emitter, call.offset, depth)
        if not guards:
            continue
        values = analysis.trace(emitter.ref, args[1], call.offset, mode, 0, depth)
        for registration in matches:
            if removed(analysis, registration, emitter, call, depth):
                continue
            for stream in streams:
                if not compatible(stream, replace(registration.live, guards=registration.guards)):
                    continue
                for value in values:
                    for choice in guards:
                        merged = registration.guards | stream.guards | value.guards | choice
                        if len({(r, b) for r, b, _ in merged}) != len(merged):
                            continue
                        where = analysis.site(emitter.ref, call.offset)
                        proof = ('livedata_emit:' + where,
                                 'livedata_same_allocation:' + stream.key,
                                 'livedata_observer_registered:' + registration.site,
                                 'livedata_callback_dispatch:' + method.ref,
                                 'livedata_delivery_requires_active_observer_and_scheduling')
                        found.append(replace(value, guards=merged,
                            callback_instances=value.callback_instances | {registration.token},
                            path=value.path + proof))
                        analysis.note('livedata_delivery_lifecycle_order_unresolved', registration.site + ' <- ' + where)
    if not found:
        analysis.note('livedata_value_delivery_unresolved', method.ref)
    return tuple(found)
