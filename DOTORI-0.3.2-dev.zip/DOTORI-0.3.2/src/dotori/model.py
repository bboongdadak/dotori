from __future__ import annotations

import re
from dataclasses import dataclass, field


def parameters(descriptor: str) -> list[str]:
    return re.findall(r"\[*L[^;]+;|\[*[ZBCSIJFD]", descriptor.split(")")[0][1:])


def split_ref(ref: str) -> tuple[str, str, str]:
    owner, tail = ref.split("->", 1)
    name, desc = tail.split("(", 1)
    return owner, name, "(" + desc


def dex_name(name: str) -> str:
    return "L" + name.replace(".", "/") + ";"


@dataclass(frozen=True)
class Instruction:
    offset: int
    op: str
    regs: tuple[int, ...] = ()
    ref: str = ""
    literal: str | int | None = None
    target: int | None = None
    cases: tuple[tuple[int, int], ...] = ()
    text: str = ""


@dataclass
class Method:
    ref: str
    access: str = ""
    registers: int = 0
    ins_size: int = 0
    instructions: list[Instruction] = field(default_factory=list)
    annotations: tuple[str, ...] = ()
    has_exceptions: bool = False
    exception_handlers: tuple[tuple[int, int, int, str], ...] = ()

    @property
    def owner(self):
        return split_ref(self.ref)[0]

    @property
    def name(self):
        return split_ref(self.ref)[1]

    @property
    def descriptor(self):
        return split_ref(self.ref)[2]

    def argument_registers(self):
        cursor = self.registers - self.ins_size
        result = []
        if "static" not in self.access.split():
            result.append(cursor)
            cursor += 1
        for typ in parameters(self.descriptor):
            result.append(cursor)
            cursor += 2 if typ in ("J", "D") else 1
        return result


@dataclass
class Component:
    name: str
    code_class: str
    kind: str
    exported: bool
    enabled: bool = True
    permission: str | None = None
    permission_level: str | None = None
    export_reason: str = ""
    filters: list[dict] = field(default_factory=list)


@dataclass
class Program:
    package: str
    target_sdk: int | None
    min_sdk: int | None
    components: list[Component]
    methods: dict[str, Method]
    supers: dict[str, str]
    sha256: str = ""
    diagnostics: list[dict] = field(default_factory=list)
    dex_count: int = 0
    catalog: object | None = field(default=None, repr=False, compare=False)

    def is_subtype(self, child: str, parent: str) -> bool:
        seen=set();todo=[child]
        while todo:
            typ=todo.pop()
            if typ==parent:return True
            if not typ or typ in seen:continue
            seen.add(typ);todo.append(self.supers.get(typ,''))
            if self.catalog is not None:todo.extend(self.catalog.interfaces.get(typ,()))
        return False

    def resolve(self, owner: str, name: str, desc: str) -> Method | None:
        seen = set()
        while owner and owner not in seen:
            seen.add(owner)
            if method := self.methods.get(f"{owner}->{name}{desc}"):
                return method
            owner = self.supers.get(owner, "")
        return None
