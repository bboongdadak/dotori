from __future__ import annotations

import hashlib
import re
from pathlib import Path
from zipfile import ZipFile

from .manifest import parse_manifest
from .model import Program


class InputError(ValueError):
    pass


def load_apk(path: str | Path, max_uncompressed: int = 512 * 1024 * 1024) -> Program:
    """Read metadata/compact references once; decode method IR on demand."""
    try:
        from loguru import logger
        logger.disable('androguard')
        from androguard.core.apk import APK
        from .index import Catalog, CompactDex
    except ImportError as exc:
        raise InputError('Install dotori-android with androguard==4.1.3') from exc
    path=Path(path)
    try:
        with ZipFile(path) as archive:
            infos=archive.infolist()
            if len({i.filename for i in infos})!=len(infos):raise InputError('Duplicate ZIP entries are unsupported')
            if sum(i.file_size for i in infos)>max_uncompressed:raise InputError('APK uncompressed size exceeds configured limit')
            names=sorted(i.filename for i in infos if re.fullmatch(r'classes(?:[2-9]|[1-9][0-9]+)?\.dex',i.filename))
            if 'classes.dex' not in names or 'AndroidManifest.xml' not in archive.namelist():raise InputError('APK must contain AndroidManifest.xml and classes.dex')
            apk=APK(str(path));root=apk.get_android_manifest_xml()
            if root is None:raise InputError('Cannot parse binary AndroidManifest.xml')
            package,target,minimum,components,notes=parse_manifest(root)
            catalog=Catalog([CompactDex(n,archive.read(n)) for n in names])
    except InputError:raise
    except Exception as exc:raise InputError(f'APK parse failed: {type(exc).__name__}: {exc}') from exc
    with path.open('rb') as source:
        digest=hashlib.file_digest(source,'sha256').hexdigest() if hasattr(hashlib,'file_digest') else hashlib.sha256(source.read()).hexdigest()
    return Program(package,target,minimum,components,catalog.methods,catalog.supers,digest,
                   notes+catalog.diagnostics,len(names),catalog)
