"""Conservative protocol-prefix evidence, separate from taint origins.

A javascript: string somewhere in the slice is not proof that a URL executes
script. Only the first known characters of the actual consumed value count.
"""
from .model import split_ref


def javascript_url_evidence(b, ref, reg, before, ctx=0, seen=frozenset()):
    key=(ref,reg,before,ctx)
    if key in seen or len(seen)>24:return None
    seen=seen|{key}
    if reg in b.contexts.get(ctx,{}):
        caller,r,offset,parent=b.contexts[ctx][reg]
        return javascript_url_evidence(b,caller,r,offset,parent,seen)
    m=b.p.methods[ref]
    definitions=b.definitions(ref,reg,before)
    if len(definitions)!=1:return None
    ins,guards=definitions[0]
    if ins is None or guards:return None
    site=b.site(ref,ins.offset)
    if ins.op.startswith('const-string'):
        return {'scheme':'javascript','prefix_site':site,'proof':'constant_prefix'} if str(ins.literal).lower().startswith('javascript:') else None
    if ins.op.startswith('move') and not ins.op.startswith('move-result'):
        return javascript_url_evidence(b,ref,ins.regs[1],ins.offset,ctx,seen)
    if not ins.op.startswith('move-result'):return None
    body=list(m.instructions);index=body.index(ins)
    if not index:return None
    call=body[index-1]
    if not call.ref or not call.op.startswith('invoke-'):return None
    owner,name,desc=split_ref(call.ref);actual=b.actuals(call)
    if owner=='Ljava/lang/String;' and name=='concat' and actual:
        return javascript_url_evidence(b,ref,actual[0],call.offset,ctx,seen)
    if owner not in ('Ljava/lang/StringBuilder;','Ljava/lang/StringBuffer;') or name!='toString' or not actual:return None
    objects=b.trace(ref,actual[0],call.offset,'object',ctx)
    if len(objects)!=1 or objects[0].kind!='allocation':return None
    wanted=objects[0].key
    # The builder must be local, straight-line, and not escape to an unknown
    # call before its first nonempty append. Mutating prefixes are rejected.
    initialized=False;prefix=None;first=False
    for prev in body:
        if prev.offset>=call.offset:break
        if prev.op.startswith(('if-','goto')) or prev.op in ('packed-switch','sparse-switch','throw'):return None
        if not prev.op.startswith('invoke-') or not prev.ref:continue
        regs=b.actuals(prev)
        matches=[]
        for rr in regs:
            vals=b.trace(ref,rr,prev.offset,'object',ctx)
            matches.append(any(a.key==wanted for a in vals))
        if not any(matches):continue
        po,pn,pd=split_ref(prev.ref)
        if po not in ('Ljava/lang/StringBuilder;','Ljava/lang/StringBuffer;') or not matches[0]:return None
        if pn=='<init>' and pd=='()V':initialized=True;continue
        if pn=='<init>' and pd=='(Ljava/lang/String;)V' and len(regs)>1:
            prefix=javascript_url_evidence(b,ref,regs[1],prev.offset,ctx,seen);initialized=True;first=True;continue
        if pn=='append' and initialized and len(regs)>1:
            if first:continue
            ok,val=b.local_constant(ref,regs[1],prev.offset)
            if ok and val=='':continue
            evidence=javascript_url_evidence(b,ref,regs[1],prev.offset,ctx,seen)
            if evidence:prefix=dict(evidence,proof='builder_first_append',builder=wanted)
            first=True;continue
        return None
    return prefix
