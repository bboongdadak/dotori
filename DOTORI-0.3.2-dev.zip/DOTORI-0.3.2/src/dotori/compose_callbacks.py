"""Registration-backed AndroidView factory callbacks, not all Function1.invoke."""
from dataclasses import replace
from .model import split_ref,parameters

OWNERS={'Landroidx/compose/ui/viewinterop/AndroidView_androidKt;','Landroidx/compose/ui/viewinterop/AndroidViewKt;'}
FUNCTION='Lkotlin/jvm/functions/Function1;'
CONTEXT='Landroid/content/Context;'


def _library_forwarder(ref):
    owner,name,_=split_ref(ref)
    return (owner in OWNERS and name=='AndroidView' or
            any(owner.startswith(o[:-1]+'$AndroidView$') for o in OWNERS))


def receivers(a,method,depth):
    if method.name!='invoke':return None
    key=('compose_factory_receivers',method.ref)
    if key in a.memo:return a.memo[key]
    if key in a.active:return None
    a.active.add(key)
    try:result=_receivers(a,method,depth)
    finally:a.active.remove(key)
    if result:a.memo[key]=result
    return result


def _receivers(a,method,depth):
    if method.name!='invoke' or not a.p.is_subtype(method.owner,FUNCTION):return None
    pars=parameters(method.descriptor);returned=method.descriptor.split(')',1)[1]
    specialized=pars==[CONTEXT] and (a.p.is_subtype(returned,'Landroid/view/View;') or a.p.is_subtype(returned,'Landroid/webkit/WebView;'))
    if not specialized:return None
    # The erased Function1 bridge must actually invoke this specialization.
    bridges=[]
    for ref in a.c.by_class.get(method.owner,()):
        m=a.p.methods[ref]
        if m.name=='invoke' and m.descriptor=='(Ljava/lang/Object;)Ljava/lang/Object;':
            bridges.extend(i for i in m.instructions if i.ref==method.ref and i.op.startswith('invoke-') and i.regs and a.is_local_this(m,i.regs[0],i.offset))
    if not bridges:return None
    sites=a.caller_cache.get(('compose_factory_sites',))
    if sites is None:
        sites=[]
        for (name,desc),refs in a.c.call_signatures.items():
            if name!='AndroidView' or parameters(desc)[:1]!=[FUNCTION] or not desc.endswith(')V'):continue
            for ref in sorted(refs):
                if split_ref(ref)[0] in OWNERS:
                    # Overload forwarding inside AndroidView is part of the
                    # outer registration, not another factory execution.
                    sites.extend(s for s in a.c.callers_of(ref) if not _library_forwarder(s.method))
        sites=sorted(sites,key=lambda s:(s.method,s.offset))
        a.caller_cache[('compose_factory_sites',)]=sites
    if not sites:return None
    out=[]
    construction_methods={s.method for r in a.c.by_class.get(method.owner,())
                          if split_ref(r)[1]=='<init>' for s in a.c.callers_of(r)}
    sites=sorted(sites,key=lambda s:(s.method not in construction_methods,s.method,s.offset))
    if len(sites)>64:a.note('compose_factory_registration_limit',method.ref)
    for site in sites[:64]:
        if not a.allowed(depth):break
        call=a.instruction(site.method,site.offset)
        if not call or not call.op.startswith('invoke-static') or not call.regs:continue
        previous=a.branch_query_limit
        a.branch_query_limit=min(previous if previous is not None else a.per_sink_limit,a.sink_queries+256)
        try:factories=a.trace(site.method,a.actuals(call)[0],call.offset,'object',0,depth+1)
        finally:a.branch_query_limit=previous
        for obj in factories:
            if obj.kind!='allocation':continue
            try:
                ref,off=obj.key.split(':call_context:',1)[0].rsplit('@',1)
                creation=a.instruction(ref,int(off,16))
            except (ValueError,KeyError):continue
            if not creation or creation.literal!=method.owner:continue
            token='compose_factory:'+obj.key+':registration:'+a.site(site.method,call.offset)
            out.append(replace(obj,callback_instances=obj.callback_instances|{token}).step('callback_registered:AndroidView_factory:'+a.site(site.method,call.offset)))
    return tuple(out) if out else None


def allocation_origins(a,method,instruction,depth,kind,typ):
    from .demand import Origin
    objects=receivers(a,method,depth)
    if not objects:return None
    result=[]
    for factory in objects:
        import hashlib,json
        key=('factory_execution',method.ref,factory)
        if key in a.context_keys:ctx=a.context_keys[key]
        else:
            ctx=a.next_context;a.next_context+=1;a.context_keys[key]=ctx
            a.contexts[ctx]={};a.context_origins[ctx]={method.argument_registers()[0]:(factory,)}
            a.context_tokens[ctx]=hashlib.sha256(json.dumps((method.ref,factory.key,sorted(factory.callback_instances))).encode()).hexdigest()[:24]
        result.append(Origin(kind,a.allocation_key(method,instruction,ctx),typ,
            path=factory.path+(a.site(method.ref,instruction.offset),'compose_factory_execution_lifetime_assumed'),
            guards=factory.guards,callback_instances=factory.callback_instances))
    return tuple(result)
