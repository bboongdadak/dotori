"""Bounded, object-specific ArrayList element transfers.

Replay only an unescaped local allocation in the concrete reader call stack.
Constant indexed reads, last(), and straight-line Iterator.next() select one
slot, never the union of all appends. Exact direct/static helper calls may
mutate that same allocation. Fields, factories outside the reader stack,
conditional control flow, unknown indices, bulk mutations and escaped aliases
remain explicit gaps. This is not a persisted-ID or lifecycle selection model.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

from .model import split_ref

OBJECT = 'Ljava/lang/Object;'
ARRAYLIST = 'Ljava/util/ArrayList;'
LIST = 'Ljava/util/List;'
ITERATOR = 'Ljava/util/Iterator;'
LIST_OWNERS = {ARRAYLIST, LIST, 'Ljava/util/AbstractList;', 'Ljava/util/Collection;',
               'Ljava/lang/Iterable;'}
KOTLIN_OWNERS = {'Lkotlin/collections/CollectionsKt;',
                 'Lkotlin/collections/CollectionsKt___CollectionsKt;',
                 'Lkotlin/collections/CollectionsKt__CollectionsKt;'}
READS = {('get', f'(I){OBJECT}'), ('size', '()I'), ('isEmpty', '()Z'),
         ('iterator', f'(){ITERATOR}')}
MAX_EVENTS = 512
MAX_ELEMENTS = 128
MAX_HELPER_DEPTH = 8


@dataclass(frozen=True)
class Element:
    method: str
    register: int
    before: int
    context: int
    write: str


class Unresolved(Exception):
    def __init__(self, code, detail):
        self.code, self.detail = code, detail


def _site(a, m, i):
    return a.site(m.ref, i.offset)


def _allocation(a, origins):
    """Casts and lookalike methods cannot manufacture a collection object."""
    if len(origins) != 1 or origins[0].kind != 'allocation':
        return None
    base = origins[0]
    try:
        ref, offset = base.key.split(':call_context:', 1)[0].rsplit('@', 1)
        instruction = a.instruction(ref, int(offset, 16))
    except (ValueError, KeyError):
        return None
    return base if instruction and instruction.op == 'new-instance' and instruction.literal == ARRAYLIST else None


def _frames(a, method, call, ctx):
    frames = [(method, call.offset, ctx)]
    seen = set()
    while ctx and ctx not in seen:
        seen.add(ctx)
        bindings = list(a.contexts.get(ctx, {}).values())
        if not bindings:
            break
        ref, _, offset, ctx = bindings[0]
        method = a.p.methods.get(ref)
        if not method:
            break
        frames.append((method, offset, ctx))
    return list(reversed(frames))


class Replay:
    def __init__(self, a, base, frames, depth):
        self.a, self.base, self.frames, self.depth = a, base, frames, depth
        self.elements = []
        self.initialized = False
        self.generation = 0
        self.events = 0
        self.iterators = {}  # Exact iterator allocation -> [next index, generation].
        self.helpers = []

    def fail(self, code, where):
        raise Unresolved('collection_' + code, where)

    def index(self, m, reg, before, ctx):
        values = self.a.trace(m.ref, reg, before, 'value', ctx, self.depth + 1)
        if len(values) != 1 or values[0].kind != 'constant':
            self.fail('index_unresolved', self.a.site(m.ref, before))
        try:
            return int(values[0].value)
        except ValueError:
            self.fail('index_unresolved', self.a.site(m.ref, before))

    def selected(self, m, call, ctx, aliases):
        owner, name, desc = split_ref(call.ref)
        args = self.a.actuals(call)
        static = call.op.startswith('invoke-static')
        where = _site(self.a, m, call)
        if not args or args[0] not in aliases:
            self.fail('receiver_alias_unresolved', where)
        identity = aliases[args[0]]
        if owner == ITERATOR and name == 'next' and desc == f'(){OBJECT}' and not static:
            if identity not in self.iterators:
                self.fail('iterator_alias_unresolved', where)
            index, generation = self.iterators[identity]
            if generation != self.generation:
                self.fail('iterator_mutation_unresolved', where)
            self.iterators[identity][0] += 1
            proof = 'collection_iterator_index:' + str(index)
        elif identity != self.base.key:
            self.fail('receiver_alias_unresolved', where)
        elif owner in LIST_OWNERS and name == 'get' and desc == f'(I){OBJECT}' and not static:
            index = self.index(m, args[1], call.offset, ctx)
            proof = 'collection_constant_index:' + str(index)
        elif owner in KOTLIN_OWNERS and name == 'last' and desc == f'({LIST}){OBJECT}' and static:
            index = len(self.elements) - 1
            proof = 'collection_last_index:' + str(index)
        else:
            self.fail('read_unresolved', where)
        if not self.initialized:
            self.fail('initialization_unresolved', where)
        if index < 0 or index >= len(self.elements):
            self.fail('index_out_of_bounds', where)
        return self.elements[index], proof

    def scan(self, m, start, stop, ctx, aliases, level=0):
        if level > MAX_HELPER_DEPTH:
            self.fail('helper_depth_limit', m.ref)
        # Reject paths whose replay may execute a different number of times.
        prior = [i for i in m.instructions if i.offset < stop]
        if m.has_exceptions or any(i.op.startswith(('if-', 'goto', 'throw')) or
                                  i.op in ('packed-switch', 'sparse-switch') for i in prior):
            self.fail('control_flow_unresolved', self.a.site(m.ref, stop))
        pending = None
        for i in prior:
            if i.offset <= start:
                continue
            self.events += 1
            if self.events > MAX_EVENTS or not self.a.allowed(self.depth + level):
                self.fail('replay_limit', _site(self.a, m, i))
            where = _site(self.a, m, i)
            if i.op.startswith('invoke-'):
                args = self.a.actuals(i)
                carried = {n: aliases[r] for n, r in enumerate(args) if r in aliases}
                pending = None
                if not carried:
                    continue
                if not i.ref or '->' not in i.ref or '(' not in i.ref:
                    self.fail('escape_unresolved', where + ':' + i.op)
                owner, name, desc = split_ref(i.ref)
                static = i.op.startswith('invoke-static')
                identity = carried.get(0) if not static else None
                if identity == self.base.key and owner in LIST_OWNERS:
                    if any(n != 0 for n in carried):
                        self.fail('escape_unresolved', where)
                    if name == '<init>' and owner == ARRAYLIST and desc in ('()V', '(I)V') and i.op.startswith('invoke-direct'):
                        if self.initialized:
                            self.fail('initialization_unresolved', where)
                        self.initialized = True
                    elif not self.initialized:
                        self.fail('initialization_unresolved', where)
                    elif (name, desc) in READS:
                        if name == 'get':
                            self.selected(m, i, ctx, aliases)
                        if name == 'iterator':
                            pending = self.a.allocation_key(m, i, ctx)
                            self.iterators[pending] = [0, self.generation]
                        # get returns the chosen element; never the list itself.
                    elif name == 'add' and desc == f'({OBJECT})Z':
                        self.elements.append(Element(m.ref, args[1], i.offset, ctx, where))
                        self.generation += 1
                    elif (name, desc) in (('add', f'(I{OBJECT})V'), ('set', f'(I{OBJECT}){OBJECT}')):
                        index = self.index(m, args[1], i.offset, ctx)
                        if index < 0 or index > len(self.elements) or (name == 'set' and index == len(self.elements)):
                            self.fail('index_out_of_bounds', where)
                        element = Element(m.ref, args[2], i.offset, ctx, where)
                        if name == 'add':
                            self.elements.insert(index, element)
                        else:
                            self.elements[index] = element
                        self.generation += 1
                    elif name == 'remove' and desc == f'(I){OBJECT}':
                        index = self.index(m, args[1], i.offset, ctx)
                        if index < 0 or index >= len(self.elements):
                            self.fail('index_out_of_bounds', where)
                        self.elements.pop(index)
                        self.generation += 1
                    elif name == 'clear' and desc == '()V':
                        self.elements.clear()
                        self.generation += 1
                    else:
                        self.fail('mutation_unresolved', where + ':' + i.ref)
                    if len(self.elements) > MAX_ELEMENTS:
                        self.fail('element_limit', where)
                elif identity in self.iterators and owner == ITERATOR:
                    if len(carried) != 1:
                        self.fail('escape_unresolved', where)
                    if name == 'next' and desc == f'(){OBJECT}':
                        self.selected(m, i, ctx, aliases)
                    elif (name, desc) != ('hasNext', '()Z'):
                        self.fail('iterator_mutation_unresolved', where)
                elif static and owner in KOTLIN_OWNERS and name == 'last' and desc == f'({LIST}){OBJECT}' and carried == {0: self.base.key}:
                    self.selected(m, i, ctx, aliases)
                elif static and owner == 'Lkotlin/jvm/internal/Intrinsics;' and (name, desc) in (
                        ('checkNotNull', f'({OBJECT})V'),
                        ('checkNotNull', f'({OBJECT}Ljava/lang/String;)V'),
                        ('checkNotNullParameter', f'({OBJECT}Ljava/lang/String;)V'),
                        ('checkNotNullExpressionValue', f'({OBJECT}Ljava/lang/String;)V')):
                    # These checks neither retain nor mutate a collection.
                    pass
                else:
                    # Exact helpers only: virtual/interface dispatch may override.
                    target = self.a.p.methods.get(i.ref) if i.op.startswith(('invoke-static', 'invoke-direct')) else None
                    if not target or {'abstract', 'native'}.intersection(target.access.split()):
                        self.fail('escape_unresolved', where + ':' + i.ref)
                    child = self.a.binding(m.ref, i, target, ctx)
                    formals = target.argument_registers()
                    mapping = {formals[n]: value for n, value in carried.items() if n < len(formals)}
                    self.helpers.append(where)
                    self.scan(target, -1, max((j.offset for j in target.instructions), default=-1) + 1,
                              child, mapping, level + 1)
            elif i.op.startswith(('iput', 'sput', 'aput', 'return')):
                if i.regs and i.regs[0] in aliases:
                    self.fail('escape_unresolved', where)
                if i.op.startswith('iput') and len(i.regs) > 1 and i.regs[1] in aliases:
                    self.fail('mutation_unresolved', where)
                if i.op.startswith('return'):
                    if level == 0:
                        self.fail('control_flow_unresolved', where)
                    break
            elif i.op.startswith('iget') and len(i.regs) > 1 and i.regs[1] in aliases:
                self.fail('escape_unresolved', where)
            elif i.op.startswith('filled-new-array'):
                if any(r in aliases for r in i.regs):
                    self.fail('escape_unresolved', where)
            elif i.op == 'check-cast':
                pass
            elif i.op.startswith('move-result'):
                if i.regs:
                    aliases.pop(i.regs[0], None)
                    if pending:
                        aliases[i.regs[0]] = pending
                pending = None
            elif i.op.startswith('move') and len(i.regs) > 1:
                value = aliases.get(i.regs[1])
                aliases.pop(i.regs[0], None)
                if value:
                    aliases[i.regs[0]] = value
            elif i.regs and self.a.defines(i, i.regs[0]):
                aliases.pop(i.regs[0], None)
        return aliases

    def run(self, method, call, ctx):
        location = self.a.allocation_contexts.get(self.base.key)
        allocation_ref, offset = self.base.key.split(':call_context:', 1)[0].rsplit('@', 1)
        offset = int(offset, 16)
        root = next((n for n, (m, _, c) in enumerate(self.frames)
                     if m.ref == allocation_ref and location == (m.ref, c)), None)
        if root is None:
            self.fail('lifecycle_order_unresolved', _site(self.a, method, call) + ':' + self.base.key)
        instruction = self.a.instruction(allocation_ref, offset)
        aliases = {instruction.regs[0]: self.base.key}
        for n, (m, stop, context) in enumerate(self.frames[root:], root):
            aliases = self.scan(m, offset if n == root else -1, stop, context, aliases)
            if n + 1 < len(self.frames):
                invocation = self.a.instruction(m.ref, stop)
                child = self.frames[n + 1][0]
                actual = self.a.actuals(invocation)
                aliases = {formal: aliases[reg] for formal, reg in zip(child.argument_registers(), actual) if reg in aliases}
        return self.selected(method, call, ctx, aliases)


def result(a, method, call, mode, ctx, depth):
    """None means inapplicable; () is a recognized but unresolved selection."""
    if not call.ref or '(' not in call.ref:
        return None
    owner, name, desc = split_ref(call.ref)
    static = call.op.startswith('invoke-static')
    iterator = owner in LIST_OWNERS and name == 'iterator' and desc == f'(){ITERATOR}' and not static
    next_element = owner == ITERATOR and name == 'next' and desc == f'(){OBJECT}' and not static
    get = owner in LIST_OWNERS and name == 'get' and desc == f'(I){OBJECT}' and not static
    last = owner in KOTLIN_OWNERS and name == 'last' and desc == f'({LIST}){OBJECT}' and static
    if not (iterator or next_element or get or last):
        return None
    actual = a.actuals(call)
    where = _site(a, method, call)
    if not iterator and (method.has_exceptions or any(
            i.op.startswith(('if-', 'goto', 'throw')) or i.op in ('packed-switch', 'sparse-switch')
            for i in method.instructions if i.offset < call.offset)):
        a.note('collection_control_flow_unresolved', where)
        return ()
    if not actual:
        a.note('collection_receiver_alias_unresolved', where)
        return ()
    origins = a.trace(method.ref, actual[0], call.offset, 'object', ctx, depth + 1)
    if next_element:
        if len(origins) != 1 or origins[0].kind != 'collection_iterator':
            a.note('collection_iterator_alias_unresolved', where)
            return ()
        origin = origins[0]
        location = a.allocation_contexts.get(origin.key)
        if not location:
            a.note('collection_iterator_alias_unresolved', where)
            return ()
        ref, offset = origin.key.split(':call_context:', 1)[0].rsplit('@', 1)
        creation = a.instruction(ref, int(offset, 16))
        bases = a.trace(ref, a.actuals(creation)[0], creation.offset, 'object', location[1], depth + 1)
    else:
        bases = origins
    base = _allocation(a, bases)
    if base is None:
        a.note('collection_receiver_alias_unresolved', where)
        return ()
    if iterator:
        from .demand import Origin
        key = a.allocation_key(method, call, ctx)
        return (Origin('collection_iterator', key, ITERATOR,
                       path=base.path + ('collection_object:' + base.key, 'collection_iterator_created:' + where),
                       guards=base.guards, callback_instances=base.callback_instances),)
    try:
        replay = Replay(a, base, _frames(a, method, call, ctx), depth)
        element, selection = replay.run(method, call, ctx)
    except Unresolved as gap:
        a.note(gap.code, gap.detail)
        return ()
    from .demand import compatible
    values = a.trace(element.method, element.register, element.before, mode, element.context, depth + 1)
    if not values:
        a.note('collection_value_unresolved', where)
    proof = ('collection_object:' + base.key, 'collection_write:' + element.write,
             selection, 'collection_read:' + where)
    return tuple(replace(value, path=value.path + base.path +
                         tuple('collection_helper:' + s for s in replay.helpers) + proof,
                         guards=value.guards | base.guards,
                         callback_instances=value.callback_instances | base.callback_instances)
                 for value in values if compatible(value, base))
