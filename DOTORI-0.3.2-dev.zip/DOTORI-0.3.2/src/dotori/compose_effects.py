"""LaunchedEffect registration followed through the lambda's real create body.

The template is not treated as the resumed object. Its invoke method must
actually create/return a continuation and call invokeSuspend on that result.
Scheduling, cancellation, and the number of launches remain runtime assumptions.
"""
from dataclasses import replace
from .model import parameters, split_ref

FUNCTION = 'Lkotlin/jvm/functions/Function2;'
OBJECT = 'Ljava/lang/Object;'
CONT = 'Lkotlin/coroutines/Continuation;'
INVOKE = '(Lkotlinx/coroutines/CoroutineScope;' + CONT + ')' + OBJECT
CREATE = '(' + OBJECT + CONT + ')' + CONT
SUSPEND = '(' + OBJECT + ')' + OBJECT
EFFECTS = 'Landroidx/compose/runtime/EffectsKt;'
COMPOSER = 'Landroidx/compose/runtime/Composer;'


def receivers(a, method, depth):
    if method.name not in ('invoke', 'invokeSuspend'):return None
    if not a.p.is_subtype(method.owner, FUNCTION):return None
    key = ('compose_effect_receivers', method.ref)
    if key in a.memo:return a.memo[key]
    if key in a.active:return None
    a.active.add(key)
    try:result = _receivers(a, method, depth)
    finally:a.active.remove(key)
    if result:a.memo[key] = result
    return result


def _receivers(a, method, depth):
    if method.name == 'invokeSuspend':
        if method.descriptor != SUSPEND:return None
        invoke = a.p.methods.get(method.owner + '->invoke' + INVOKE)
        if not invoke:return None
        from .view_lookup import _call_sources
        # Require the actual call on the result of this.create(...). The create
        # body is traced with its bound template, including constructor captures.
        creates = {i.offset for i in invoke.instructions
                   if i.ref == method.owner + '->create' + CREATE and i.regs
                   and a.is_local_this(invoke, i.regs[0], i.offset)}
        templates = receivers(a, invoke, depth + 1)
        if not templates:return None
        out = []
        for call in invoke.instructions:
            if call.ref != method.ref or not call.regs:continue
            sources = _call_sources(a, invoke, call.regs[0], call.offset)
            if not sources or not sources <= creates:continue
            for template in templates:
                import hashlib, json
                key = ('effect_execution', invoke.ref, template)
                if key in a.context_keys:ctx = a.context_keys[key]
                else:
                    ctx = a.next_context;a.next_context += 1;a.context_keys[key] = ctx
                    a.contexts[ctx] = {}
                    a.context_origins[ctx] = {invoke.argument_registers()[0]:(template,)}
                    a.context_tokens[ctx] = hashlib.sha256(json.dumps((invoke.ref,template.key,sorted(template.callback_instances))).encode()).hexdigest()[:24]
                values = a.trace(invoke.ref, call.regs[0], call.offset, 'object', ctx, depth + 1)
                out.extend(_continuations(a, method, invoke, call, template, values))
        return tuple(out) or None
    if method.descriptor != INVOKE:return None
    return _templates(a, method, depth)


def _continuations(a, method, invoke, call, template, values):
    out = []
    for value in values:
        # A cast alone is insufficient: it must be a fresh continuation
        # of this class reached through the real create return body.
        if value.kind != 'allocation':continue
        try:
            ref, off = value.key.split(':call_context:', 1)[0].rsplit('@', 1)
            creation = a.instruction(ref, int(off, 16))
        except (ValueError, KeyError):continue
        if not creation or creation.literal != method.owner:continue
        from .demand import compatible
        if not compatible(value,template):continue
        out.append(replace(value,path=template.path+value.path,
                           guards=value.guards|template.guards,
                           callback_instances=value.callback_instances|template.callback_instances)
                   .step('coroutine_created_then_invoked:' + a.site(invoke.ref, call.offset)))
    return out


def _templates(a, method, depth):
    bridges = [a.p.methods[r] for r in a.c.by_class.get(method.owner, ())
               if r == method.owner + '->invoke(' + OBJECT + OBJECT + ')' + OBJECT]
    if not any(i.ref == method.ref and i.regs and a.is_local_this(b, i.regs[0], i.offset)
               for b in bridges for i in b.instructions):return None
    sites = a.caller_cache.get(('launched_effect_sites',))
    if sites is None:
        sites = []
        for (name, desc), refs in a.c.call_signatures.items():
            ps = parameters(desc)
            if name != 'LaunchedEffect' or not desc.endswith(')V'):continue
            if len(ps) < 4 or ps[-3:] != [FUNCTION, COMPOSER, 'I']:continue
            keys = ps[:-3]
            if keys not in ([OBJECT], [OBJECT, OBJECT], [OBJECT, OBJECT, OBJECT], ['[' + OBJECT]):continue
            for ref in refs:
                if split_ref(ref)[0] == EFFECTS:
                    sites.extend(s for s in a.c.callers_of(ref)
                                 if not (split_ref(s.method)[0]==EFFECTS and split_ref(s.method)[1]=='LaunchedEffect'))
        sites = sorted(sites, key=lambda s:(s.method, s.offset))
        a.caller_cache[('launched_effect_sites',)] = sites
    out = []
    construction_methods = {s.method for r in a.c.by_class.get(method.owner, ())
                            if split_ref(r)[1] == '<init>' for s in a.c.callers_of(r)}
    sites = sorted(sites, key=lambda s:(s.method not in construction_methods,s.method,s.offset))
    if len(sites) > 64:a.note('compose_effect_registration_limit', method.ref)
    for site in sites[:64]:
        if not a.allowed(depth):break
        call = a.instruction(site.method, site.offset)
        if not call or not call.op.startswith('invoke-static'):continue
        actual = a.actuals(call)
        index = len(parameters(split_ref(call.ref)[2])) - 3
        if index >= len(actual):continue
        previous = a.branch_query_limit
        a.branch_query_limit = min(previous if previous is not None else a.per_sink_limit, a.sink_queries + 256)
        try:values = a.trace(site.method, actual[index], call.offset, 'object', 0, depth + 1)
        finally:a.branch_query_limit = previous
        for obj in values:
            if obj.kind != 'allocation':continue
            try:
                ref, off = obj.key.split(':call_context:', 1)[0].rsplit('@', 1)
                creation = a.instruction(ref, int(off, 16))
            except (ValueError, KeyError):continue
            if not creation or creation.literal != method.owner:continue
            token = 'compose_effect:' + obj.key + ':registration:' + a.site(site.method, call.offset)
            out.append(replace(obj, callback_instances=obj.callback_instances | {token})
                       .step('callback_registered:LaunchedEffect:' + a.site(site.method, call.offset))
                       .step('launched_effect_scheduling_lifetime_assumed'))
    return tuple(out) or None
