"""Constructor-owned helper contexts for receiver-specific field initialization."""
import hashlib
import json
from .model import split_ref


def call_choice(a,target,caller,call,parent):
    token=(caller.ref,call.offset,a.context_tokens.get(parent,''))
    digest=hashlib.sha256(json.dumps(token).encode()).hexdigest()[:24]
    return 'call_tuple:'+json.dumps((target.ref,digest),separators=(',',':'))


def receiver_calls(a,method,depth):
    """Actual invocation receivers precede unrelated construction instances."""
    from .demand import compatible
    out=[];sites=a.c.callers_of(method.ref)
    if len(sites)>64:a.note('receiver_caller_limit',method.ref)
    for site in sites[:64]:
        call=a.instruction(site.method,site.offset)
        if not call or not call.regs or call.op.startswith('invoke-static'):continue
        caller=a.p.methods[site.method]
        if not a.reachable(caller.ref,call.offset):continue
        previous=a.branch_query_limit
        a.branch_query_limit=min(previous if previous is not None else a.per_sink_limit,a.sink_queries+128)
        try:
            values=a.trace(caller.ref,a.actuals(call)[0],call.offset,'object',0,depth+1)
            for base in values:
                # A relative 'this' from another frame is not an instance proof.
                if base.kind not in ('allocation','component','view','view_lookup','field_slot'):continue
                typ=base.typ
                if typ and not a.p.is_subtype(typ,method.owner):continue
                out.append(base.step(call_choice(a,method,caller,call,0)).step('invocation_receiver:'+a.site(caller.ref,call.offset)))
        finally:a.branch_query_limit=previous
    return tuple(out)


def owner_context(a,method,base):
    """Bind a conditional framework-created View to its own constructor this."""
    key=('constructor_owner',method.ref,base)
    if key in a.context_keys:return a.context_keys[key]
    ctx=a.next_context;a.next_context+=1;a.context_keys[key]=ctx
    proof=base.step('framework_constructor_assumed:'+method.ref)
    a.contexts[ctx]={}
    a.context_origins[ctx]={method.argument_registers()[0]:(proof,)}
    a.context_tokens[ctx]=hashlib.sha256(json.dumps((method.ref,base.key)).encode()).hexdigest()[:24]
    return ctx


def writer_contexts(a,base,target,depth):
    """Follow constructor calls on exactly this owner; never all helper callers.

    Framework Views require an anchored lookup origin and retain explicit
    construction/non-null/lifetime assumptions. App allocations use actual
    constructor callsites. Static helpers and lifecycle methods are not guessed.
    """
    from .demand import compatible
    if base.kind not in ('allocation','view_lookup','view'):return ()
    typ=base.typ
    if base.kind=='allocation':
        try:
            ref,off=base.key.split(':call_context:',1)[0].rsplit('@',1)
            creation=a.instruction(ref,int(off,16))
        except (ValueError,KeyError):return ()
        if not creation or creation.op!='new-instance':return ()
        typ=str(creation.literal)
    elif not (a.p.is_subtype(typ,'Landroid/view/View;') or a.p.is_subtype(typ,'Landroid/webkit/WebView;')):
        return ()
    if not typ or not a.p.is_subtype(typ,target.owner):return ()
    pending=[]
    for ref in a.c.by_class.get(typ,()):
        ctor=a.p.methods[ref]
        if ctor.name!='<init>' or not ctor.argument_registers():continue
        contexts=(a.constructor_contexts(base,ctor,depth+1) if base.kind=='allocation' else (owner_context(a,ctor,base),))
        pending.extend((ctor,c,0) for c in contexts)
    out=[];seen=set();events=0
    while pending and len(seen)<32 and a.allowed(depth):
        method,ctx,hops=pending.pop(0)
        if (method.ref,ctx) in seen:continue
        seen.add((method.ref,ctx))
        if method.ref==target.ref:out.append(ctx);continue
        if hops>=4:a.note('initializer_helper_depth_limit',method.ref);continue
        for call in method.instructions:
            if not call.op.startswith('invoke-') or not call.ref or call.op.startswith('invoke-static'):continue
            events+=1
            if events>128:a.note('initializer_helper_call_limit',target.ref);return tuple(dict.fromkeys(out))
            owner,name,desc=split_ref(call.ref)
            if not a.p.is_subtype(typ,owner):continue
            callee=(a.p.methods.get(call.ref) if call.op.startswith(('invoke-direct','invoke-super')) else a.p.resolve(typ,name,desc))
            if not callee or not callee.instructions:continue
            # Only helpers with a syntactic call/field route to this writer.
            if callee.ref!=target.ref and hops>=3:continue
            actual=a.actuals(call)
            if not actual or not a.reachable(method.ref,call.offset):continue
            owners=a.trace(method.ref,actual[0],call.offset,'object',ctx,depth+1)
            if not any(v.key==base.key and compatible(v,base) for v in owners):continue
            child=a.binding(method.ref,call,callee,ctx)
            pending.append((callee,child,hops+1))
    if pending:a.note('initializer_context_limit',target.ref)
    return tuple(dict.fromkeys(out))
