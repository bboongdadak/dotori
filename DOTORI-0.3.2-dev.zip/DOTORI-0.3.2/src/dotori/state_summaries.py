"""Object-sensitive Compose state summaries with explicit write-order limits.

Like a field summary, setValue writes one receiver-owned slot and getValue
reads it.  Unlike name-only propagation, both operands must identify the same
allocation.  Setter wrappers are replayed in each caller context so a value
from one invocation cannot be paired with the state from another invocation.
No composition/coroutine scheduling or recomposition equivalence is inferred.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

from .model import split_ref

STATE = 'Landroidx/compose/runtime/State;'
MUTABLE = 'Landroidx/compose/runtime/MutableState;'
OBJECT = 'Ljava/lang/Object;'
POLICY = 'Landroidx/compose/runtime/SnapshotMutationPolicy;'
FACTORY_OWNERS = {'Landroidx/compose/runtime/SnapshotStateKt;',
                  'Landroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt;'}
FACTORIES = {('mutableStateOf', f'({OBJECT}{POLICY}){MUTABLE}'),
             ('mutableStateOf$default', f'({OBJECT}{POLICY}I{OBJECT}){MUTABLE}')}


def _heap_compatible(left, right):
    # A proven heap slot carries values between different callbacks. Callback
    # identity is retained in the resulting witness, not required to intersect
    # at the transfer. Branch and invocation choices still must agree.
    from .demand import compatible
    return compatible(replace(left, callback_instances=frozenset()),
                      replace(right, callback_instances=frozenset()))


@dataclass(frozen=True)
class Write:
    method: str
    offset: int
    context: int
    root: str
    root_offset: int
    root_context: int
    guarded: bool
    chain: tuple[str, ...]
    order: tuple[int, ...]
    events: tuple[tuple[str, int, int], ...]


def _formal(analysis, method, reg, before, seen=frozenset()):
    """Recognize only a formal copied/cast locally, never guess through a field."""
    key = (reg, before)
    if key in seen or len(seen) > 16:
        return None
    definitions = analysis.definitions(method.ref, reg, before)
    if len(definitions) != 1:
        return None
    instruction, _ = definitions[0]
    if instruction is None:
        formals = method.argument_registers()
        return formals.index(reg) if reg in formals else None
    if instruction.op == 'check-cast':
        return _formal(analysis, method, reg, instruction.offset, seen | {key})
    if instruction.op.startswith('move') and not instruction.op.startswith('move-result'):
        return _formal(analysis, method, instruction.regs[1], instruction.offset, seen | {key})
    return None


def _guarded(method, before):
    return method.has_exceptions or any(
        i.op.startswith(('if-', 'goto', 'throw')) or i.op in ('packed-switch', 'sparse-switch')
        for i in method.instructions if i.offset < before)


def _reader_frames(analysis, method, offset, ctx):
    """The concrete stack already established by the demand slice."""
    frames = {method.ref: (offset, ctx)}
    seen = set()
    while ctx and ctx not in seen:
        seen.add(ctx)
        bound = list(analysis.contexts.get(ctx, {}).values())
        if not bound:
            break
        caller, _, before, parent = bound[0]
        frames[caller] = (before, parent)
        ctx = parent
    return frames


def _writes(analysis, frames, depth, writer_specs=None):
    """Expand exact setter callsites, preserving argument tuples together."""
    # Other exact receiver-owned slots share the same context replay.
    specs = writer_specs or (("setValue", f'({OBJECT})V',
                              lambda owner: analysis.p.is_subtype(owner, MUTABLE)),)
    sites = [s for name, descriptor, accepts in specs
             for ref in analysis.c.call_signatures.get((name, descriptor), ())
             if accepts(split_ref(ref)[0]) for s in analysis.c.callers_of(ref)]
    prefix = 'L' + analysis.p.package.replace('.', '/') + '/'
    sites.sort(key=lambda s: (not s.method.startswith(prefix), s.method, s.offset))
    if len(sites) > 256:
        analysis.note('state_writer_fanout_limit', str(len(sites)))
    out = []

    def expand(method, before, reg, chain, seen):
        if not analysis.allowed(depth + len(chain)):
            return
        if method.ref in seen or len(chain) > 8:
            analysis.note('state_writer_context_limit', analysis.site(method.ref, before))
            return
        formal = _formal(analysis, method, reg, before)
        callers = analysis.c.callers_of(method.ref) if formal is not None else ()
        if callers:
            if len(callers) > 64:
                analysis.note('state_writer_context_limit', method.ref)
            for caller in callers[:64]:
                call = analysis.instruction(caller.method, caller.offset)
                cm = analysis.p.methods.get(caller.method)
                actual = analysis.actuals(call) if call else ()
                if cm and formal < len(actual):
                    expand(cm, call.offset, actual[formal],
                           ((cm, call, method),) + chain, seen | {method.ref})
            return
        # Stop at a local definition, including a constructor-captured field.
        # Binding an arbitrary framework invoke caller would invent a different
        # heap context for a callback allocation reached directly from a seed.
        root_context = frames.get(method.ref, (None, 0))[1]
        context = root_context
        guarded = _guarded(method, before)
        proof = []
        events = []
        for cm, call, target in chain:
            events.append((cm.ref, call.offset, context))
            guarded |= _guarded(cm, call.offset)
            proof.append(analysis.site(cm.ref, call.offset))
            context = analysis.binding(cm.ref, call, target, context)
        terminal = chain[-1][2] if chain else method
        terminal_offset = terminal_call.offset
        guarded |= _guarded(terminal, terminal_offset)
        events.append((terminal.ref, terminal_offset, context))
        out.append(Write(terminal.ref, terminal_offset, context, method.ref,
                         before, root_context, guarded, tuple(proof),
                         tuple(call.offset for _, call, _ in chain) + (terminal_offset,), tuple(events)))

    for site in sites[:256]:
        if not analysis.allowed(depth):
            break
        terminal_call = analysis.instruction(site.method, site.offset)
        method = analysis.p.methods.get(site.method)
        if not terminal_call or not method:
            continue
        actual = analysis.actuals(terminal_call)
        if terminal_call.op.startswith('invoke-static') or len(actual) < 2:
            continue
        expand(method, terminal_call.offset, actual[0], (), frozenset())
    return tuple(out)


def _state_origins(analysis, origins):
    result = []
    for origin in origins:
        if origin.kind != 'allocation':
            continue
        if any(':compose_state_factory' in step for step in origin.path):
            result.append(origin)
            continue
        # A check-cast changes the displayed type; it cannot turn an arbitrary
        # allocation (for example Composer.Empty) into a genuine state object.
        allocation = origin.key.split(':call_context:', 1)[0]
        try:
            ref, offset = allocation.rsplit('@', 1)
            instruction = analysis.instruction(ref, int(offset, 16))
        except (ValueError, KeyError):
            instruction = None
        if (instruction and instruction.op == 'new-instance' and
                analysis.p.is_subtype(str(instruction.literal), STATE)):
            result.append(origin)
    return tuple(result)


def result(analysis, method, call, mode, ctx, depth):
    """None means inapplicable; () means recognized but no verified relation."""
    if not call.ref or '(' not in call.ref:
        return None
    owner, name, desc = split_ref(call.ref)
    actual = analysis.actuals(call)
    if (owner in FACTORY_OWNERS and (name, desc) in FACTORIES
            and call.op.startswith('invoke-static') and actual):
        from .demand import Origin
        key = analysis.allocation_key(method, call, ctx)
        if _guarded(method, call.offset):
            analysis.note('conditional_state_identity', analysis.site(method.ref, call.offset))
        return (Origin('allocation', key, MUTABLE,
                       path=(analysis.site(method.ref, call.offset) + ':compose_state_factory',)),)
    if call.ref == 'Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;':
        analysis.note('compose_remembered_value_unresolved', analysis.site(method.ref, call.offset))
        return ()
    if not (name == 'getValue' and desc == f'(){OBJECT}' and actual
            and not call.op.startswith('invoke-static') and
            (owner in (STATE, MUTABLE) or analysis.p.is_subtype(owner, STATE))):
        return None
    from .demand import compatible
    where = analysis.site(method.ref, call.offset)
    origins = analysis.trace(method.ref, actual[0], call.offset, 'object', ctx, depth)
    bases = _state_origins(analysis, origins)
    if not bases or len(bases) != len(origins):
        analysis.note('state_receiver_alias_unresolved', where)
    if not bases:
        return ()
    frames = _reader_frames(analysis, method, call.offset, ctx)
    writes = _writes(analysis, frames, depth)
    out = []
    for base in bases:
        candidates = []
        candidate_values = {}
        unknown = []
        ambiguous = []
        for write in writes:
            # Known stack order is authoritative; a later write cannot define
            # a read in the same invocation (including helper accessors).
            ordered_event = next(((offset, frames[ref][0]) for ref, offset, context
                                  in reversed(write.events)
                                  if ref in frames and context == frames[ref][1]), None)
            if ordered_event and ordered_event[0] >= ordered_event[1]:
                continue
            instruction = analysis.instruction(write.method, write.offset)
            operands = analysis.actuals(instruction)
            # Give unrelated publisher alternatives a bounded share, reserving
            # half the remaining budget for the selected value and its witness.
            previous = analysis.branch_query_limit
            share = max(8, min(256, (analysis.per_sink_limit - analysis.sink_queries) //
                               max(2, 2 * len(writes))))
            analysis.branch_query_limit = min(previous if previous is not None else analysis.per_sink_limit,
                                              analysis.sink_queries + share)
            try:
                targets = analysis.trace(write.method, operands[0], write.offset,
                                         'object', write.context, depth)
            finally:
                analysis.branch_query_limit = previous
            targets = tuple(a for a in targets if _heap_compatible(a, base))
            known = _state_origins(analysis, targets)
            matching = [a for a in known if a.key == base.key and _heap_compatible(a, base)]
            if not matching:
                if not targets or len(known) != len(targets):
                    unknown.append(write)
                continue
            # Multiple possible state receivers are not a must-alias write.
            if len({a.key for a in known}) != 1 or len(known) != len(targets):
                analysis.note('state_writer_alias_unresolved', analysis.site(write.root, write.root_offset))
                ambiguous.append(write)
                continue
            candidates.append((write, matching[0]))
            # Preserve this proven slot's value before unrelated writer slices
            # spend the rest of the seed budget. Selection and overwrite/order
            # checks below still run over all discovered candidates unchanged.
            previous = analysis.branch_query_limit
            share = max(8, min(256, (analysis.per_sink_limit - analysis.sink_queries) // 4))
            analysis.branch_query_limit = min(previous if previous is not None else analysis.per_sink_limit,
                                              analysis.sink_queries + share)
            try:
                candidate_values[write] = analysis.trace(write.method, operands[1], write.offset,
                                                         mode, write.context, depth)
            finally:
                analysis.branch_query_limit = previous
        if not candidates:
            analysis.note('state_write_unresolved', where + ':' + base.key)
            continue
        # Last-write wins only within one concrete root invocation. Across
        # callbacks there is no established total order, so multiple publishers
        # stay unresolved rather than combining every historical value.
        groups = {(w.root, w.root_context) for w, _ in candidates}
        if len(groups) != 1:
            analysis.note('state_write_order_unresolved', where + ':' + base.key)
            continue
        write, target = max(candidates, key=lambda item: item[0].order)
        if any((u.root, u.root_context) != (write.root, write.root_context) or
               u.order >= write.order for u in ambiguous):
            analysis.note('state_writer_alias_unresolved', where + ':' + base.key)
            continue
        if any(u.root == write.root and u.root_context == write.root_context
               and u.order >= write.order for u in unknown):
            analysis.note('state_writer_alias_unresolved', where + ':' + base.key)
            continue
        if write.guarded:
            analysis.note('conditional_state_write', analysis.site(write.root, write.root_offset))
            continue
        if write.root not in frames:
            # Retain a useful field-like relation but explicitly do not claim
            # that this independent callback executed before the reader.
            analysis.note('state_lifecycle_order_unresolved', where + ':' + analysis.site(write.root, write.root_offset))
        if base.guards or target.guards:
            analysis.note('conditional_state_identity', where + ':' + base.key)
        instruction = analysis.instruction(write.method, write.offset)
        operands = analysis.actuals(instruction)
        values = candidate_values.get(write, ())
        if not values and analysis.allowed(depth):
            values = analysis.trace(write.method, operands[1], write.offset, mode, write.context, depth)
        if not values:
            analysis.note('state_value_unresolved', analysis.site(write.method, write.offset))
        if len({(a.kind, a.key) for a in values}) > 1:
            analysis.note('state_value_alias_unresolved', analysis.site(write.method, write.offset))
            continue
        for value in values:
            if not _heap_compatible(value, base) or not _heap_compatible(value, target):
                continue
            proof = ('state_object:' + base.key,
                     'state_write:' + analysis.site(write.method, write.offset))
            proof += tuple('state_writer_call:' + s for s in write.chain)
            proof += ('state_read:' + where,)
            if write.root not in frames:
                proof += ('state_read_after_write_assumed',)
            out.append(replace(value, guards=value.guards | base.guards | target.guards,
                               callback_instances=value.callback_instances | base.callback_instances | target.callback_instances,
                               path=value.path + proof))
    return tuple(out)
