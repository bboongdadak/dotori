"""Exact local string-keyed HashMap/LinkedHashMap transfers.

This is a value/container summary, not a router-registration summary. It never
infers that a generated route table ran, identifies an unbound Map formal with
a global registry, or bypasses reflective loading and interceptor callbacks.
"""
from __future__ import annotations

from dataclasses import replace

from .model import split_ref
from .webview_callbacks import allocation_type

MAP = 'Ljava/util/Map;'
HASHMAP = 'Ljava/util/HashMap;'
LINKED = 'Ljava/util/LinkedHashMap;'
IMPLEMENTATIONS = (HASHMAP, LINKED)
OWNERS = (MAP,) + IMPLEMENTATIONS
OBJECT = 'Ljava/lang/Object;'
GET = '(' + OBJECT + ')' + OBJECT
PUT = '(' + OBJECT + OBJECT + ')' + OBJECT
READS = {('get', GET), ('containsKey', '(' + OBJECT + ')Z'),
         ('size', '()I'), ('isEmpty', '()Z')}
MUTATIONS = {('put', PUT), ('remove', GET), ('clear', '()V')}
EMPTY_CONSTRUCTORS = ('()V', '(I)V', '(IF)V', '(IFZ)V')


def _string_key(analysis, method, reg, before, ctx, seen=frozenset()):
    """Only literal Strings/copies/bound formals; never conflate int 1 and '1'."""
    state = (method.ref, reg, before, ctx)
    if state in seen or len(seen) >= 16:
        return None
    definitions = analysis.definitions(method.ref, reg, before)
    if len(definitions) != 1 or definitions[0][1]:
        return None
    instruction, _ = definitions[0]
    if instruction is None:
        bound = analysis.contexts.get(ctx, {}).get(reg)
        if not bound:
            return None
        caller, actual, offset, parent = bound
        return _string_key(analysis, analysis.p.methods[caller], actual, offset,
                           parent, seen | {state})
    if instruction.op.startswith('const-string'):
        return str(instruction.literal)
    if instruction.op.startswith('move') and not instruction.op.startswith('move-result'):
        return _string_key(analysis, method, instruction.regs[1], instruction.offset,
                           ctx, seen | {state})
    return None


def _unique(origins):
    return bool(origins) and all(o.kind == 'allocation' for o in origins) and len({o.key for o in origins}) == 1


def _framework(analysis, concrete, name, desc):
    target = analysis.p.resolve(concrete, name, desc)
    return target is None or target.owner in OWNERS


def result(analysis, method, call, mode, ctx, depth):
    owner, name, desc = split_ref(call.ref)
    if owner not in OWNERS or (name, desc) != ('get', GET):
        return None
    actual = analysis.actuals(call)
    where = analysis.site(method.ref, call.offset)
    if len(actual) != 2 or call.op.startswith('invoke-static'):
        return ()
    bases = analysis.trace(method.ref, actual[0], call.offset, 'object', ctx, depth)
    if not _unique(bases):
        analysis.note('map_receiver_unresolved', where)
        return ()
    base = bases[0]
    concrete = allocation_type(analysis, base)
    if concrete not in IMPLEMENTATIONS or not _framework(analysis, concrete, name, desc):
        analysis.note('map_implementation_unresolved', where)
        return ()
    location = analysis.allocation_contexts.get(base.key)
    if location != (method.ref, ctx):
        analysis.note('map_nonlocal_state_unresolved', where)
        return ()
    key = _string_key(analysis, method, actual[1], call.offset, ctx)
    if key is None:
        analysis.note('map_key_unresolved', where)
        return ()
    prior = [i for i in method.instructions if i.offset < call.offset]
    if method.has_exceptions or any(i.op.startswith(('if-', 'goto', 'throw'))
            or i.op in ('packed-switch', 'sparse-switch') for i in prior):
        analysis.note('map_control_flow_unresolved', where)
        return ()
    if len(prior) > 512:
        analysis.note('map_local_instruction_limit', where)
        return ()
    writers = []
    initialized = False
    for previous in prior:
        if not analysis.allowed(depth):
            return ()
        # Once the container escapes through a field/array, another unknown
        # method can mutate its entries. Do not pretend its state is local.
        if previous.op.startswith(('iput', 'sput', 'aput')) and previous.regs:
            stored = analysis.trace(method.ref, previous.regs[0], previous.offset,
                                    'object', ctx, depth)
            if any(o.key == base.key for o in stored):
                analysis.note('map_escape_unresolved', analysis.site(method.ref, previous.offset))
                return ()
        if not previous.op.startswith('invoke-') or not previous.ref:
            continue
        po, pn, pd = split_ref(previous.ref)
        arguments = analysis.actuals(previous)
        aliases = []
        for index, reg in enumerate(arguments):
            # A new local map cannot alias a parameter or field unless it has
            # escaped. Exact traces here also catch move/check-cast aliases.
            operands = analysis.trace(method.ref, reg, previous.offset, 'object', ctx, depth)
            if any(o.key == base.key for o in operands):
                if not _unique(operands):
                    analysis.note('map_receiver_unresolved', analysis.site(method.ref, previous.offset))
                    return ()
                aliases.append(index)
        if not aliases:
            continue
        if aliases != [0] or previous.op.startswith('invoke-static') or po not in OWNERS:
            analysis.note('map_escape_unresolved', analysis.site(method.ref, previous.offset))
            return ()
        if pn == '<init>' and po == concrete and pd in EMPTY_CONSTRUCTORS:
            initialized = True
            continue
        if not initialized or not _framework(analysis, concrete, pn, pd):
            analysis.note('map_implementation_unresolved', analysis.site(method.ref, previous.offset))
            return ()
        if (pn, pd) in READS:
            continue
        if (pn, pd) not in MUTATIONS:
            analysis.note('map_mutation_unresolved', analysis.site(method.ref, previous.offset))
            return ()
        if pn == 'clear':
            writers.append((previous, None, 'clear'))
            continue
        written_key = _string_key(analysis, method, arguments[1], previous.offset, ctx)
        if written_key is None:
            # Even an apparently unrelated unknown key may overwrite this one.
            analysis.note('map_key_unresolved', analysis.site(method.ref, previous.offset))
            return ()
        if written_key == key:
            writers.append((previous, arguments[2] if pn == 'put' else None, pn))
    if not initialized:
        analysis.note('map_initialization_unresolved', where)
        return ()
    if not writers:
        return ()
    writer, value, action = writers[-1]
    if action != 'put':
        return ()
    from .demand import compatible
    out = []
    for origin in analysis.trace(method.ref, value, writer.offset, mode, ctx, depth):
        for container in bases:
            if compatible(origin, container):
                out.append(replace(origin, guards=origin.guards | container.guards,
                    callback_instances=origin.callback_instances | container.callback_instances,
                    path=origin.path + ('map_same_allocation:' + container.key,
                        'map_put_key:' + key + ':' + analysis.site(method.ref, writer.offset),
                        'map_get_key:' + key + ':' + where)))
    return tuple(out)
