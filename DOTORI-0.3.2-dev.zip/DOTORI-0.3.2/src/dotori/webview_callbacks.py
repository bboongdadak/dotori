"""Registration-backed framework inputs for WebViewClient callbacks.

A callback name or class alone is not a source.  Each framework-dispatched
argument is tied to the concrete client passed to setWebViewClient and that
call's WebView receiver.  This is an abstract registration relation, not proof
that a particular navigation occurred or was controlled by an OS Intent.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

from .model import split_ref


WEBVIEW = 'Landroid/webkit/WebView;'
CLIENT = 'Landroid/webkit/WebViewClient;'
REQUEST = 'Landroid/webkit/WebResourceRequest;'
STRING = 'Ljava/lang/String;'

# Exact Android signatures, with the URL/request formal index (including this).
# Extra callback parameters, such as Bitmap and error descriptions, are not
# silently labeled as URL inputs.
CALLBACKS = {
    ('shouldOverrideUrlLoading', f'({WEBVIEW}{STRING})Z'): (2, STRING),
    ('shouldOverrideUrlLoading', f'({WEBVIEW}{REQUEST})Z'): (2, REQUEST),
    ('shouldInterceptRequest', f'({WEBVIEW}{STRING})Landroid/webkit/WebResourceResponse;'): (2, STRING),
    ('shouldInterceptRequest', f'({WEBVIEW}{REQUEST})Landroid/webkit/WebResourceResponse;'): (2, REQUEST),
    ('onPageStarted', f'({WEBVIEW}{STRING}Landroid/graphics/Bitmap;)V'): (2, STRING),
    ('onPageFinished', f'({WEBVIEW}{STRING})V'): (2, STRING),
    ('onPageCommitVisible', f'({WEBVIEW}{STRING})V'): (2, STRING),
    ('onLoadResource', f'({WEBVIEW}{STRING})V'): (2, STRING),
    ('doUpdateVisitedHistory', f'({WEBVIEW}{STRING}Z)V'): (2, STRING),
    ('onReceivedError', f'({WEBVIEW}I{STRING}{STRING})V'): (4, STRING),
    ('onReceivedError', f'({WEBVIEW}{REQUEST}Landroid/webkit/WebResourceError;)V'): (2, REQUEST),
    ('onReceivedHttpError', f'({WEBVIEW}{REQUEST}Landroid/webkit/WebResourceResponse;)V'): (2, REQUEST),
}


@dataclass(frozen=True)
class Registration:
    client: object
    webview: object
    site: str
    token: str


def callback_spec(analysis, method):
    if 'static' in method.access.split() or 'public' not in method.access.split():
        return None
    if not analysis.p.is_subtype(method.owner, CLIENT):
        return None
    return CALLBACKS.get((method.name, method.descriptor))


def allocation_type(analysis, origin):
    """Recover allocation type even when a check-cast erased its narrow type."""
    if origin.kind != 'allocation':
        return ''
    for step in origin.path:
        if '@' not in step:
            continue
        ref, offset = step.rsplit('@', 1)
        try:
            offset = int(offset, 16)
        except ValueError:
            continue
        instruction = analysis.instruction(ref, offset)
        if instruction and instruction.op == 'new-instance':
            return str(instruction.literal)
    return ''


def constructor_receiver(analysis, method, reg, before, origins, ctx=0):
    """A relational placeholder for one unbound custom-WebView constructor.

    This only identifies two direct uses of the constructor's same p0.  It
    cannot alias arbitrary methods, fields, other constructor overloads, or
    separately recovered real allocations.  Framework/XML construction is an
    explicit remaining assumption, never represented as an allocation proof.
    """
    if (method.name != '<init>' or not analysis.p.is_subtype(method.owner, WEBVIEW)
            or len(origins) != 1 or origins[0].kind != 'relative_this'
            or origins[0].typ != method.owner or origins[0].guards
            or not analysis.is_local_this(method, reg, before)):
        return origins
    origin = origins[0]
    token = analysis.context_tokens.get(ctx, '')
    key = 'constructor_receiver:' + method.ref + (':call_context:' + token if token else '')
    return (replace(origin, kind='constructor_receiver', key=key,
        path=origin.path + ('symbolic_constructor_this:' + method.ref,
                            analysis.site(method.ref, before) + ':direct_constructor_receiver')),)


def registrations(analysis, method, depth):
    """Resolve indexed registration operands; never join by class name alone."""
    cache_key = ('webview_client_registrations', method.ref)
    if cache_key in analysis.memo:
        return analysis.memo[cache_key]
    if cache_key in analysis.active:
        return ()
    analysis.active.add(cache_key)
    found = []
    try:
        refs = analysis.c.call_signatures.get(('setWebViewClient', f'({CLIENT})V'), ())
        sites = [site for ref in refs if analysis.p.is_subtype(split_ref(ref)[0], WEBVIEW)
                 for site in analysis.c.callers_of(ref)]
        if len(sites) > 128:
            analysis.note('callback_registration_fanout_limit', method.ref)
        for site in sites[:128]:
            if not analysis.allowed(depth):
                break
            caller = analysis.p.methods.get(site.method)
            call = analysis.instruction(site.method, site.offset)
            if not caller or not call or call.op.startswith('invoke-static'):
                continue
            actual = analysis.actuals(call)
            if len(actual) != 2:
                continue
            # Skip cheaply known unrelated client classes before opening slices.
            types = analysis.known_receiver_types(caller, actual[1], call.offset, 0)
            if types and not any((target := analysis.p.resolve(typ, method.name, method.descriptor))
                                 and target.ref == method.ref for typ in types):
                continue
            clients = analysis.trace(site.method, actual[1], site.offset, 'object', 0, depth)
            if not clients or any(c.kind!='allocation' for c in clients) or len({c.key for c in clients})!=1:
                analysis.note('callback_alias_unresolved', analysis.site(site.method, site.offset))
                continue
            client = clients[0]
            concrete = allocation_type(analysis, client)
            target = analysis.p.resolve(concrete, method.name, method.descriptor) if concrete else None
            if not analysis.p.is_subtype(concrete, CLIENT) or not target or target.ref != method.ref:
                continue
            # An unrelated earlier branch does not make registration of this
            # newly created client conditional. Require an uninterrupted local
            # allocation-to-registration segment; guards on the chosen view are
            # retained below. A branch *after* allocation remains unsupported.
            allocations=[i.offset for i in caller.instructions if i.op=='new-instance'
                         and analysis.site(caller.ref,i.offset) in client.path]
            if not allocations:
                analysis.note('callback_registration_context_unresolved',analysis.site(site.method,site.offset));continue
            created=allocations[-1]
            segment=[i for i in caller.instructions if created<i.offset<call.offset]
            if caller.has_exceptions or any(i.op.startswith(('if-', 'goto', 'throw'))
                    or i.op in ('packed-switch', 'sparse-switch') for i in segment):
                analysis.note('conditional_callback_registration', analysis.site(site.method, site.offset))
                continue
            if not analysis.reachable(site.method, site.offset):
                continue
            views = analysis.trace(site.method, actual[0], site.offset, 'object', 0, depth)
            views = constructor_receiver(analysis, caller, actual[0], site.offset, views)
            # A null receiver cannot perform registration. Discard only that
            # impossible invocation alternative, never another unknown object.
            if any(v.kind=='constant' and v.value=='0' for v in views):
                analysis.note('callback_null_receiver_alternative',analysis.site(site.method,site.offset))
            views=tuple(v for v in views if not (v.kind=='constant' and v.value=='0'))
            if (not views or any(v.kind not in ('allocation','view','constructor_receiver') for v in views)
                    or len({v.key for v in views})!=1):
                analysis.note('callback_webview_alias_unresolved', analysis.site(site.method, site.offset))
                continue
            from .demand import compatible
            for client in clients:
                for view in views:
                    if not compatible(client,view):continue
                    if view.kind=='allocation' and not analysis.p.is_subtype(allocation_type(analysis,view),WEBVIEW):
                        analysis.note('callback_webview_alias_unresolved',analysis.site(site.method,site.offset));continue
                    replaced=False
                    for later in caller.instructions:
                        if later.offset<=call.offset or not later.ref:continue
                        lo,ln,ld=split_ref(later.ref) if '(' in later.ref else ('','','')
                        if ln!='setWebViewClient' or ld!=f'({CLIENT})V' or not analysis.p.is_subtype(lo,WEBVIEW):continue
                        lr=analysis.actuals(later)
                        if not lr:continue
                        targets=analysis.trace(caller.ref,lr[0],later.offset,'object',0,depth)
                        if any(t.key==view.key and compatible(t,view) for t in targets):
                            replaced=True;analysis.note('callback_replacement_unresolved',analysis.site(caller.ref,later.offset));break
                    if replaced:continue
                    guards=client.guards|view.guards
                    if guards:analysis.note('callback_registration_guarded',analysis.site(site.method,site.offset))
                    where=analysis.site(site.method,site.offset)
                    token='webview_client:'+client.key+':registration:'+where+':view:'+view.key
                    found.append(Registration(replace(client,typ=concrete,guards=guards),
                                              replace(view,guards=guards),where,token))
    finally:
        analysis.active.remove(cache_key)
    result = tuple(found)
    analysis.memo[cache_key] = result
    return result


def parameter(analysis, method, index, mode, depth):
    """Return None when inapplicable, () when recognized but unverified."""
    spec = callback_spec(analysis, method)
    if spec is None:
        return None
    source_index, source_type = spec
    if index not in (0, 1, source_index):
        analysis.note('unmodeled_webview_callback_parameter', method.ref + ':' + str(index))
        return ()
    registered = registrations(analysis, method, depth)
    if not registered:
        analysis.note('callback_registration_unresolved', method.ref)
        return ()
    from .demand import Origin
    result = []
    for registration in registered:
        proof = ('callback_registered:' + registration.site,
                 'callback_dispatch:' + method.ref)
        instances = frozenset((registration.token,))
        if index in (0, 1):
            base = registration.client if index == 0 else registration.webview
            result.append(replace(base, callback_instances=instances,
                                  path=base.path + proof + ('callback_parameter:' + str(index),)))
        elif mode == 'value':
            key = 'web_navigation:' + method.ref + ':' + str(index) + ':' + registration.token
            result.append(Origin('web_navigation', key, source_type,
                entry=method.ref, path=registration.client.path + proof +
                (method.ref + ':web_navigation_parameter:' + str(index),),
                callback_instances=instances,guards=registration.client.guards|registration.webview.guards))
    return tuple(result)


def result(analysis, method, call, mode, ctx, depth):
    """The request URL accessor preserves only a verified navigation origin."""
    if (call.ref != REQUEST + '->getUrl()Landroid/net/Uri;'
            or call.op.startswith('invoke-static') or not call.regs):
        return None
    origins = analysis.trace(method.ref, call.regs[0], call.offset, 'value', ctx, depth)
    verified = tuple(replace(origin, typ='Landroid/net/Uri;').step(
        analysis.site(method.ref, call.offset) + ':web_resource_request_url')
        for origin in origins if origin.kind == 'web_navigation' and origin.typ == REQUEST)
    # An application-owned implementation may have an ordinary method body;
    # leave that path to normal interprocedural slicing rather than suppress it.
    return verified or None
