"""Exact Android inflation identity and receiver-owned View tag slots.

A layout ID identifies the resource, not the allocated view.  Inflation keys
therefore include the callsite/context. Tags are separate default/keyed slots;
values only move between receivers with the same established object identity.
Independent lifecycle writes keep an explicit ordering assumption.
"""
from dataclasses import replace

from .model import split_ref
from .state_summaries import _reader_frames, _writes

VIEW = 'Landroid/view/View;'
WEBVIEW = 'Landroid/webkit/WebView;'
INFLATER = 'Landroid/view/LayoutInflater;'
OBJECT = 'Ljava/lang/Object;'
TAG_GET = {'()' + OBJECT: None, '(I)' + OBJECT: 1}
TAG_SET = {'(' + OBJECT + ')V': None, '(I' + OBJECT + ')V': 1}


def _view_type(analysis, typ):
    # Android framework parents need not be defined by the application's DEX.
    return typ in (VIEW, WEBVIEW) or analysis.p.is_subtype(typ, VIEW) or analysis.p.is_subtype(typ, WEBVIEW)


def _allocated_type(analysis, origin):
    """Use the allocation instruction, not a later check-cast's type."""
    if origin.kind != 'allocation':
        return origin.typ if origin.kind in ('view', 'constructor_receiver') else ''
    ref, sep, offset = origin.key.split(':call_context:', 1)[0].rpartition('@')
    try:
        instruction = analysis.instruction(ref, int(offset, 16)) if sep else None
    except ValueError:
        instruction = None
    return str(instruction.literal) if instruction and instruction.op == 'new-instance' else ''


def _custom_implementation(analysis, method, call, ctx, origins=()):
    """A DEX implementation must not be replaced by a framework summary.

    Super calls deliberately resolve against their declared owner. Virtual
    calls also consider concrete allocation types, including through casts.
    """
    owner, name, desc = split_ref(call.ref)
    types = (owner,)
    if call.op.startswith(('invoke-virtual', 'invoke-interface')):
        actual = analysis.actuals(call)
        if actual:
            types += analysis.known_receiver_types(method, actual[0], call.offset, ctx)
        types += tuple(_allocated_type(analysis, origin) for origin in origins)
    return any(analysis.p.resolve(typ, name, desc) is not None for typ in types if typ)


def _views(analysis, origins):
    out = []
    for origin in origins:
        if origin.kind == 'view' or origin.kind == 'constructor_receiver' and _view_type(analysis, origin.typ):
            out.append(origin)
        elif origin.kind == 'allocation':
            if _view_type(analysis, _allocated_type(analysis, origin)):
                out.append(origin)
    return tuple(out)


def _guard_compatible(left, right):
    # The exact shared slot can transfer between different callback invocations.
    # Keep both tokens in the result, but compare control-flow guards here.
    from .demand import compatible
    return compatible(replace(left, callback_instances=frozenset()),
                      replace(right, callback_instances=frozenset()))


def _scalar(analysis, method, reg, offset, ctx, depth):
    values = analysis.trace(method.ref, reg, offset, 'value', ctx, depth)
    if len(values) == 1 and values[0].kind == 'constant':
        return values[0]
    return None


def _inflate(analysis, method, call, actual, desc, ctx, depth):
    from .demand import Origin, compatible
    where = analysis.site(method.ref, call.offset)
    if desc not in ('(ILandroid/view/ViewGroup;)Landroid/view/View;',
                    '(ILandroid/view/ViewGroup;Z)Landroid/view/View;') or len(actual) not in (3, 4):
        return None
    layout = _scalar(analysis, method, actual[1], call.offset, ctx, depth)
    root = analysis.trace(method.ref, actual[2], call.offset, 'object', ctx, depth)
    null_root = len(root) == 1 and root[0].kind == 'constant' and root[0].value == '0'
    attach = (_scalar(analysis, method, actual[3], call.offset, ctx, depth)
              if len(actual) == 4 else None)
    detached = null_root or attach is not None and attach.value == '0'
    attached = not null_root and (len(actual) == 3 or attach is not None and attach.value == '1')
    if not layout or not layout.value.isdecimal() or int(layout.value) <= 0:
        analysis.note('inflated_view_resource_unresolved', where)
        return ()
    if detached:
        if any(i.target is not None and i.op.startswith(('goto', 'if-'))
               and i.target <= call.offset <= i.offset for i in method.instructions):
            analysis.note('loop_allocation_unresolved', where)
            return ()
        key = 'inflated:' + analysis.allocation_key(method, call, ctx) + ':layout:' + layout.value
        out = []
        for parent in root or (None,):
            operands = (layout,) + ((parent,) if parent else ()) + ((attach,) if attach else ())
            if not all(compatible(a, b) for a in operands for b in operands):
                continue
            out.append(Origin('view', key, VIEW,
                path=layout.path + (where + ':inflated_layout:' + layout.value,),
                guards=frozenset().union(*(a.guards for a in operands)),
                callback_instances=frozenset().union(*(a.callback_instances for a in operands))))
        return tuple(out)
    if attached:
        known = _views(analysis, root)
        if len(known) == len(root) == 1:
            operands = (known[0], layout) + ((attach,) if attach else ())
            if not all(compatible(a, b) for a in operands for b in operands):
                return ()
            return (replace(known[0],
                guards=frozenset().union(*(a.guards for a in operands)),
                callback_instances=frozenset().union(*(a.callback_instances for a in operands)))
                .step(where + ':inflation_returns_parent'),)
    analysis.note('inflated_view_root_unresolved', where)
    return ()


def result(analysis, method, call, mode, ctx, depth):
    if not call.ref or '(' not in call.ref or call.op.startswith('invoke-static'):
        return None
    owner, name, desc = split_ref(call.ref)
    actual = analysis.actuals(call)
    if owner == INFLATER and name == 'inflate':
        if _custom_implementation(analysis, method, call, ctx):
            return None
        return _inflate(analysis, method, call, actual, desc, ctx, depth)
    if not (name == 'getTag' and desc in TAG_GET and actual and _view_type(analysis, owner)):
        return None
    if _custom_implementation(analysis, method, call, ctx):
        return None
    where = analysis.site(method.ref, call.offset)
    origins = analysis.trace(method.ref, actual[0], call.offset, 'object', ctx, depth)
    if _custom_implementation(analysis, method, call, ctx, origins):
        return None
    if any(a.kind == 'constant' and a.value == '0' for a in origins):
        analysis.note('view_tag_null_receiver_alternative', where)
    origins = tuple(a for a in origins if not (a.kind == 'constant' and a.value == '0'))
    bases = _views(analysis, origins)
    if not bases or len(bases) != len(origins):
        analysis.note('view_tag_receiver_unresolved', where)
    if not bases:
        return ()
    keyed = TAG_GET[desc] is not None
    key = _scalar(analysis, method, actual[1], call.offset, ctx, depth) if keyed else None
    if keyed and (key is None or not key.value.lstrip('-').isdecimal()):
        analysis.note('view_tag_key_unresolved', where)
        return ()
    frames = _reader_frames(analysis, method, call.offset, ctx)
    setter_desc = '(I' + OBJECT + ')V' if keyed else '(' + OBJECT + ')V'
    writes = _writes(analysis, frames, depth,
                     (('setTag', setter_desc, lambda typ: _view_type(analysis, typ)),))
    out = []
    for base in bases:
        if keyed and not _guard_compatible(base, key):
            continue
        candidates = []
        unknown = []
        for write in writes:
            event = next(((offset, frames[ref][0]) for ref, offset, context in reversed(write.events)
                          if ref in frames and context == frames[ref][1]), None)
            if event and event[0] >= event[1]:
                continue
            instruction = analysis.instruction(write.method, write.offset)
            operands = analysis.actuals(instruction)
            wm = analysis.p.methods[write.method]
            if keyed:
                written_key = _scalar(analysis, wm, operands[1], write.offset, write.context, depth)
                if written_key and written_key.value != key.value:
                    continue
            else:
                written_key = None
            previous = analysis.branch_query_limit
            share = max(16, min(512, (analysis.per_sink_limit - analysis.sink_queries) // max(2, len(writes) * 2)))
            analysis.branch_query_limit = min(previous if previous is not None else analysis.per_sink_limit,
                                              analysis.sink_queries + share)
            try:
                targets = analysis.trace(write.method, operands[0], write.offset, 'object', write.context, depth)
            finally:
                analysis.branch_query_limit = previous
            if _custom_implementation(analysis, wm, instruction, write.context, targets):
                continue
            if any(a.kind == 'constant' and a.value == '0' for a in targets):
                analysis.note('view_tag_null_receiver_alternative', analysis.site(write.method, write.offset))
            targets = tuple(a for a in targets if _guard_compatible(a, base)
                            and not (a.kind == 'constant' and a.value == '0'))
            known = _views(analysis, targets)
            matching = [a for a in known if a.key == base.key]
            if not matching:
                if not targets or len(known) != len(targets):
                    unknown.append(write)
                continue
            if len({a.key for a in known}) != 1 or len(known) != len(targets) or keyed and written_key is None:
                unknown.append(write)
                analysis.note('view_tag_writer_alias_unresolved', analysis.site(write.root, write.root_offset))
                continue
            operands = (base, matching[0]) + ((key, written_key) if keyed else ())
            if not all(_guard_compatible(a, b) for a in operands for b in operands):
                continue
            candidates.append((write, matching[0], written_key))
        if not candidates:
            analysis.note('view_tag_write_unresolved', where + ':' + base.key)
            continue
        groups = {}
        for candidate in candidates:
            w = candidate[0]
            groups.setdefault((w.root, w.root_context), []).append(candidate)
        selected = []
        for group in groups.values():
            latest = max(group, key=lambda item: item[0].order)
            write = latest[0]
            if any(u.root == write.root and u.root_context == write.root_context and u.order >= write.order
                   for u in unknown):
                analysis.note('view_tag_writer_alias_unresolved', where + ':' + base.key)
                continue
            if write.guarded and len(group) > 1:
                # A conditional last write does not definitely replace an
                # earlier one; do not pick either without a path-order proof.
                analysis.note('view_tag_write_order_unresolved', where + ':' + base.key)
                continue
            selected.append(latest)
        if unknown:
            analysis.note('view_tag_writer_alias_unresolved', where + ':' + base.key)
        for write, target, written_key in selected:
            if write.guarded:
                analysis.note('conditional_view_tag_write', analysis.site(write.root, write.root_offset))
            lifecycle = write.root not in frames
            if lifecycle:
                analysis.note('view_tag_lifecycle_order_unresolved', where + ':' + analysis.site(write.root, write.root_offset))
            if len(groups) > 1:
                analysis.note('view_tag_write_order_unresolved', where + ':' + base.key)
            instruction = analysis.instruction(write.method, write.offset)
            operands = analysis.actuals(instruction)
            values = analysis.trace(write.method, operands[-1], write.offset, mode, write.context, depth)
            if not values:
                analysis.note('view_tag_value_unresolved', analysis.site(write.method, write.offset))
            for value in values:
                relevant = (base, target) + ((key, written_key) if keyed else ())
                if not all(_guard_compatible(value, atom) for atom in relevant):
                    continue
                guards = value.guards
                callback_instances = value.callback_instances
                for atom in relevant:
                    guards |= atom.guards
                    callback_instances |= atom.callback_instances
                proof = ('view_tag_object:' + base.key,
                         'view_tag_slot:' + ('key:' + key.value if keyed else 'default'),
                         'view_tag_write:' + analysis.site(write.method, write.offset),
                         'view_tag_read:' + where)
                proof += tuple('view_tag_writer_call:' + s for s in write.chain)
                if lifecycle:
                    proof += ('view_tag_read_after_write_assumed',)
                out.append(replace(value, guards=guards,
                    callback_instances=callback_instances,
                    path=value.path + proof))
    return tuple(out)
