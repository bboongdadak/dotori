"""Compact DEX catalog and bounded on-demand IR.

Uses Androguard's instruction decoder, not its whole-DEX object graph. The
catalog scans instruction boundaries and stores packed caller/field-write
indices; full operand objects are built only when a trace requests a method.
The lazy/LRU design follows the supplied MIT-licensed UnIntent backend; this
implementation is independently adapted to DOTORI's smaller IR.
"""
from __future__ import annotations

from array import array
from collections import OrderedDict, defaultdict
from collections.abc import Sequence
from dataclasses import dataclass
import struct
import sys

from .model import Instruction, Method

API_NAMES = frozenset({'loadUrl','postUrl','loadData','loadDataWithBaseURL','evaluateJavascript',
                       'addJavascriptInterface','removeJavascriptInterface','setJavaScriptEnabled',
                       'addWebMessageListener'})


def uleb(data, offset):
    value=0
    for shift in range(0,35,7):
        b=data[offset];offset+=1;value|=(b&127)<<shift
        if b<128:return value,offset
    raise ValueError('Invalid ULEB128')


def sleb(data, offset):
    value=0
    for shift in range(0,35,7):
        byte=data[offset];offset+=1;value|=(byte&127)<<shift
        if byte<128:
            if byte&64:value-=1<<(shift+7)
            return value,offset
    raise ValueError('Invalid SLEB128')


class Packers(dict):
    def __missing__(self,key):
        value=struct.Struct('<'+key);self[key]=value;return value


class MethodReference:
    def __init__(self, dex, index):self.dex,self.index=dex,index
    def get_class_name(self):return self.dex.method_parts(self.index)[0]
    def get_name(self):return self.dex.method_parts(self.index)[1]
    def get_descriptor(self):return self.dex.method_parts(self.index)[2]


@dataclass(frozen=True,slots=True)
class Site:
    method: str
    offset: int
    target: str
    opcode: str

    def as_dict(self):
        return {'method':self.method,'offset':self.offset,'target':self.target,'opcode':self.opcode}


FLAGS={1:'public',2:'private',4:'protected',8:'static',16:'final',32:'synchronized',64:'bridge',
       128:'varargs',256:'native',512:'interface',1024:'abstract',2048:'strictfp',4096:'synthetic',
       65536:'constructor',131072:'declared-synchronized'}


class CompactDex:
    def __init__(self,name,data):
        from mutf8 import decode_modified_utf8
        self.name,self.data=name,data
        if data[:4]!=b'dex\n' or data[7]!=0 or data[4:7] not in (b'035',b'037',b'038',b'039',b'040'):
            raise ValueError(f'{name}: unsupported DEX version/container')
        if self.uint(40)!=0x12345678:raise ValueError('Only little-endian DEX is supported')
        if self.uint(32)!=len(data) or self.uint(36)!=112:raise ValueError('Invalid DEX header size')
        self.strings=[]
        for index in range(self.uint(56)):
            off=self.uint(self.uint(60)+4*index);_,off=uleb(data,off)
            end=data.index(b'\0',off)
            self.strings.append(sys.intern(decode_modified_utf8(data[off:end])))
        self.types=[self.strings[self.uint(self.uint(68)+4*i)] for i in range(self.uint(64))]
        self.protos=[]
        for i in range(self.uint(72)):
            off=self.uint(76)+12*i;ret=self.types[self.uint(off+4)];poff=self.uint(off+8)
            ps='' if not poff else ''.join(self.types[self.ushort(poff+4+2*j)] for j in range(self.uint(poff)))
            self.protos.append(sys.intern('('+ps+')'+ret))
        self.fields=[]
        for i in range(self.uint(80)):
            off=self.uint(84)+8*i;c,t,n=struct.unpack_from('<HHI',data,off)
            self.fields.append((self.types[c],self.types[t],self.strings[n]))
        self.method_ids=[];self.refs=[];self.ref_ids={}
        for i in range(self.uint(88)):
            c,p,n=struct.unpack_from('<HHI',data,self.uint(92)+8*i)
            self.method_ids.append((c,p,n))
            ref=sys.intern(self.types[c]+'->'+self.strings[n]+self.protos[p])
            self.refs.append(ref);self.ref_ids[ref]=i
        self.definitions={};self.supers={};self.interfaces={};self.annotations={}
        for i in range(self.uint(96)):
            c,flags,s,interfaces,source,annotations,classdata,values=struct.unpack_from('<8I',data,self.uint(100)+32*i)
            self.supers[self.types[c]]=self.types[s] if s!=0xffffffff else ''
            self.interfaces[self.types[c]]=tuple(self.types[self.ushort(interfaces+4+2*j)] for j in range(self.uint(interfaces))) if interfaces else ()
            if annotations:
                _,fields,methods,_=struct.unpack_from('<4I',data,annotations)
                moff=annotations+16+8*fields
                for j in range(methods):
                    mid,aset=struct.unpack_from('<2I',data,moff+8*j)
                    names=[]
                    for k in range(self.uint(aset)):
                        annotation=self.uint(aset+4+4*k)
                        typ,_=uleb(data,annotation+1);names.append(self.types[typ])
                    self.annotations[mid]=tuple(names)
            if not classdata:continue
            counts=[]
            for _ in range(4):
                count,classdata=uleb(data,classdata);counts.append(count)
            for _ in range(counts[0]+counts[1]):
                _,classdata=uleb(data,classdata);_,classdata=uleb(data,classdata)
            for count in counts[2:]:
                mid=0
                for _ in range(count):
                    delta,classdata=uleb(data,classdata);mid+=delta
                    access,classdata=uleb(data,classdata);code,classdata=uleb(data,classdata)
                    self.definitions[mid]=(access,code)
        self.packer=Packers();self.callers=defaultdict(lambda:array('I'));self.writers=defaultdict(lambda:array('I'))
        self.inventory=[];self.scan_diagnostics=[];self.opcodes_scanned=0;self.class_literals=defaultdict(lambda:array('I'))
        self._scan()

    def uint(self,off):return struct.unpack_from('<I',self.data,off)[0]
    def ushort(self,off):return struct.unpack_from('<H',self.data,off)[0]
    def get_odex_format(self):return False
    def get_method_ref(self,index):return MethodReference(self,index)
    def get_string(self,index):return self.strings[index]
    def get_type(self,index):return self.types[index]
    def get_field(self,index):return self.fields[index]
    def method_parts(self,index):
        c,p,n=self.method_ids[index];return self.types[c],self.strings[n],self.protos[p]
    def field_ref(self,index):
        c,t,n=self.fields[index];return sys.intern(c+'->'+n+t)

    def _scan(self):
        from androguard.core.dex import DALVIK_OPCODES_FORMAT
        lengths={op:cls.length for op,(cls,_) in DALVIK_OPCODES_FORMAT.items() if op<256}
        for caller,(_,code) in self.definitions.items():
            if not code:continue
            cursor=code+16;end=cursor+2*self.uint(code+12)
            if end>len(self.data):raise ValueError('Code item extends beyond DEX')
            while cursor<end:
                op=self.data[cursor];high=self.data[cursor+1];offset=cursor-code-16
                self.opcodes_scanned+=1
                if op==0 and high:
                    count=self.ushort(cursor+2)
                    if high==1:length=8+4*count
                    elif high==2:length=4+8*count
                    elif high==3:
                        length=8+count*self.uint(cursor+4);length+=(length&1)
                    else:raise ValueError('Unknown DEX payload')
                else:length=lengths.get(op,0)
                if not length or cursor+length>end:
                    self.scan_diagnostics.append({'code':'catalog_decode_gap','detail':self.refs[caller]+'@'+hex(offset)})
                    break
                if 0x6e<=op<=0x72 or 0x74<=op<=0x78:
                    target=self.ushort(cursor+2)
                    self.callers[target].extend((caller,offset))
                    if self.method_parts(target)[1] in API_NAMES:
                        self.inventory.append(Site(self.refs[caller],offset,self.refs[target],DALVIK_OPCODES_FORMAT[op][1][0]))
                elif 0x59<=op<=0x5f or 0x67<=op<=0x6d:
                    self.writers[self.ushort(cursor+2)].extend((caller,offset))
                elif op==0x1c:
                    self.class_literals[self.ushort(cursor+2)].extend((caller,offset))
                elif op in (0xfa,0xfb,0xfc,0xfd):
                    self.scan_diagnostics.append({'code':'dynamic_invoke_unresolved','detail':self.refs[caller]+'@'+hex(offset)})
                cursor+=length

    def exception_handlers(self,code):
        """Decode DEX code_item try ranges in byte offsets, not code units."""
        if not code:return ()
        _,_,_,count,_,size=struct.unpack_from('<4H2I',self.data,code)
        if not count:return ()
        table=code+16+2*size+(2 if size%2 else 0)
        handlers=table+8*count
        out=[]
        for n in range(count):
            start,length,relative=struct.unpack_from('<IHH',self.data,table+8*n)
            num,cursor=sleb(self.data,handlers+relative)
            for _ in range(abs(num)):
                typ,cursor=uleb(self.data,cursor);address,cursor=uleb(self.data,cursor)
                if start+length>size or address>=size:raise ValueError('Invalid DEX exception range')
                out.append((2*start,2*(start+length),2*address,self.types[typ]))
            if num<=0:
                address,cursor=uleb(self.data,cursor)
                if start+length>size or address>=size:raise ValueError('Invalid DEX catch-all range')
                out.append((2*start,2*(start+length),2*address,'*'))
        return tuple(out)

    def method(self,index):
        from androguard.core.dex import LinearSweepAlgorithm
        access,code=self.definitions[index]
        flags=' '.join(name for bit,name in FLAGS.items() if access&bit)
        if not code:return Method(self.refs[index],flags,annotations=self.annotations.get(index,()))
        regs,ins,outs,tries,debug,size=struct.unpack_from('<4H2I',self.data,code)
        data=self.data[code+16:code+16+2*size]
        decoded={};offset=0
        for item in LinearSweepAlgorithm.get_instructions(self,size,data,0):
            decoded[offset]=item;offset+=item.get_length()
        if offset!=2*size:raise ValueError('Incomplete method decoding')
        result=[]
        for off,item in decoded.items():
            op=item.get_name();registers=[];reference='';literal=None;target=None
            for operand in item.get_operands():
                kind=getattr(operand[0],'name',str(operand[0]))
                if kind=='REGISTER':registers.append(int(operand[1]))
                elif kind=='LITERAL':literal=int(operand[1])
                elif kind=='OFFSET':target=off+2*int(operand[1])
                if len(operand)>=3 and isinstance(operand[2],str):
                    rendered=operand[2]
                    if '->' in rendered:reference=''.join(rendered.split())
                    elif op.startswith(('const-string','const-class','new-instance','new-array','check-cast')):literal=rendered
            cases=()
            if op in ('packed-switch','sparse-switch'):
                payload=decoded.get(target)
                if payload is not None and hasattr(payload,'get_targets'):
                    cases=tuple((int(k),off+2*int(v)) for k,v in zip(payload.get_keys(),payload.get_targets()))
            result.append(Instruction(off,op,tuple(registers),reference,literal,target,cases,item.get_output()))
        return Method(self.refs[index],flags,regs,ins,result,self.annotations.get(index,()),bool(tries),self.exception_handlers(code))


class LazyBody(Sequence):
    __slots__=('catalog','ref')
    def __init__(self,catalog,ref):self.catalog,self.ref=catalog,ref
    def __len__(self):return len(self.catalog.body(self.ref).instructions)
    def __getitem__(self,key):return self.catalog.body(self.ref).instructions[key]
    def __iter__(self):return iter(self.catalog.body(self.ref).instructions)


class Catalog:
    def __init__(self,dex_files,max_cache=256):
        self.dex_files=dex_files;self.max_cache=max_cache;self.cache=OrderedDict();self.location={}
        self.methods={};self.supers={};self.interfaces={};self.inventory=[];self.diagnostics=[]
        self.decoded=0;self.cache_peak=0
        for dex in dex_files:
            self.supers.update(dex.supers);self.interfaces.update(dex.interfaces)
            self.inventory.extend(dex.inventory);self.diagnostics.extend(dex.scan_diagnostics)
            for idx,(access,code) in dex.definitions.items():
                ref=dex.refs[idx]
                if ref in self.location:self.diagnostics.append({'code':'duplicate_method','detail':ref})
                self.location[ref]=(dex,idx)
                regs=ins=tries=0
                if code:regs,ins,_,tries=struct.unpack_from('<4H',dex.data,code)
                m=Method(ref,' '.join(name for bit,name in FLAGS.items() if access&bit),regs,ins,
                         annotations=dex.annotations.get(idx,()),has_exceptions=bool(tries),
                         exception_handlers=dex.exception_handlers(code))
                m.instructions=LazyBody(self,ref) if code else []
                self.methods[ref]=m
        self.by_signature=defaultdict(list)
        self.by_class=defaultdict(list)
        self.call_signatures=defaultdict(set)
        self.field_writers=defaultdict(list)
        self.field_types={}
        for dex in dex_files:
            for idx in dex.callers:
                owner,name,desc=dex.method_parts(idx)
                self.call_signatures[name,desc].add(dex.refs[idx])
            for idx,entries in dex.writers.items():
                key=dex.field_ref(idx);self.field_types[key]=dex.fields[idx][1]
                self.field_writers[key].extend((dex.refs[entries[i]],entries[i+1]) for i in range(0,len(entries),2))
        for ref,m in self.methods.items():
            self.by_signature[(m.name,m.descriptor)].append(ref)
            self.by_class[m.owner].append(ref)

    def literal_users(self,typ):
        result=[]
        for dex in self.dex_files:
            if typ not in dex.types:continue
            entries=dex.class_literals.get(dex.types.index(typ),())
            result.extend((dex.refs[entries[i]],entries[i+1]) for i in range(0,len(entries),2))
        return result

    def body(self,ref):
        if ref in self.cache:
            self.cache.move_to_end(ref);return self.cache[ref]
        dex,index=self.location[ref];method=dex.method(index);self.decoded+=1
        self.cache[ref]=method
        if len(self.cache)>self.max_cache:self.cache.popitem(last=False)
        self.cache_peak=max(self.cache_peak,len(self.cache));return method

    def callers_of(self,ref):
        result=[]
        for dex in self.dex_files:
            idx=dex.ref_ids.get(ref)
            if idx is None:continue
            entries=dex.callers.get(idx,())
            result.extend(Site(dex.refs[entries[i]],entries[i+1],ref,'direct_reference') for i in range(0,len(entries),2))
        return result

    def writers_of(self,field):
        return self.field_writers.get(field,())
