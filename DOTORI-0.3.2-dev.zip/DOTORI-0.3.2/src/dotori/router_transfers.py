"""Exact Fragment argument transfers, with deferred, key-sensitive Intent extras.

A Fragment class or a route/API occurrence is not a transfer.  Reads must match
one concrete Fragment allocation and one setArguments operand tuple.  ARouter's
reflective route registration and interceptor machinery are deliberately not
summarized here: an incomplete route witness must not become an ICC delivery.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

from .model import split_ref
from .state_summaries import _formal, _reader_frames
from .webview_callbacks import allocation_type

BUNDLE = 'Landroid/os/Bundle;'
BASE_BUNDLE = 'Landroid/os/BaseBundle;'
INTENT = 'Landroid/content/Intent;'
FRAGMENTS = ('Landroid/app/Fragment;', 'Landroidx/fragment/app/Fragment;',
             'Landroid/support/v4/app/Fragment;')
STRING = 'Ljava/lang/String;'
SET = '(' + BUNDLE + ')V'
GET = '()' + BUNDLE


@dataclass(frozen=True)
class Write:
    method: str
    offset: int
    context: int
    fragment: int
    bundle: int
    root: str
    root_offset: int
    chain: tuple[str, ...]
    guarded: bool


def framework_call(analysis, ref, name, descriptor):
    owner, actual, desc = split_ref(ref)
    if actual != name or desc != descriptor:
        return False
    if not any(analysis.p.is_subtype(owner, base) for base in FRAGMENTS):
        return False
    target = analysis.p.resolve(owner, name, descriptor)
    return target is None or target.owner in FRAGMENTS


def _single_allocation(origins):
    return bool(origins) and all(o.kind == 'allocation' for o in origins) and len({o.key for o in origins}) == 1


def _straight(method, before, after=-1):
    return not method.has_exceptions and not any(
        i.op.startswith(('if-', 'goto', 'throw')) or i.op in ('packed-switch', 'sparse-switch')
        for i in method.instructions if after < i.offset < before)


def _writes(analysis, reader, offset, ctx, depth):
    """Replay setter helpers using the same caller tuple, never zipped origins."""
    frames = _reader_frames(analysis, reader, offset, ctx)
    refs = analysis.c.call_signatures.get(('setArguments', SET), ())
    sites = [site for ref in sorted(refs) if framework_call(analysis, ref, 'setArguments', SET)
             for site in analysis.c.callers_of(ref)]
    sites.sort(key=lambda s: (s.method not in frames, s.method, s.offset))
    if len(sites) > 128:
        analysis.note('fragment_arguments_writer_limit', reader.ref)
    out = []

    def expand(method, call, reg, chain, seen, terminal):
        if not analysis.allowed(depth + len(chain)):
            return
        if method.ref in seen or len(chain) > 6:
            analysis.note('fragment_arguments_context_limit', method.ref)
            return
        formal = _formal(analysis, method, reg, call.offset)
        callers = analysis.c.callers_of(method.ref) if formal is not None and method.ref not in frames else ()
        if callers:
            if len(callers) > 32:
                analysis.note('fragment_arguments_context_limit', method.ref)
            for site in callers[:32]:
                cm = analysis.p.methods.get(site.method)
                invocation = analysis.instruction(site.method, site.offset)
                actual = analysis.actuals(invocation) if invocation else ()
                if cm and formal < len(actual):
                    expand(cm, invocation, actual[formal], ((cm, invocation, method),) + chain,
                           seen | {method.ref}, terminal)
            return
        context = frames.get(method.ref, (None, 0))[1]
        proof = []
        guarded = not _straight(method, call.offset)
        for cm, invocation, target in chain:
            guarded |= not _straight(cm, invocation.offset)
            proof.append(analysis.site(cm.ref, invocation.offset))
            context = analysis.binding(cm.ref, invocation, target, context)
        tm, tc = terminal
        actual = analysis.actuals(tc)
        out.append(Write(tm.ref, tc.offset, context, actual[0], actual[1],
                         method.ref, call.offset, tuple(proof), guarded))

    for site in sites[:128]:
        call = analysis.instruction(site.method, site.offset)
        method = analysis.p.methods.get(site.method)
        actual = analysis.actuals(call) if call else ()
        if method and len(actual) == 2 and not call.op.startswith('invoke-static'):
            expand(method, call, actual[0], (), frozenset(), (method, call))
    return tuple(out)


def _arguments(analysis, method, call, ctx, depth):
    from .demand import Origin, compatible
    actual = analysis.actuals(call)
    where = analysis.site(method.ref, call.offset)
    if len(actual) != 1 or call.op.startswith('invoke-static'):
        return ()
    fragments = analysis.trace(method.ref, actual[0], call.offset, 'object', ctx, depth)
    if not _single_allocation(fragments):
        analysis.note('fragment_arguments_alias_unresolved', where)
        return ()
    concrete = allocation_type(analysis, fragments[0])
    if not any(analysis.p.is_subtype(concrete, base) for base in FRAGMENTS):
        return ()
    if not framework_call(analysis, concrete + '->getArguments' + GET, 'getArguments', GET):
        analysis.note('fragment_arguments_override_unresolved', where)
        return ()
    matching = []
    for writer in _writes(analysis, method, call.offset, ctx, depth):
        if writer.root == method.ref and writer.root_offset >= call.offset:
            continue
        wm = analysis.p.methods[writer.method]
        written = analysis.trace(writer.method, writer.fragment, writer.offset,
                                 'object', writer.context, depth)
        if not any(a.key == fragments[0].key for a in written):
            continue
        if not _single_allocation(written):
            analysis.note('fragment_arguments_alias_unresolved', analysis.site(writer.method, writer.offset))
            return ()
        if not framework_call(analysis, concrete + '->setArguments' + SET, 'setArguments', SET):
            analysis.note('fragment_arguments_override_unresolved', where)
            return ()
        if writer.guarded or not _straight(wm, writer.offset):
            analysis.note('fragment_arguments_conditional_write_unresolved', analysis.site(writer.method, writer.offset))
            return ()
        matching.append((writer, written))
    # A local, unambiguous last assignment is sound. Cross-method writes have no
    # established temporal order, so even two exact aliases must not be merged.
    if len(matching) > 1:
        if all(w.method == method.ref and w.context == ctx and not w.chain for w, _ in matching) and _straight(method, call.offset):
            matching = [max(matching, key=lambda item: item[0].offset)]
        else:
            analysis.note('fragment_arguments_write_order_unresolved', where)
            return ()
    out = []
    for writer, written in matching:
        if writer.root != method.ref:
            analysis.note('fragment_arguments_lifecycle_order_unresolved', where)
        token = 'fragment_arguments:' + fragments[0].key + ':write:' + analysis.site(writer.method, writer.offset)
        # The context suffix is already part of the Fragment allocation key;
        # the stored tuple keeps its Bundle operand in exactly that context.
        analysis.memo[('fragment_arguments_writer', token)] = writer
        for fragment in fragments:
            for target in written:
                if not compatible(fragment, target):
                    continue
                out.append(Origin('fragment_arguments', token, BUNDLE,
                    path=fragment.path + writer.chain + ('fragment_arguments_set:' + analysis.site(writer.method, writer.offset),
                                                        'fragment_arguments_get:' + where) +
                         (('fragment_arguments_read_after_set_assumed:' + where,) if writer.root != method.ref else ()),
                    guards=fragment.guards | target.guards,
                    callback_instances=fragment.callback_instances | target.callback_instances))
    if not matching:
        analysis.note('fragment_arguments_writer_unresolved', where)
    return tuple(out)


def _intent_values(analysis, origin, key, where):
    from .demand import Origin
    target = origin.key.removeprefix('intent:')
    found = []
    for forwarder in analysis.forwarders:
        # A forwarded external nested Intent carries the whole extras
        # container. Its conditional target witness must survive getExtras;
        # unlike a structured putExtra summary, it has no single payload key.
        # Never infer this meaning just from missing target/key metadata.
        whole_intent = (forwarder.get('classification') == 'conditional_intent_forwarding'
                        and 'payload' not in forwarder and 'extra_key' not in forwarder)
        declared_target = forwarder.get('target_class')
        if declared_target and declared_target != target:
            continue
        if not whole_intent and (declared_target != target or forwarder.get('payload') != 'extra'
                                 or forwarder.get('extra_key') != key):
            continue
        source = forwarder['source']
        condition = (where + ':conditional_internal_intent_target',) if whole_intent else ()
        found.append(Origin('external_value', source['key'], entry=source['entry'],
            path=tuple(source['path']) + (forwarder['site'] + ':intent_forwarding',) + condition +
                 (where + ':intent_extra_key:' + key,),
            guards=frozenset(tuple(g) for g in source.get('branch_choices', ())),
            callback_instances=frozenset(source.get('callback_instances', ()))))
    return tuple(found) or (replace(origin, kind='internal_value').step(where + ':intent_extra_key:' + key),)


def _bundle_value(analysis, method, reg, before, ctx, key, depth, reader=None):
    """Read one constant string key from the exact setter's Bundle operand."""
    if not analysis.allowed(depth):
        return ()
    formal = _formal(analysis, method, reg, before)
    if formal is not None:
        bound = analysis.contexts.get(ctx, {}).get(method.argument_registers()[formal])
        if bound:
            caller, actual, offset, parent = bound
            return _bundle_value(analysis, analysis.p.methods[caller], actual, offset,
                                 parent, key, depth + 1, reader)
    local_read = bool(reader and reader[0] == method.ref and reader[2] == ctx)
    until = reader[1] if local_read else before
    bases = analysis.trace(method.ref, reg, before, 'object', ctx, depth)
    where = analysis.site(method.ref, before)
    if not bases:
        return ()
    source_container = all(b.kind in ('intent_extras', 'external_value', 'bridge_parameter') for b in bases)
    # setArguments keeps the Bundle reference. Do not freeze a stale value at
    # assignment when a later local mutation may replace it before lifecycle
    # delivery. Source-container mutation is conservatively unresolved too.
    for mutation in method.instructions:
        if not mutation.op.startswith('invoke-') or not mutation.ref:
            continue
        owner, name, _ = split_ref(mutation.ref)
        if owner not in (BUNDLE, BASE_BUNDLE) or not (name.startswith('put') or name in ('remove', 'clear')):
            continue
        if not (source_container and mutation.offset < until or not local_read and mutation.offset > before):
            continue
        actual = analysis.actuals(mutation)
        changed = analysis.trace(method.ref, actual[0], mutation.offset, 'object', ctx, depth) if actual else ()
        if any(a.key == b.key for a in changed for b in bases):
            analysis.note('fragment_arguments_bundle_mutation_unresolved', analysis.site(method.ref, mutation.offset))
            return ()
    if all(b.kind == 'intent_extras' for b in bases):
        return tuple(value for b in bases for value in _intent_values(analysis, b, key, where))
    if all(b.kind in ('external_value', 'bridge_parameter') for b in bases):
        # Intent extras from an external sender are source containers. Never
        # accept a flattened internal-forwarding value: its key was discarded.
        if any(any(':intent_forwarding' in step for step in b.path) for b in bases):
            analysis.note('fragment_arguments_payload_key_unresolved', where)
            return ()
        return tuple(b.step(where + ':Bundle_value:container_key:' + key) for b in bases)
    if not _single_allocation(bases) or not _straight(method, until):
        analysis.note('fragment_arguments_bundle_unresolved', where)
        return ()
    for call in reversed(method.instructions):
        if call.offset >= until or not call.op.startswith('invoke-') or not call.ref:
            continue
        owner, name, desc = split_ref(call.ref)
        if owner not in (BUNDLE, BASE_BUNDLE) or not (name.startswith('put') or name in ('remove', 'clear')):
            continue
        actual = analysis.actuals(call)
        if not actual:
            continue
        written = analysis.trace(method.ref, actual[0], call.offset, 'object', ctx, depth)
        if not any(b.key == bases[0].key for b in written):
            continue
        if not _single_allocation(written) or len(actual) < 2 or name in ('clear', 'putAll'):
            analysis.note('fragment_arguments_bundle_unresolved', where)
            return ()
        keys = analysis.trace(method.ref, actual[1], call.offset, 'value', ctx, depth)
        if len(keys) != 1 or keys[0].kind != 'constant':
            analysis.note('fragment_arguments_payload_key_unresolved', where)
            return ()
        if keys[0].value != key:
            continue
        if name != 'putString' or desc != '(' + STRING + STRING + ')V' or len(actual) != 3:
            # A removal or a type-changing overwrite kills the string value.
            return ()
        return tuple(v.step('fragment_argument_key:' + key + ':' + analysis.site(method.ref, call.offset))
                     for v in analysis.trace(method.ref, actual[2], call.offset, 'value', ctx, depth))
    return ()


def result(analysis, method, call, mode, ctx, depth):
    """None = not modeled; () = a recognized but unverified transfer."""
    owner, name, desc = split_ref(call.ref)
    actual = analysis.actuals(call)
    if framework_call(analysis, call.ref, 'getArguments', GET):
        return _arguments(analysis, method, call, ctx, depth)
    # Delay only internal getExtras reads. Otherwise the existing summary loses
    # the exact extra key before the downstream Bundle getter can check it.
    if owner == INTENT and name == 'getExtras' and desc == GET and len(actual) == 1:
        origins = analysis.trace(method.ref, actual[0], call.offset, 'value', ctx, depth)
        if origins and all(o.kind == 'internal_intent' for o in origins):
            return tuple(replace(o, kind='intent_extras', typ=BUNDLE).step(
                analysis.site(method.ref, call.offset) + ':intent_extras_container') for o in origins)
        return None
    if owner not in (BUNDLE, BASE_BUNDLE) or name != 'getString' or desc not in (
            '(' + STRING + ')' + STRING, '(' + STRING + STRING + ')' + STRING) or len(actual) < 2:
        return None
    bases = analysis.trace(method.ref, actual[0], call.offset, 'object', ctx, depth)
    if not bases or not any(b.kind in ('fragment_arguments', 'intent_extras') for b in bases):
        return None
    where = analysis.site(method.ref, call.offset)
    keys = analysis.trace(method.ref, actual[1], call.offset, 'value', ctx, depth)
    if len(keys) != 1 or keys[0].kind != 'constant':
        analysis.note('fragment_arguments_payload_key_unresolved', where)
        return ()
    from .demand import compatible
    out = []
    for base in bases:
        if base.kind == 'intent_extras':
            values = _bundle_value(analysis, method, actual[0], call.offset, ctx,
                                   keys[0].value, depth, (method.ref, call.offset, ctx))
            for value in values:
                if compatible(base, value):
                    out.append(replace(value, guards=value.guards | base.guards,
                        callback_instances=value.callback_instances | base.callback_instances))
            continue
        writer = analysis.memo.get(('fragment_arguments_writer', base.key))
        if not writer:
            continue
        values = _bundle_value(analysis, analysis.p.methods[writer.method], writer.bundle,
                               writer.offset, writer.context, keys[0].value, depth,
                               (method.ref, call.offset, ctx))
        for value in values:
            if compatible(base, value):
                out.append(replace(value, path=value.path + base.path + ('fragment_arguments_read:' + where,),
                    guards=value.guards | base.guards,
                    callback_instances=value.callback_instances | base.callback_instances))
    return tuple(out)
