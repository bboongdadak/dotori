"""DOTORI: static path candidates, never confirmed exploitability."""

__version__ = "0.3.2"
