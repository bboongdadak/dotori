"""Manifest facts; exported does not imply an unprivileged caller is allowed."""

from .model import Component, dex_name

NS = "{http://schemas.android.com/apk/res/android}"


def parse_manifest(root):
    package = root.get("package", "")
    notes = []

    def number(value, fallback=None):
        try:
            return int(value, 0) if isinstance(value, str) else fallback
        except ValueError:
            return fallback

    sdk = root.find("uses-sdk")
    minimum = number(sdk.get(NS + "minSdkVersion"), 1) if sdk is not None else 1
    target = (
        number(sdk.get(NS + "targetSdkVersion"), minimum)
        if sdk is not None
        else minimum
    )
    levels = {
        p.get(NS + "name"): p.get(NS + "protectionLevel", "normal")
        for p in root.findall("permission")
    }

    def qualify(name):
        return (
            package + name
            if name.startswith(".")
            else package + "." + name if "." not in name else name
        )

    app = root.find("application")
    if app is None:
        return package, target, minimum, [], notes
    enabled_app = app.get(NS + "enabled", "true") != "false"
    components = []
    nodes = [
        n
        for n in app
        if n.tag in ("activity", "activity-alias", "service", "receiver", "provider")
    ]
    target_enabled = {
        qualify(n.get(NS + "name", "")): n.get(NS + "enabled", "true") != "false"
        for n in nodes
        if n.tag == "activity"
    }
    for node in nodes:
        name = node.get(NS + "name")
        if not name:
            continue
        name = qualify(name)
        code_name = (
            qualify(node.get(NS + "targetActivity"))
            if node.tag == "activity-alias" and node.get(NS + "targetActivity")
            else name
        )
        filters = []
        for f in node.findall("intent-filter"):
            filters.append(
                {
                    "actions": [x.get(NS + "name") for x in f.findall("action")],
                    "categories": [x.get(NS + "name") for x in f.findall("category")],
                    "data": [
                        {k.removeprefix(NS): v for k, v in x.attrib.items()}
                        for x in f.findall("data")
                    ],
                }
            )
        explicit = node.get(NS + "exported")
        if explicit is not None:
            exported, reason = explicit == "true", "explicit"
        elif node.tag == "provider":
            exported, reason = (
                target is not None and target <= 16,
                "provider SDK default",
            )
        else:
            exported, reason = bool(filters), "intent-filter default"
            if filters and target is not None and target >= 31:
                notes.append(
                    {
                        "code": "manifest_installability",
                        "detail": f"{name}: target >=31 requires explicit exported; treated as a conditional entry",
                    }
                )
        enabled = enabled_app and node.get(NS + "enabled", "true") != "false"
        if node.tag == "activity-alias":
            enabled = enabled and target_enabled.get(code_name, False)
        if any(
            str(v).startswith("@")
            for v in (node.get(NS + "enabled", ""), explicit or "")
        ):
            notes.append({"code": "manifest_resource_unresolved", "detail": name})
        perm = node.get(NS + "permission", app.get(NS + "permission"))
        if node.tag == "activity-alias" and NS + "permission" not in node.attrib:
            target_node = next(
                (
                    n
                    for n in nodes
                    if n.tag == "activity"
                    and qualify(n.get(NS + "name", "")) == code_name
                ),
                None,
            )
            if target_node is not None:
                perm = target_node.get(NS + "permission", app.get(NS + "permission"))
        components.append(
            Component(
                name,
                dex_name(code_name),
                node.tag,
                exported,
                enabled,
                perm,
                levels.get(perm),
                reason,
                filters,
            )
        )
    return package, target, minimum, components, notes
