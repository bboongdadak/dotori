"""Analyst handoff is separate from exhaustive static coverage."""
from collections import Counter


GLOBAL_INTERRUPTS = {'analysis_timeout', 'total_query_limit', 'catalog_decode_gap'}


def diagnostic_kind(code):
    if code in GLOBAL_INTERRUPTS or code.endswith(('_limit', '_timeout')):
        return 'coverage_gap'
    if code.startswith('manifest_') or code in ('duplicate_method', 'dynamic_invoke_unresolved'):
        return 'input_model_gap'
    return 'model_gap'


def collection_status(loading, registrations, diagnostics):
    """Finish means every selected seed was attempted, not every value solved.

    Local slice limits remain visible in coverage and per-path context. Global
    interruption, unread bytecode, or an unvisited seed still means incomplete.
    """
    if any(s['status']=='unvisited_budget' for s in loading+registrations):
        return 'incomplete'
    if any(d['code'] in GLOBAL_INTERRUPTS for d in diagnostics):
        return 'incomplete'
    if diagnostics or any(s['status'] not in ('sliced_complete', 'unreachable_constant_branch')
                          for s in loading+registrations):
        return 'completed_with_gaps'
    return 'completed_with_model_limits'


def annotate_paths(groups, loading, registrations):
    """Attach the gaps at the involved sites without invalidating a witness.

    A slice diagnostic can refer to a discarded alternative rather than this
    witness. Report it as context, never claim it is a proven break in the path.
    """
    sites={s['site']:s for s in loading+registrations}
    counts=Counter()
    for group,items in groups.items():
        counts[group]=len(items)
        for item in items:
            sink=item.get('load',item.get('javascript_execution',{}))
            involved=[sites[s] for s in (sink.get('site'),item.get('bridge',{}).get('site')) if s in sites]
            gaps=[{'site':s['site'], 'slice_status':s['status'],
                   'diagnostic_codes':s.get('diagnostic_codes',[])}
                  for s in involved if s['status']!='sliced_complete']
            relations=item.get('object_relations',[])
            weak=any(r['relation'] in ('same_field_slot_possible_instance','same_constructor_receiver_possible_instance','same_lookup_result_possible_instance') for r in relations)
            steps=item['source'].get('path',[])
            tasks=list(item.get('assumptions',[]))
            all_steps=steps+[p for atom in sink.get('receiver',[]) for p in atom.get('path',[])]
            if any('framework_constructor_assumed:' in p for p in all_steps):
                tasks.append('The lookup identifies the owner under non-null/layout assumptions; constructor/helper initialization and no intervening field replacement must hold for this framework-created instance.')
            if any('callback_registered:AndroidView_factory:' in p for p in all_steps):
                tasks.append('This Function1 instance is supplied as an AndroidView factory. Framework invocation, recomposition and view lifetime remain runtime assumptions.')
            if any('callback_registered:LaunchedEffect:' in p for p in all_steps):
                tasks.append('This Function2 instance is supplied to LaunchedEffect; the actual create return and invokeSuspend call are followed. Composition entry, scheduling, cancellation and launch lifetime remain runtime assumptions.')
            receiver_status=sink.get('receiver_resolution')
            if receiver_status=='unresolved':
                tasks.append('Only the loading argument value is recovered; a compatible non-null WebView receiver is unresolved. Do not count this as receiver-supported execution.')
            elif receiver_status=='possible_identity':
                tasks.append('Verify the possible loading receiver identity and runtime instance before treating this value path as executed.')
            if any('uri_builder_normal_success_assumed' in step for step in steps):
                tasks.append('URI construction follows the normal-success path; covering exception handlers cannot deliver this read, but successful API execution is not proved.')
            if any(r['relation']=='same_lookup_result_possible_instance' for r in relations):
                tasks.append('The same conditional View lookup result is reused; verify non-null resolution, root type, resource membership and root/view-tree lifetime.')
            if any('constructed_callback_dispatch_unproven' in step for step in steps):
                tasks.append('Callback construction/captured values are recovered, but this receiver proof alone does not establish callback registration, scheduling or invocation order.')
            if any('field_owner_instance_unproven:' in step for atom in sink.get('receiver',[]) for step in atom.get('path',[])):
                tasks.append('The field writer and reader have only a relative owner-type match; verify that they operate on the same runtime owner instance before counting a receiver-supported path.')
            if any('dispatch_receiver_type_unproven' in step for step in steps):
                tasks.append('Conditional dispatch: verify the runtime receiver implements the displayed target; body-derived type evidence is not an object-identity proof.')
            if any('state_read_after_write_assumed' in step or 'view_tag_read_after_write_assumed' in step or 'fragment_arguments_read_after_set_assumed' in step for step in all_steps):
                tasks.append('Verify the displayed state/tag/Fragment argument write occurs before this callback read on the same runtime instance; lifecycle order is assumed.')
            if any(owner.endswith(':exception') for owner,_,_ in item['source'].get('branch_choices',[])):
                tasks.append('Verify the displayed exception can occur and matches its handler type; the caught path is conditional.')
            if any(r['relation']=='same_field_slot_possible_instance' for r in relations):
                tasks.append('Verify the possible field-slot receiver alias in the displayed methods.')
            if any(r['relation']=='same_constructor_receiver_possible_instance' for r in relations):
                tasks.append('The WebView identity is symbolic this within the same constructor execution, not a recovered allocation; verify framework construction and instance lifetime.')
            if gaps:tasks.append('Inspect slice gaps for alternative or missing flows; they need not invalidate this witness.')
            item['review']={
                'status':'ready_for_review' if steps else 'needs_value_trace',
                'evidence_level':('value_path_with_possible_receiver' if weak or receiver_status=='possible_identity' else
                                  'value_and_receiver_path' if receiver_status=='abstract_identity' or relations else 'value_path'),
                'vulnerability_verdict':'not_assessed',
                'receiver_resolution':receiver_status,
                'source_to_sink_steps':len(steps),
                'context_gaps':gaps,
                'manual_checks':tasks,
            }
    return {'status':'paths_available' if any(counts.values()) else 'no_linked_paths',
            'path_counts':dict(counts),
            'meaning':'Linked static witnesses for manual review; no vulnerability or absence verdict.'}
