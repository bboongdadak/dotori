"""Demand-driven backward slices from WebView operands.

The output keeps source-to-loading, registration, and Bridge-to-JavaScript
relations separate. A lexical API occurrence never becomes a connected path.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, replace
from collections import defaultdict, deque
import hashlib
import json
import time
from functools import lru_cache

from .engine import Limits
from .model import parameters, split_ref
from . import router_transfers, intent_delivery
from . import uri_builder
from . import __version__
from . import keyed_maps
from .javascript import javascript_url_evidence
from .reporting import annotate_paths, collection_status, diagnostic_kind
from . import webview_callbacks, state_summaries, livedata, view_state, collections_summary
from . import view_lookup
from . import string_format
from . import heap_context
from . import compose_callbacks
from . import compose_effects

WV='Landroid/webkit/WebView;'
JS='Landroid/webkit/JavascriptInterface;'
INTENT='Landroid/content/Intent;'


@dataclass(frozen=True)
class Origin:
    kind: str
    key: str
    typ: str=''
    entry: str=''
    value: str=''
    path: tuple[str,...]=()
    guards: frozenset[tuple[str,int,int]]=frozenset()
    callback_instances: frozenset[str]=frozenset()

    def step(self,site):
        return replace(self,path=self.path+(site,))

    def dump(self):
        return {'kind':self.kind,'key':self.key,'type':self.typ,'entry':self.entry,'value':self.value,
                'path':list(self.path),'branch_choices':[list(x) for x in sorted(self.guards)],
                'callback_instances':sorted(self.callback_instances),'invocation_choices':[list(x) for x in invocation_choices(self)]}


def invocation_choices(origin):
    return _invocation_path_choices(origin.path)


@lru_cache(maxsize=8192)
def _invocation_path_choices(path):
    choices=set()
    for step in path:
        if step.startswith('call_tuple:'):
            try:choices.add(tuple(json.loads(step[len('call_tuple:'):])))
            except (ValueError,TypeError):continue
    return tuple(sorted(choices))


def compatible(a,b):
    if a.callback_instances and b.callback_instances and not a.callback_instances.intersection(b.callback_instances):return False
    choices={}
    for owner,branch,target in a.guards|b.guards:
        key=(owner,branch)
        if key in choices and choices[key]!=target:return False
        choices[key]=target
    calls={}
    for method,call in invocation_choices(a)+invocation_choices(b):
        if method in calls and calls[method]!=call:return False
        calls[method]=call
    return True


class Backward:
    def __init__(self,p,limits=None,focus_methods=()):
        if p.catalog is None:raise ValueError('Demand analysis requires a compact DEX catalog')
        self.p=p;self.c=p.catalog;self.limits=limits or Limits(max_depth=48);self.focus_methods=tuple(focus_methods)
        self.started=time.monotonic();self.queries=0;self.sink_queries=0;self.notes=set();self.seed_notes=set();self.phase_notes=set()
        self.memo={};self.active=set();self.contexts={0:{}};self.context_origins={};self.context_keys={};self.next_context=1
        self.context_tokens={0:''};self.allocation_contexts={}
        self.cfg_cache={};self.control_guard_cache={};self.forwarders=[];self.visited=set();self.coverage=[];self.incomplete=False
        self.caller_cache={};self.root_cache={}
        # Divide the query budget among relevant API seeds. The old 4,000
        # ceiling made --max-steps ineffective on large APKs even when time
        # and the total query budget remained available.
        relevant_seeds=sum(self.is_webview_api(site) for site in self.c.inventory)
        self.per_sink_limit=max(100,min(20000,self.limits.max_steps//max(1,relevant_seeds)))
        self.seed_started=self.started;self.phase_deadline=None;self.branch_query_limit=None
        self.source_distance_cache={};self.source_methods=set()
        self.factory_paths=[];self.target_scanned=set()
        for (name,desc),refs in self.c.call_signatures.items():
            if name in ('getIntent','getData','getDataString','getStringExtra','getParcelableExtra'):
                for ref in refs:self.source_methods.update(s.method for s in self.c.callers_of(ref))
        self.seed_seconds=max(0.1,self.limits.timeout_seconds/max(1,relevant_seeds))

    def note(self,code,detail):
        self.notes.add((code,detail));self.seed_notes.add((code,detail));self.phase_notes.add((code,detail));self.incomplete=True

    def seed_diagnostics(self):
        return [{'code':c,'detail':d,'kind':diagnostic_kind(c)} for c,d in sorted(self.seed_notes)]
    def reset(self):
        self.sink_queries=0;self.memo.clear();self.active.clear();self.contexts={0:{}};self.context_origins.clear();self.context_keys={};self.next_context=1;self.seed_started=time.monotonic();self.branch_query_limit=None;self.seed_notes.clear()
        self.context_tokens={0:''};self.allocation_contexts.clear()
    def allowed(self,depth):
        if self.branch_query_limit is not None and self.sink_queries>=self.branch_query_limit:self.note('caller_branch_query_limit','A caller alternative exhausted its slice share');return False
        if self.phase_deadline and time.monotonic()>self.phase_deadline:self.note('forwarding_time_limit','Forwarding prepass budget exhausted');return False
        if time.monotonic()-self.seed_started>self.seed_seconds:self.note('seed_time_limit',str(round(self.seed_seconds,4)));return False
        if depth>self.limits.max_depth:self.note('slice_depth_limit',str(self.limits.max_depth));return False
        if self.sink_queries>=self.per_sink_limit:self.note('slice_query_limit',str(self.per_sink_limit));return False
        if self.queries>=self.limits.max_steps:self.note('total_query_limit',str(self.limits.max_steps));return False
        if time.monotonic()-self.started>=self.limits.timeout_seconds:self.note('analysis_timeout',str(self.limits.timeout_seconds));return False
        return True
    def instruction(self,ref,offset):
        m=self.p.methods.get(ref)
        return next((i for i in m.instructions if i.offset==offset),None) if m else None
    @staticmethod
    def site(ref,offset):return ref+'@'+format(offset,'04x')

    def cfg(self,ref):
        if ref in self.cfg_cache:return self.cfg_cache[ref]
        m=self.p.methods[ref];ins=list(m.instructions);pred=defaultdict(list)
        for index,i in enumerate(ins):
            after=ins[index+1].offset if index+1<len(ins) else None
            if i.op.startswith(('return','throw')):targets=[]
            elif i.op.startswith('goto'):targets=[i.target]
            elif i.op.startswith('if-'):targets=[after,i.target]
            elif i.op in ('packed-switch','sparse-switch'):targets=[after]+[v for _,v in i.cases]
            else:targets=[after]
            branching=i.op.startswith('if-') or i.op in ('packed-switch','sparse-switch')
            for target in targets:
                if target is not None:pred[target].append((i.offset,(ref,i.offset,target) if branching else None))
        # Exceptional control flow preserves the state *before* a throwing
        # instruction. Guard tags let definitions skip its normal destination.
        for start,end,handler,exception in m.exception_handlers:
            if handler not in {i.offset for i in ins}:
                self.note('exception_handler_unresolved',self.site(ref,handler));continue
            for i in ins:
                if start<=i.offset<end and self.may_throw(i):
                    pred[handler].append((i.offset,(ref+':exception',i.offset,handler)))
            self.note('exception_type_feasibility_unresolved',ref+':'+exception)
        result=(ins,{i.offset:i for i in ins},pred)
        self.cfg_cache[ref]=result
        # Prune branches only when every local reaching definition agrees on
        # the scalar value. Unknown input-dependent conditions stay in the CFG.
        impossible=set()
        for index,i in enumerate(ins):
            if time.monotonic()-self.seed_started>self.seed_seconds:break
            if not i.op.startswith('if-'):continue
            vals=[self.local_constant(ref,r,i.offset) for r in i.regs]
            if not vals or not all(ok for ok,_ in vals):continue
            a=vals[0][1];b=vals[1][1] if len(vals)>1 else 0
            try:
                test=i.op[3:].removesuffix('z')
                taken={'eq':lambda:a==b,'ne':lambda:a!=b,'lt':lambda:a<b,'le':lambda:a<=b,'gt':lambda:a>b,'ge':lambda:a>=b}[test]()
            except (KeyError,TypeError):continue
            after=ins[index+1].offset if index+1<len(ins) else None
            impossible.add((i.offset,after if taken else i.target))
        if impossible:
            pred=defaultdict(list,{target:[(source,edge) for source,edge in parents if (source,target) not in impossible] for target,parents in pred.items()})
            result=(ins,result[1],pred)
        if len(self.cfg_cache)>256:self.cfg_cache.clear()
        self.cfg_cache[ref]=result;return result

    def local_constant(self,ref,reg,before,seen=frozenset()):
        if time.monotonic()-self.seed_started>self.seed_seconds:return False,None
        key=(ref,reg,before)
        if key in seen or len(seen)>16:return False,None
        vals=[]
        for i,_ in self.definitions(ref,reg,before):
            if i is None:return False,None
            if i.op.startswith('const'):vals.append(i.literal)
            elif i.op.startswith('move') and not i.op.startswith('move-result') and len(i.regs)>1:
                ok,v=self.local_constant(ref,i.regs[1],i.offset,seen|{key})
                if not ok:return False,None
                vals.append(v)
            else:return False,None
        return (True,vals[0]) if vals and all(v==vals[0] for v in vals) else (False,None)

    def reachable(self,ref,offset):
        ins,_,pred=self.cfg(ref)
        if not ins:return False
        todo=[offset];seen=set()
        while todo:
            at=todo.pop()
            if at==ins[0].offset:return True
            if at in seen:continue
            seen.add(at);todo.extend(p for p,_ in pred.get(at,()))
        return False

    def control_guards(self,ref,offset):
        """Necessary entry-to-instruction choices, including before a definition.

        Reaching-definition search stops at the assignment, so its suffix alone
        omits the branch controlling that assignment. Propagate intersections
        over reachable predecessors: joins remove optional choices, whereas a
        branch-local allocation/value retains its required outcome. This is not
        an enumeration or a proof of all feasible paths through loops.
        """
        if ref not in self.control_guard_cache:
            ins,_,pred=self.cfg(ref)
            if not ins:return None
            successors=defaultdict(list)
            for target,parents in pred.items():
                for source,edge in parents:successors[source].append((target,edge))
            requirements={ins[0].offset:frozenset()}
            todo=deque((ins[0].offset,));pending={ins[0].offset};steps=0
            while todo and steps<20000:
                if steps%64==0 and not self.allowed(0):break
                source=todo.popleft();pending.discard(source);steps+=1
                for target,edge in successors[source]:
                    if target==ins[0].offset:continue
                    incoming=requirements[source]|(frozenset((edge,)) if edge else frozenset())
                    old=requirements.get(target)
                    merged=incoming if old is None else old&incoming
                    if old is None or merged!=old:
                        requirements[target]=merged
                        if target not in pending:todo.append(target);pending.add(target)
            if todo:
                self.note('control_guard_limit',ref)
                return None
            self.control_guard_cache[ref]=requirements
        return self.control_guard_cache[ref].get(offset)

    @staticmethod
    def may_throw(i):
        return i.op.startswith(('invoke-','throw','new-','filled-new-array','check-cast',
                                'iget','iput','sget','sput','aget','aput','array-length',
                                'div-','rem-','monitor-'))

    @staticmethod
    def defines(i,reg):
        if not i.regs or i.regs[0]!=reg:return False
        return not i.op.startswith(('invoke-','return','throw','if-','goto','iput','sput','aput','monitor-','packed-switch','sparse-switch','fill-array-data','filled-new-array')) and i.op!='nop'

    def definitions(self,ref,reg,before):
        ins,byoff,pred=self.cfg(ref)
        if not ins:return [(None,frozenset())]
        # Start strictly before the instruction consuming the register.
        todo=[(p,frozenset((edge,)) if edge else frozenset()) for p,edge in pred.get(before,())]
        if before==ins[0].offset:return [(None,frozenset())]
        if before not in byoff:
            todo=[(ins[-1].offset,frozenset())]
        result=[];seen=set()
        while todo and len(seen)<2000 and len(result)<32:
            if len(seen)%64==0 and time.monotonic()-self.seed_started>self.seed_seconds:
                self.note('seed_time_limit',self.site(ref,before));break
            offset,guards=todo.pop();key=(offset,guards)
            if key in seen:continue
            seen.add(key);i=byoff[offset]
            exceptional=any(owner==ref+':exception' and source==offset for owner,source,_ in guards)
            if self.defines(i,reg) and not exceptional:result.append((i,guards));continue
            parents=pred.get(offset,())
            if not parents and offset==ins[0].offset:result.append((None,guards))
            for parent,edge in parents:
                added=guards|frozenset((edge,)) if edge else guards
                # A path cannot choose both outcomes of the same branch without
                # a loop. Keep it as unresolved rather than merging iterations.
                if len({(x[0],x[1]) for x in added})<len(added):continue
                todo.append((parent,added))
        if todo:self.note('local_definition_limit',self.site(ref,before))
        return result

    def binding(self,caller,call,target,parent):
        key=(caller,call.offset,target.ref,parent)
        if key in self.context_keys:return self.context_keys[key]
        ctx=self.next_context;self.next_context+=1;self.context_keys[key]=ctx
        actual=self.actuals(call)
        self.contexts[ctx]={formal:(caller,reg,call.offset,parent) for formal,reg in zip(target.argument_registers(),actual)}
        # A numeric context ID is seed-local and must never become heap identity.
        # Keep the whole calling chain in a bounded, deterministic fingerprint.
        # The existing query/depth budgets bound the number of contexts created.
        token=(self.context_tokens.get(parent,''),caller,call.offset,target.ref)
        self.context_tokens[ctx]=hashlib.sha256(json.dumps(token).encode()).hexdigest()[:24]
        return ctx

    def allocation_key(self,m,i,ctx):
        """Separate factory invocations while retaining the replay context.

        Root allocations keep their existing site identity. Component-only
        contexts retain the established lifecycle heap abstraction; a real
        caller binding is what introduces a call-context suffix.
        """
        key=self.site(m.ref,i.offset)
        token=self.context_tokens.get(ctx,'')
        if token:key+=':call_context:'+token
        self.allocation_contexts[key]=(m.ref,ctx)
        return key

    def constructor_contexts(self,base,constructor,depth):
        """Replay a constructor from the allocation's own caller context."""
        location=self.allocation_contexts.get(base.key)
        out=[]
        for callsite in self.c.callers_of(constructor.ref):
            # A constructor must initialize this allocation in its allocating
            # method. Do not substitute another factory invocation's arguments.
            if location and callsite.method!=location[0]:continue
            call=self.instruction(callsite.method,callsite.offset)
            if not call or not call.regs:continue
            parent=location[1] if location else 0
            allocated=self.trace(callsite.method,call.regs[0],call.offset,'object',parent,depth)
            if any(a.key==base.key and compatible(a,base) for a in allocated):
                out.append(self.binding(callsite.method,call,constructor,parent))
        return out

    def component_context(self,method,base):
        """Keep an instance field's component when visiting its writer.

        A base-class lifecycle writer must be evaluated with the reader's
        component, rather than all manifest subclasses of that base class.
        This is an abstract lifecycle relation, not proof the writer executes.
        """
        formals=method.argument_registers()
        if 'static' in method.access.split() or not formals:return 0
        key=('component',method.ref,base)
        if key in self.context_keys:return self.context_keys[key]
        ctx=self.next_context;self.next_context+=1;self.context_keys[key]=ctx
        self.contexts[ctx]={}
        self.context_origins[ctx]={formals[0]:(base.step('component_context:'+method.ref),)}
        # One inherited allocation site may execute on distinct components.
        # Keep its owner in the heap/call fingerprint, consistently across seeds.
        self.context_tokens[ctx]=(hashlib.sha256(json.dumps(('component',base.key)).encode()).hexdigest()[:24]
                                  if len(self.roots(method.owner))>1 else '')
        return ctx

    def known_receiver_types(self,m,reg,before,ctx,seen=frozenset()):
        """Cheap exhaustive type set for this/bound parameters/local allocations.

        Do not open arbitrary field/return graphs to choose a dispatch target.
        Casts constrain a type but cannot establish its concrete implementation.
        A branch-dependent local assignment deliberately falls back to dispatch.
        """
        key=(m.ref,reg,before,ctx)
        if key in seen or len(seen)>=16:return ()
        seen=seen|{key}
        prior=[j for j in m.instructions if j.offset<before]
        definitions=[j for j in prior if self.defines(j,reg) and j.op!='check-cast']
        if definitions:
            if any(j.op.startswith(('if-','goto')) or j.op in ('packed-switch','sparse-switch','throw') for j in prior):return ()
            last=definitions[-1]
            if last.op=='new-instance':return (str(last.literal),)
            if last.op.startswith('move') and not last.op.startswith('move-result') and len(last.regs)>1:
                return self.known_receiver_types(m,last.regs[1],last.offset,ctx,seen)
            return ()
        if reg in self.context_origins.get(ctx,{}):
            return tuple(sorted({a.typ for a in self.context_origins[ctx][reg] if a.kind=='component'}))
        if reg in self.contexts.get(ctx,{}):
            ref,r,b,c=self.contexts[ctx][reg]
            return self.known_receiver_types(self.p.methods[ref],r,b,c,seen)
        formals=m.argument_registers()
        if 'static' not in m.access.split() and formals and reg==formals[0]:
            return tuple(sorted({c.code_class for c in self.roots(m.owner)}))
        return ()

    def is_local_this(self,m,reg,before,seen=frozenset()):
        """Recognize this through local copies, never through casts alone."""
        key=(reg,before)
        if key in seen or len(seen)>=16:return False
        prior=[j for j in m.instructions if j.offset<before]
        definitions=[j for j in prior if self.defines(j,reg) and j.op!='check-cast']
        if definitions:
            if any(j.op.startswith(('if-','goto')) or j.op in ('packed-switch','sparse-switch') for j in prior):return False
            last=definitions[-1]
            return (last.op.startswith('move') and not last.op.startswith('move-result') and len(last.regs)>1
                    and self.is_local_this(m,last.regs[1],last.offset,seen|{key}))
        formals=m.argument_registers()
        return bool('static' not in m.access.split() and formals and reg==formals[0])

    @staticmethod
    def actuals(ins):
        if not ins.ref or '(' not in ins.ref:return list(ins.regs)
        _,_,desc=split_ref(ins.ref);out=[];cursor=0
        if not ins.op.startswith('invoke-static'):
            if ins.regs:out.append(ins.regs[0])
            cursor=1
        for typ in parameters(desc):
            if cursor<len(ins.regs):out.append(ins.regs[cursor])
            cursor+=2 if typ in ('J','D') else 1
        return out

    def callers(self,ref):
        if ref in self.caller_cache:return self.caller_cache[ref]
        exact=self.c.callers_of(ref)
        approximate=[]
        owner,name,desc=split_ref(ref)
        for candidate in self.c.call_signatures.get((name,desc),()):
            co,_,_=split_ref(candidate)
            if candidate!=ref and self.p.is_subtype(owner,co):
                # A superclass/direct/static invocation never dispatches to an
                # arbitrary override, even when the declared signatures match.
                # Compact catalog entries defer opcode decoding until the
                # parameter traversal validates each actual invocation below.
                approximate.extend(s for s in self.c.callers_of(candidate)
                                   if s.opcode=='direct_reference' or
                                   s.opcode.startswith(('invoke-virtual','invoke-interface')))
        key=lambda site:(self.source_distance(site.method),site.method,site.offset)
        seen=set();result=[]
        for site in sorted(exact,key=key)+sorted(approximate,key=key):
            identifier=(site.method,site.offset)
            if identifier not in seen:seen.add(identifier);result.append(site)
        if len(result)>64:self.note('caller_fanout_limit',ref)
        result=result[:64];self.caller_cache[ref]=result;return result

    def reverse_dispatch_receivers(self,target,caller,call,ctx,depth):
        """Validate a reversed virtual edge against concrete receiver origins.

        The signature index supplies candidates, not a dispatch proof. In
        particular, a call through WebView must not feed all WebView overrides.
        Unknown exact calls retain their old abstraction. A type-compatible
        approximate edge may remain as an explicitly conditional witness; it
        never supplies allocation identity or a callback execution proof.
        """
        if not call.op.startswith(('invoke-virtual','invoke-interface')):
            return call.ref==target.ref,()
        actual=self.actuals(call)
        if not actual:return False,()
        runnable=target.name=='run' and target.descriptor=='()V' and self.p.is_subtype(target.owner,'Ljava/lang/Runnable;')
        cheap=self.known_receiver_types(caller,actual[0],call.offset,ctx)
        if cheap and not any((resolved:=self.p.resolve(typ,target.name,target.descriptor)) and resolved.ref==target.ref for typ in cheap):
            return False,()
        if call.ref==target.ref and cheap and not runnable:
            return True,()
        # Dispatch validation must not consume the value slice while opening
        # unrelated framework object graphs. Do not cache capped exploratory
        # results into the caller's ordinary provenance memo.
        previous=self.branch_query_limit;saved_memo=self.memo
        self.branch_query_limit=min(previous if previous is not None else self.per_sink_limit,self.sink_queries+128)
        self.memo=dict(saved_memo)
        try:origins=self.trace(caller.ref,actual[0],call.offset,'object',ctx,depth)
        finally:self.branch_query_limit=previous;self.memo=saved_memo
        matched=[];unknown=False
        for origin in origins:
            typ=origin.typ if origin.kind=='component' else ''
            if origin.kind=='allocation':
                # check-cast records a declared type, not the allocated class.
                allocation=origin.key.split(':call_context:',1)[0]
                ref,separator,offset=allocation.rpartition('@')
                try:instruction=self.instruction(ref,int(offset,16)) if separator else None
                except ValueError:instruction=None
                if instruction and instruction.op=='new-instance':typ=str(instruction.literal)
            if not typ:
                unknown=True;continue
            if not self.p.is_subtype(typ,target.owner):continue
            implementation=self.p.resolve(typ,target.name,target.descriptor)
            if implementation and implementation.ref==target.ref:
                matched.append(replace(origin,typ=typ))
            elif implementation is None:
                # The compact class resolver cannot establish interface-default
                # dispatch or an implementation absent from the indexed DEX.
                unknown=True
        if matched:
            if unknown:self.note('virtual_receiver_unresolved',self.site(caller.ref,call.offset)+':'+target.ref)
            return True,tuple(matched)
        if origins and not unknown:return False,()
        if call.ref==target.ref:return True,()
        self.note('virtual_receiver_unresolved',self.site(caller.ref,call.offset)+':'+target.ref)
        if not runnable:
            bounds=self.receiver_type_bounds(caller,actual[0],call.offset,ctx)
            if bounds and any(self.p.is_subtype(target.owner,typ) or self.p.is_subtype(typ,target.owner) for typ in bounds):
                site=self.site(caller.ref,call.offset)
                self.note('dispatch_receiver_type_unproven',site+':'+target.ref)
                condition=site+':dispatch_receiver_type_unproven:'+target.ref
                return True,(Origin('conditional_dispatch',condition,target.owner,path=(condition,)),)
        return False,()

    def receiver_type_bounds(self,m,reg,before,ctx,seen=frozenset()):
        """Declared receiver bounds only; casts/getters do not prove identity."""
        state=(m.ref,reg,before,ctx)
        if state in seen or len(seen)>=8:return ()
        seen=seen|{state};out=set()
        for definition,_ in self.definitions(m.ref,reg,before):
            if definition is None:
                if reg in self.contexts.get(ctx,{}):
                    ref,r,offset,parent=self.contexts[ctx][reg]
                    out.update(self.receiver_type_bounds(self.p.methods[ref],r,offset,parent,seen))
                else:
                    formals=m.argument_registers()
                    if reg in formals:
                        types=parameters(m.descriptor)
                        if 'static' not in m.access.split():types=[m.owner]+types
                        out.add(types[formals.index(reg)])
                continue
            op=definition.op
            if op in ('check-cast','new-instance'):out.add(str(definition.literal))
            elif op.startswith(('iget','sget')):out.add(self.c.field_types.get(definition.ref,self.field_type(definition.ref)))
            elif op.startswith('move-result'):
                instructions,_,_=self.cfg(m.ref)
                index=next((n for n,i in enumerate(instructions) if i.offset==definition.offset),0)
                if index and '(' in instructions[index-1].ref:out.add(split_ref(instructions[index-1].ref)[2].split(')',1)[1])
            elif op.startswith('move') and len(definition.regs)>1:
                out.update(self.receiver_type_bounds(m,definition.regs[1],definition.offset,ctx,seen))
        return tuple(sorted(t for t in out if t and t.startswith(('L','['))))

    def source_distance(self,ref):
        if ref in self.source_distance_cache:return self.source_distance_cache[ref]
        front={ref};seen=set();distance=8
        for level in range(4):
            if any(r in self.source_methods and any(c.exported for c in self.roots(split_ref(r)[0])) for r in front):distance=level;break
            if level==0 and ref in self.source_methods:distance=4
            seen.update(front)
            front={s.method for r in sorted(front)[:32] for s in self.c.callers_of(r)}-seen
            if not front:break
        self.source_distance_cache[ref]=distance;return distance

    def roots(self,owner):
        if owner not in self.root_cache:
            self.root_cache[owner]=[c for c in self.p.components if c.enabled and self.p.is_subtype(c.code_class,owner)]
        return self.root_cache[owner]

    def trace(self,ref,reg,before,mode='value',ctx=0,depth=0):
        if not self.allowed(depth):return ()
        key=(ref,reg,before,mode,ctx)
        if key in self.memo:return self.memo[key]
        if key in self.active:return ()
        self.active.add(key);self.queries+=1;self.sink_queries+=1;self.visited.add(ref)
        m=self.p.methods.get(ref);results=[]
        if not m:self.active.remove(key);return ()
        for definition,guards in self.definitions(ref,reg,before):
            prefix=self.control_guards(ref,definition.offset if definition else before)
            if prefix is None:continue
            guards=guards|prefix
            token=self.context_tokens.get(ctx,'')
            if token:
                guards=frozenset((owner+':call_context:'+token if owner==ref else
                                  ref+':call_context:'+token+':exception' if owner==ref+':exception' else owner,
                                  branch,target) for owner,branch,target in guards)
            if definition is None:
                atoms=self.parameter(m,reg,mode,ctx,depth+1)
            else:
                atoms=self.definition(m,definition,reg,mode,ctx,depth+1)
            for atom in atoms:
                merged=replace(atom,guards=atom.guards|guards)
                if compatible(merged,Origin('','','',guards=guards)):results.append(merged)
        # Deduplicate semantic origin while retaining a shortest witness per guards.
        unique={}
        for atom in results:
            k=(atom.kind,atom.key,atom.typ,atom.entry,atom.value,atom.guards,atom.callback_instances,invocation_choices(atom))
            if k not in unique or len(atom.path)<len(unique[k].path):unique[k]=atom
        ordered=sorted(unique.values(),key=lambda a:(a.kind not in ('external_value','external_intent','bridge_parameter','web_navigation'),a.kind=='constant'))
        if len(ordered)>32:
            self.note('origin_alternative_limit',self.site(ref,before))
            # A single input's many branch variants must not crowd out every
            # other actual source. Keep one witness per semantic source first,
            # then round-robin additional guarded variants without merging them.
            groups={}
            for atom in ordered:
                semantic=(atom.kind,atom.key,atom.typ,atom.entry,atom.value,
                          atom.callback_instances,atom.path[:1])
                groups.setdefault(semantic,deque()).append(atom)
            queues=deque(groups.values());ordered=[]
            while queues and len(ordered)<32:
                queue=queues.popleft();ordered.append(queue.popleft())
                if queue:queues.append(queue)
        result=tuple(ordered);self.memo[key]=result;self.active.remove(key);return result

    def parameter(self,m,reg,mode,ctx,depth):
        if reg in self.context_origins.get(ctx,{}):return self.context_origins[ctx][reg]
        if reg in self.contexts.get(ctx,{}):
            ref,r,b,c=self.contexts[ctx][reg];return tuple(a.step('argument:'+m.ref) for a in self.trace(ref,r,b,mode,c,depth))
        formals=m.argument_registers()
        if reg not in formals:return ()
        index=formals.index(reg);instance='static' not in m.access.split();receiver=instance and index==0
        callback=webview_callbacks.parameter(self,m,index,mode,depth)
        if callback is not None:return callback
        delivery=livedata.parameter(self,m,index,mode,depth)
        if delivery is not None:return delivery
        if JS in m.annotations and 'public' in m.access.split() and not receiver and mode=='value':
            return (Origin('bridge_parameter',m.ref+':parameter:'+str(index),entry=m.ref,path=(m.ref+':parameter:'+str(index),)),)
        component_roots=self.roots(m.owner)
        if receiver and component_roots:
            return tuple(Origin('component','component:'+c.code_class,c.code_class,c.name,path=('component_instance:'+c.name,)) for c in component_roots)
        if not receiver:
            typ=parameters(m.descriptor)[index-(1 if instance else 0)]
            if typ==INTENT and m.name in ('onNewIntent','onReceive','onStartCommand'):
                return tuple(Origin('external_intent' if c.exported else 'internal_intent','intent:'+c.code_class,INTENT,c.name,path=(m.ref+':Intent_parameter',)) for c in component_roots)
        found=[]
        # A concrete callback's `this` is the constructed callback object.
        # Following every Function1.invoke/Runnable.run caller first conflates
        # unrelated callbacks with the same erased signature.
        runnable=receiver and m.name=='run' and m.descriptor=='()V' and self.p.is_subtype(m.owner,'Ljava/lang/Runnable;')
        if runnable:
            # Resolve the narrow, proven scheduler path before looking for
            # custom helpers. Never start by tracing every Runnable.run site.
            found.extend(self.registered_runnable_receivers(m,depth))
            previous=self.branch_query_limit
            remaining=max(0,self.per_sink_limit-self.sink_queries)
            self.branch_query_limit=min(previous if previous is not None else self.per_sink_limit,
                                        self.sink_queries+min(1024,max(64,remaining//4)))
            try:found.extend(self.direct_runnable_receivers(m,depth))
            finally:self.branch_query_limit=previous
            if not found:self.note('callback_registration_unresolved',m.ref)
            return tuple(found)
        if receiver and not runnable:
            effect=compose_effects.receivers(self,m,depth)
            if effect:return effect
            registered=compose_callbacks.receivers(self,m,depth)
            if registered:return registered
            if m.name not in ('<init>','invoke','invokeSuspend','run','resumeWith','emit'):
                direct=heap_context.receiver_calls(self,m,depth)
                if direct:return direct
            for initref in self.c.by_class.get(m.owner,()):
                if split_ref(initref)[1]!='<init>':continue
                for caller in self.c.callers_of(initref):
                    call=self.instruction(caller.method,caller.offset)
                    if call and call.regs:found.extend(self.trace(caller.method,call.regs[0],caller.offset,'object',0,depth))
            if found:
                if m.name in ('invoke','invokeSuspend','run','resumeWith','emit'):
                    self.note('constructed_callback_dispatch_unproven',m.ref)
                    return tuple(a.step('constructed_callback_dispatch_unproven:'+m.ref) for a in found)
                return tuple(found)
        generic_callback=m.name in ('invoke','invokeSuspend','run','resumeWith','emit')
        callers=self.c.callers_of(m.ref) if receiver or generic_callback else self.callers(m.ref)
        share=max(32,(self.per_sink_limit-self.sink_queries)//max(1,len(callers)))
        for caller in callers:
            call=self.instruction(caller.method,caller.offset)
            if not call:continue
            actual=self.actuals(call)
            if index<len(actual):
                caller_ctx=0
                # Reverse a setter/helper argument while retaining the same
                # component receiver. Do not transfer this constraint to calls
                # on another allocation or an arbitrary Activity parameter.
                pinned=self.context_origins.get(ctx,{}).get(formals[0],()) if instance else ()
                cm=self.p.methods[caller.method]
                if len(pinned)==1 and pinned[0].kind=='component' and not call.op.startswith('invoke-static') and actual:
                    if self.p.is_subtype(pinned[0].typ,cm.owner) and self.is_local_this(cm,actual[0],call.offset):
                        caller_ctx=self.component_context(cm,pinned[0])
                    else:
                        if not self.known_receiver_types(cm,actual[0],call.offset,0):
                            self.note('component_argument_receiver_unresolved',self.site(cm.ref,call.offset))
                        continue
                previous=self.branch_query_limit
                self.branch_query_limit=min(previous if previous is not None else self.per_sink_limit,self.sink_queries+share)
                allowed,receivers=self.reverse_dispatch_receivers(m,cm,call,caller_ctx,depth)
                if allowed and self.reachable(cm.ref,call.offset):
                    atoms=receivers if runnable and receivers else self.trace(caller.method,actual[index],caller.offset,mode,caller_ctx,depth)
                    for atom in atoms:
                        if runnable:
                            if atom.kind!='allocation':continue
                            atom=replace(atom,callback_instances=atom.callback_instances|{atom.key}).step('callback_invoked:'+self.site(cm.ref,call.offset))
                        if receivers and not runnable:
                            for base in receivers:
                                if compatible(atom,base):
                                    result=replace(atom,guards=atom.guards|base.guards)
                                    if base.kind=='conditional_dispatch':result=result.step(base.path[-1])
                                    found.append(result.step('argument:'+m.ref))
                        else:found.append(atom.step(heap_context.call_choice(self,m,cm,call,caller_ctx)).step('argument:'+m.ref))
                self.branch_query_limit=previous
        if found:return tuple(found)
        if receiver:
            # Framework-dispatched Runnable/coroutine/callback receiver: recover
            # concrete construction sites instead of traversing framework setup.
            if not found:
                # Relative receiver identity can connect only a field slot; it is
                # explicitly weaker than a proven allocation alias in reporting.
                return (Origin('relative_this','this:'+m.owner,m.owner,path=('unbound_receiver:'+m.ref,)),)
        else:self.note('unresolved_parameter',m.ref+':'+str(index))
        return tuple(found)

    def direct_runnable_receivers(self,m,depth):
        """Follow only helpers actually passed this callback allocation.

        Candidate discovery starts at construction, not every erased run()
        signature in the APK. The edge is emitted only at an actual invocation
        on the same receiver; storage in a queue is not an execution edge.
        """
        out=[];pending=[];seen=set()
        constructors=[ref for ref in self.c.by_class.get(m.owner,()) if split_ref(ref)[1]=='<init>']
        for ref in constructors:
            sites=self.c.callers_of(ref)
            if len(sites)>64:self.note('callback_constructor_fanout_limit',m.ref)
            for site in sites[:64]:
                call=self.instruction(site.method,site.offset)
                if not call or not call.regs:continue
                for base in self.trace(site.method,call.regs[0],call.offset,'object',0,depth):
                    if base.kind=='allocation' and base.typ==m.owner:
                        pending.append((site.method,site.offset,0,base,0))
        # Exact app-bytecode calls are cheap and do not require an inferred
        # registration. They also cover receivers returned from a factory.
        for site in self.c.callers_of(m.ref)[:64]:
            call=self.instruction(site.method,site.offset)
            if not call or not call.regs:continue
            cm=self.p.methods[site.method]
            valid,receivers=self.reverse_dispatch_receivers(m,cm,call,0,depth)
            if valid and self.reachable(cm.ref,call.offset):
                for base in receivers:
                    if base.kind=='allocation':
                        out.append(replace(base,callback_instances=base.callback_instances|{base.key}).step('callback_invoked:'+self.site(cm.ref,call.offset)))
        while pending and len(seen)<64 and self.allowed(depth):
            ref,after,ctx,base,hops=pending.pop(0)
            state=(ref,after,ctx,base.key)
            if state in seen:continue
            seen.add(state);method=self.p.methods[ref]
            for call in method.instructions:
                if call.offset<=after or not call.op.startswith('invoke-') or not call.ref:continue
                owner,name,desc=split_ref(call.ref)
                actual=self.actuals(call)
                if not actual:continue
                if name=='run' and desc=='()V' and call.op.startswith(('invoke-virtual','invoke-interface')):
                    valid,receivers=self.reverse_dispatch_receivers(m,method,call,ctx,depth+hops)
                    if valid and self.reachable(ref,call.offset):
                        for receiver in receivers:
                            if receiver.key==base.key and compatible(receiver,base):
                                out.append(replace(receiver,guards=receiver.guards|base.guards,
                                    callback_instances=receiver.callback_instances|{base.key}).step('callback_invoked:'+self.site(ref,call.offset)))
                    continue
                if name=='<init>':continue
                target=self.p.resolve(owner,name,desc)
                if not target or {'abstract','native'}.intersection(target.access.split()):continue
                types=parameters(desc);arguments=actual if call.op.startswith('invoke-static') else actual[1:]
                eligible=[arg for typ,arg in zip(types,arguments) if self.p.is_subtype(base.typ,typ)]
                if not eligible:continue
                matching=[]
                for arg in eligible:
                    matching.extend(a for a in self.trace(ref,arg,call.offset,'object',ctx,depth+hops)
                                    if a.key==base.key and compatible(a,base))
                if not matching:continue
                if hops>=4:
                    self.note('callback_helper_depth_limit',self.site(ref,call.offset));continue
                child=self.binding(ref,call,target,ctx)
                for atom in matching:pending.append((target.ref,-1,child,atom,hops+1))
        if pending:self.note('callback_helper_search_limit',m.ref)
        return tuple(out)

    def registered_runnable_receivers(self,m,depth):
        """Demand-resolve a concrete Runnable passed to a framework scheduler."""
        out=[];constructors=[r for r in self.c.by_class.get(m.owner,()) if split_ref(r)[1]=='<init>']
        for initref in constructors:
            sites=self.c.callers_of(initref)
            if len(sites)>64:self.note('callback_constructor_fanout_limit',m.ref)
            for site in sites[:64]:
                method=self.p.methods[site.method];init=self.instruction(site.method,site.offset)
                if not init or not init.regs:continue
                objects=self.trace(site.method,init.regs[0],site.offset,'object',0,depth)
                if len(objects)!=1 or objects[0].kind!='allocation':
                    self.note('callback_alias_unresolved',self.site(site.method,site.offset));continue
                for call in method.instructions:
                    if call.offset<=site.offset or not call.op.startswith('invoke-') or not call.ref:continue
                    owner,name,desc=split_ref(call.ref)
                    scheduler=(name in ('post','postDelayed') and desc.startswith('(Ljava/lang/Runnable;')
                               and (owner in ('Landroid/os/Handler;','Landroid/view/View;','Landroid/webkit/WebView;')
                                    or self.p.is_subtype(owner,'Landroid/view/View;')))
                    scheduler|=(name=='execute' and desc=='(Ljava/lang/Runnable;)V' and
                                owner in ('Ljava/util/concurrent/Executor;','Ljava/util/concurrent/ExecutorService;'))
                    if not scheduler:continue
                    if any(i.op.startswith(('if-','goto')) or i.op in ('packed-switch','sparse-switch','throw')
                           for i in method.instructions if site.offset<i.offset<call.offset):
                        self.note('conditional_callback_registration',self.site(site.method,call.offset));continue
                    actual=self.actuals(call)
                    if len(actual)<2:continue
                    submitted=self.trace(site.method,actual[1],call.offset,'object',0,depth)
                    if len(submitted)==1 and submitted[0].key==objects[0].key:
                        out.append(replace(objects[0],callback_instances=frozenset((objects[0].key,))).step('callback_registered:'+self.site(site.method,call.offset)))
                    elif any(a.key==objects[0].key for a in submitted):
                        self.note('callback_alias_unresolved',self.site(site.method,call.offset))
        return tuple(out)

    def definition(self,m,i,reg,mode,ctx,depth):
        site=self.site(m.ref,i.offset);r=i.regs;op=i.op
        wrap=lambda atoms:tuple(a.step(site+':'+op) for a in atoms)
        if op.startswith('move-result'):
            ins,_,_=self.cfg(m.ref);index=next(k for k,x in enumerate(ins) if x.offset==i.offset)
            if index:return wrap(self.result(m,ins[index-1],mode,ctx,depth))
            return ()
        if op.startswith('move') and len(r)>1:return wrap(self.trace(m.ref,r[1],i.offset,mode,ctx,depth))
        if op=='check-cast':return tuple(replace(a,typ=str(i.literal)) for a in self.trace(m.ref,r[0],i.offset,mode,ctx,depth))
        if op.startswith('const'):
            return (Origin('constant',str(i.literal),value=str(i.literal),path=(site,)),)
        if op=='new-instance':
            loop=any(j.target is not None and j.op.startswith(('goto','if-')) and j.target<=i.offset<=j.offset for j in m.instructions)
            if loop:self.note('loop_allocation_unresolved',site)
            if ctx==0:
                factory_allocations=compose_callbacks.allocation_origins(self,m,i,depth,'loop_allocation' if loop else 'allocation',str(i.literal))
                if factory_allocations is not None:return factory_allocations
            contexts=[ctx]
            if ctx==0 and 'static' not in m.access.split() and len(self.roots(m.owner))>1:
                contexts=[self.component_context(m,Origin('component','component:'+c.code_class,c.code_class,c.name)) for c in self.roots(m.owner)]
            return tuple(Origin('loop_allocation' if loop else 'allocation',self.allocation_key(m,i,c),str(i.literal),path=(site,)) for c in contexts)
        if op=='new-array':
            loop=any(j.target is not None and j.op.startswith(('goto','if-')) and j.target<=i.offset<=j.offset for j in m.instructions)
            if loop:self.note('loop_allocation_unresolved',site)
            return (Origin('loop_allocation' if loop else 'allocation',self.allocation_key(m,i,ctx),path=(site,)),)
        if op.startswith(('iget','sget')):
            if op.startswith('sget'):bases=(Origin('static','static'),)
            else:bases=self.trace(m.ref,r[1],i.offset,'object',ctx,depth)
            local=self.last_local_field_value(m,i,bases,mode,ctx,depth)
            if local is not None:return local
            out=[]
            # Explore proved object identities before weaker relative slots.
            # Keep every alternative; this only prevents weak receiver graphs
            # from consuming the slice before a concrete local witness.
            for base in sorted(bases,key=lambda base:base.kind not in ('allocation','component','static')):
                if base.kind in ('bridge_parameter','external_intent','external_value','internal_value') and mode=='value':
                    out.append(base.step(site+':field_of_external_object'));continue
                matched=False
                # Retain the direct local witness before spending the bounded
                # slice on unrelated global writers. This is only discovery
                # order: other writers and their diagnostics remain visible.
                writers=sorted(self.c.writers_of(i.ref),
                    key=lambda writer:(writer[0]!=m.ref,-writer[1] if writer[0]==m.ref else 0))
                for wref,woff in writers:
                    # A later write in this invocation cannot define this read;
                    # reject it before recursively discovering its receiver.
                    if wref==m.ref and woff>=i.offset:continue
                    writer=self.instruction(wref,woff)
                    if not writer:continue
                    wm=self.p.methods[wref]
                    writer_ctx=0
                    if base.kind=='component' and self.p.is_subtype(base.typ,wm.owner):
                        writer_ctx=self.component_context(wm,base)
                    # A known allocation already identifies its constructor
                    # call context. Replay that first: tracing the constructor's
                    # unbound receiver visits every other allocation of its class
                    # and can exhaust the slice before the exact capture is read.
                    contexts=heap_context.writer_contexts(self,base,wm,depth)
                    constructor_capture=bool(contexts)
                    if not constructor_capture:
                        if writer.op.startswith('sput'):wbases=(Origin('static','static'),)
                        else:wbases=self.trace(wref,writer.regs[1],woff,'object',writer_ctx,depth)
                        if not any((a.key==base.key or base.kind=='relative_this' and a.typ==base.typ) and compatible(a,base) for a in wbases):continue
                    if base.kind=='relative_this':self.note('relative_receiver_field_match',site)
                    matched=True
                    if not constructor_capture:contexts=[writer_ctx]
                    for wctx in contexts:
                        for a in self.trace(wref,writer.regs[0],woff,mode,wctx,depth):
                            if writer_ctx:a=a.step('component_context:'+base.typ+':'+wref)
                            if constructor_capture:
                                owner_proofs=self.trace(wref,writer.regs[1],woff,'object',wctx,depth) if writer.op.startswith('iput') else ()
                                for wb in owner_proofs:
                                    if wb.key!=base.key or not all((compatible(a,base),compatible(a,wb),compatible(base,wb))):continue
                                    joined=replace(a,path=a.path+base.path+wb.path,
                                        guards=a.guards|base.guards|wb.guards,
                                        callback_instances=a.callback_instances|base.callback_instances|wb.callback_instances)
                                    out.append(joined.step(site+':field_read:'+i.ref).step(site+':owned_initializer_field:'+i.ref))
                            else:
                                for wb in wbases:
                                    if not (wb.key==base.key or base.kind=='relative_this' and wb.typ==base.typ):continue
                                    if not all((compatible(a,base),compatible(a,wb),compatible(base,wb))):continue
                                    proof=a.path+base.path+wb.path
                                    if base.kind=='relative_this':proof+=('field_owner_instance_unproven:'+i.ref,)
                                    if base.kind in ('allocation','view_lookup','view') and wref!=m.ref:
                                        proof+=('field_writer_execution_unproven:'+i.ref,)
                                        self.note('field_writer_execution_unproven',site)
                                    joined=replace(a,path=proof,guards=a.guards|base.guards|wb.guards,
                                        callback_instances=a.callback_instances|base.callback_instances|wb.callback_instances)
                                    out.append(joined.step(site+':field_read:'+i.ref))
                if mode=='object' and (not matched or not out):
                    out.append(Origin('field_slot','field:'+base.key+':'+i.ref,typ=self.c.field_types.get(i.ref,self.field_type(i.ref)),entry=base.entry,path=base.path+(site+':field_slot',),guards=base.guards,callback_instances=base.callback_instances))
            return tuple(out)
        if op.startswith('aget'):
            # Exact local array transfer: same allocation, constant element,
            # straight-line code, and the last write to that element. Unknown
            # indices or control flow must not be silently merged.
            if len(r)>=3:
                prior=[j for j in m.instructions if j.offset<i.offset]
                if not any(j.op.startswith(('if-','goto')) or j.op in ('packed-switch','sparse-switch','throw') for j in prior):
                    arrays=self.trace(m.ref,r[1],i.offset,'object',ctx,depth)
                    idx=self.trace(m.ref,r[2],i.offset,'value',ctx,depth)
                    keys={a.key for a in arrays if a.kind=='allocation'}
                    indices={a.value for a in idx if a.kind=='constant'}
                    if len(keys)==1 and len(arrays)==1 and len(indices)==1 and len(idx)==1:
                        for writer in reversed(prior):
                            if not writer.op.startswith('aput') or len(writer.regs)<3:continue
                            targets=self.trace(m.ref,writer.regs[1],writer.offset,'object',ctx,depth)
                            if not any(a.kind=='allocation' and a.key in keys for a in targets):continue
                            write_indices=self.trace(m.ref,writer.regs[2],writer.offset,'value',ctx,depth)
                            if len(write_indices)!=1 or write_indices[0].kind!='constant':break
                            if write_indices[0].value==next(iter(indices)):
                                return wrap(self.trace(m.ref,writer.regs[0],writer.offset,mode,ctx,depth))
            self.note('array_slice_unresolved',site);return ()
        if op.startswith(('add-','sub-','mul-','div-','rem-','and-','or-','xor-','shl-','shr-','ushr-','neg-','int-to-','long-to-')):
            return wrap(tuple(a for rr in r[1:] for a in self.trace(m.ref,rr,i.offset,mode,ctx,depth)))
        self.note('unmodeled_definition',site+':'+op);return ()

    def last_local_field_value(self,m,read,bases,mode,ctx,depth):
        """Strong update only along a single predecessor chain on an exact owner.

        A call, join, loop, or ambiguous owner blocks this shortcut. Fall back
        to the ordinary alternatives rather than deleting uncertain writers.
        """
        if len(bases)!=1 or bases[0].kind not in ('allocation','component','static'):return None
        base=bases[0];_,byoff,pred=self.cfg(m.ref);at=read.offset;seen=set()
        while at not in seen and len(seen)<512:
            seen.add(at);parents=pred.get(at,())
            if len(parents)!=1 or parents[0][1] is not None:return None
            at=parents[0][0];writer=byoff[at]
            if writer.op.startswith(('invoke-','filled-new-array')):
                self.note('field_mutation_order_unresolved',self.site(m.ref,read.offset))
                return None
            if not writer.op.startswith(('iput','sput')) or writer.ref!=read.ref:continue
            targets=((Origin('static','static'),) if writer.op.startswith('sput') else
                     self.trace(m.ref,writer.regs[1],writer.offset,'object',ctx,depth))
            if not targets or any(a.kind not in ('allocation','component','static') for a in targets):return None
            if all(a.key!=base.key for a in targets):continue
            if len(targets)!=1 or not compatible(targets[0],base):return None
            guards=self.control_guards(m.ref,writer.offset)
            if guards is None:return None
            proof=replace(base,guards=base.guards|targets[0].guards|guards)
            out=[]
            for value in self.trace(m.ref,writer.regs[0],writer.offset,mode,ctx,depth):
                if compatible(value,proof):
                    out.append(replace(value,guards=value.guards|proof.guards,
                        callback_instances=value.callback_instances|proof.callback_instances,
                        path=value.path+base.path).step(self.site(m.ref,read.offset)+':last_field_write:'+self.site(m.ref,writer.offset)))
            return tuple(out)
        return None

    @staticmethod
    def field_type(ref):
        tail=ref.split('->',1)[-1]
        for k,ch in enumerate(tail):
            if ch in ('L','['):return tail[k:]
        return ''

    def receiver_arguments(self,m,receiver,before,ctx,depth):
        wanted={a.key for a in self.trace(m.ref,receiver,before,'object',ctx,depth)}
        result=[]
        for i in m.instructions:
            if i.offset>=before:break
            if not i.op.startswith('invoke-') or '-><init>(' not in i.ref or not i.regs:continue
            seen=self.trace(m.ref,i.regs[0],i.offset,'object',ctx,depth)
            if not wanted.intersection(a.key for a in seen):continue
            for rr in self.actuals(i)[1:]:result.extend(self.trace(m.ref,rr,i.offset,'value',ctx,depth))
        return tuple(result)

    def local_container_value(self,m,i,receiver,keyreg,ctx,depth,putters):
        """A single local allocation, constant key and last straight-line write."""
        site=self.site(m.ref,i.offset)
        prior=[j for j in m.instructions if j.offset<i.offset]
        if any(j.op.startswith(('if-','goto')) or j.op in ('packed-switch','sparse-switch','throw') for j in prior):
            self.note('container_slice_unresolved',site);return ()
        bases=self.trace(m.ref,receiver,i.offset,'object',ctx,depth)
        keys=self.trace(m.ref,keyreg,i.offset,'value',ctx,depth)
        if len(bases)!=1 or bases[0].kind!='allocation' or len(keys)!=1 or keys[0].kind!='constant':
            self.note('container_slice_unresolved',site);return ()
        for writer in reversed(prior):
            if not writer.op.startswith('invoke-') or not writer.ref or '(' not in writer.ref:continue
            owner,name,_=split_ref(writer.ref)
            if owner not in ('Landroid/os/Bundle;','Landroid/os/BaseBundle;') or not (name.startswith('put') or name in ('remove','clear')):continue
            actual=self.actuals(writer)
            if not actual:continue
            targets=self.trace(m.ref,actual[0],writer.offset,'object',ctx,depth)
            if not any(a.kind=='allocation' and a.key==bases[0].key for a in targets):continue
            if len(targets)!=1:
                self.note('container_slice_unresolved',site);return ()
            if name in ('clear','putAll') or len(actual)<2:
                self.note('container_slice_unresolved',site);return ()
            written=self.trace(m.ref,actual[1],writer.offset,'value',ctx,depth)
            if len(written)!=1 or written[0].kind!='constant':
                self.note('container_slice_unresolved',site);return ()
            if written[0].value==keys[0].value:
                if (owner,name) not in putters or len(actual)<3:
                    self.note('container_slice_unresolved',site);return ()
                return tuple(a.step(site+':container_key:'+keys[0].value) for a in
                             self.trace(m.ref,actual[2],writer.offset,'value',ctx,depth))
        return ()

    def result(self,m,i,mode,ctx,depth):
        if not i.ref or '(' not in i.ref:return ()
        formatted=string_format.result(self,m,i,mode,ctx,depth)
        if formatted is not None:return formatted
        mapped=keyed_maps.result(self,m,i,mode,ctx,depth)
        if mapped is not None:return mapped
        uri=uri_builder.result(self,m,i,mode,ctx,depth)
        if uri is not None:return uri
        routed=router_transfers.result(self,m,i,mode,ctx,depth)
        if routed is not None:return routed
        collection=collections_summary.result(self,m,i,mode,ctx,depth)
        if collection is not None:return collection
        view=view_state.result(self,m,i,mode,ctx,depth)
        if view is not None:return view
        lookup=view_lookup.result(self,m,i,mode,ctx,depth)
        if lookup is not None:return lookup
        state=state_summaries.result(self,m,i,mode,ctx,depth)
        if state is not None:return state
        callback=webview_callbacks.result(self,m,i,mode,ctx,depth)
        if callback is not None:return callback
        owner,name,desc=split_ref(i.ref);actual=self.actuals(i);static=i.op.startswith('invoke-static')
        receiver=actual[0] if actual and not static else None;args=actual if static else actual[1:]
        at=lambda rr,which=mode:self.trace(m.ref,rr,i.offset,which,ctx,depth)
        site=self.site(m.ref,i.offset)
        if name=='getIntent' and desc=='()Landroid/content/Intent;':
            roots=self.roots(m.owner)
            types=set(self.known_receiver_types(m,receiver,i.offset,ctx)) if receiver is not None else set()
            if types:roots=[c for c in self.p.components if c.enabled and c.code_class in types]
            if not roots and receiver is not None:
                types={a.typ for a in at(receiver,'object') if a.kind=='component'}
                roots=[c for c in self.p.components if c.enabled and c.code_class in types]
            return tuple(Origin('external_intent' if c.exported else 'internal_intent','intent:'+c.code_class,INTENT,c.name,path=(site,)) for c in roots)
        if owner==INTENT and name in ('getData','getDataString','getStringExtra','getCharSequenceExtra','getParcelableExtra','getBundleExtra','getExtras','getSelector'):
            origins=at(receiver,'value') if receiver is not None else ()
            if receiver is not None and any(a.kind=='allocation' and a.typ==INTENT for a in origins):
                origins=origins+self.receiver_arguments(m,receiver,i.offset,ctx,depth)
            out=[]
            for a in origins:
                if a.kind in ('internal_intent','external_intent'):
                    keys=at(args[0],'value') if args and name in intent_delivery.EXTRA_TYPES else ()
                    required_types=(at(args[1],'value') if name=='getParcelableExtra' and len(args)>1 else None)
                    delivered=intent_delivery.values(self,a,name,keys,site,required_types)
                    out.extend(delivered)
                    # An exported destination remains independently reachable
                    # even when an explicit caller also forwards a payload.
                    if a.kind=='external_intent':
                        out.append(replace(a,kind='external_value').step(site+':'+name))
                    elif not delivered:
                        out.append(replace(a,kind='internal_value').step(site+':'+name))
                elif a.kind in ('external_value','bridge_parameter'):
                    out.append(a.step(site+':'+name))
            return tuple(out)
        if owner in ('Landroid/os/Bundle;','Landroid/os/BaseBundle;') and name.startswith(('getString','getParcelable','getBundle','getCharSequence','getSerializable')):
            if receiver is None:return ()
            bases=at(receiver,'object')
            if any(a.kind=='allocation' for a in bases):
                if name=='getString' and args:
                    return self.local_container_value(m,i,receiver,args[0],ctx,depth,
                        {('Landroid/os/Bundle;','putString'),('Landroid/os/BaseBundle;','putString')})
                self.note('container_slice_unresolved',site);return ()
            return tuple(a.step(site+':Bundle_value') for a in at(receiver,'value'))
        if owner==INTENT and name=='setAction' and desc=='(Ljava/lang/String;)Landroid/content/Intent;' and receiver is not None:
            # Fluent identity only; the action's value is not a validation proof.
            return at(receiver,mode)
        if owner==INTENT and name in ('putExtra','putExtras','setClass','setClassName','setComponent','setData','setDataAndType','addFlags','setFlags') and receiver is not None:
            return at(receiver,mode)
        if owner=='Ljava/lang/Class;' and name=='cast' and desc=='(Ljava/lang/Object;)Ljava/lang/Object;' and args:
            return tuple(a.step(site+':class_cast') for a in at(args[0],mode))
        if name=='getSettings' and desc=='()Landroid/webkit/WebSettings;' and self.p.is_subtype(owner,WV) and receiver is not None and mode=='object':
            return tuple(Origin('settings','settings:'+a.key,'Landroid/webkit/WebSettings;',a.entry,
                                path=a.path+(site+':webview_settings',)) for a in at(receiver,'object')
                         if a.kind in ('allocation','view','field_slot','component'))
        if owner.startswith('Lkotlinx/serialization/json/') and name in ('parseToJsonElement','get','getContent','getJsonObject','getJsonPrimitive','getContentOrNull'):
            regs=args[:1] if static or name=='parseToJsonElement' else ([receiver] if receiver is not None else [])
            return tuple(a.step(site+':json_value') for rr in regs for a in at(rr,'value'))
        if owner=='Lkotlin/Result;' and name in ('constructor-impl','box-impl','unbox-impl'):
            regs=args[:1] if static else ([receiver] if receiver is not None else [])
            return tuple(a.step(site+':result_value') for rr in regs for a in at(rr,'value'))
        if owner.startswith('Lkotlin/text/') and name in ('trimIndent','trimMargin','replace','replace$default','replaceFirst','replaceFirst$default','substringAfter','substringBefore','toString'):
            return tuple(a.step(site+':text_transform') for rr in args[:1] for a in at(rr,'value'))
        if owner in ('Ljava/net/URLDecoder;','Ljava/net/URLEncoder;') and name in ('decode','encode'):
            return tuple(a.step(site+':url_transform') for rr in args[:1] for a in at(rr,'value'))
        if owner in ('Ljava/lang/StringBuilder;','Ljava/lang/StringBuffer;'):
            if name=='append' and receiver is not None:return at(receiver,'object' if mode=='object' else 'value')
            if name=='toString' and receiver is not None:
                wanted={a.key for a in at(receiver,'object')};out=list(self.receiver_arguments(m,receiver,i.offset,ctx,depth))
                for prev in m.instructions:
                    if prev.offset>=i.offset:break
                    if '->append(' not in prev.ref or not prev.regs:continue
                    if wanted.intersection(a.key for a in self.trace(m.ref,prev.regs[0],prev.offset,'object',ctx,depth)):
                        for rr in self.actuals(prev)[1:]:out.extend(self.trace(m.ref,rr,prev.offset,'value',ctx,depth))
                return tuple(a.step(site+':string_build') for a in out)
        if owner.startswith(('Ljava/lang/String;','Landroid/net/Uri;','Ljava/net/URL;','Ljava/net/URI;')) and name in ('toString','parse','valueOf','concat','substring','getQueryParameter','getFragment','getPath','getHost','getScheme','decode','encode','replace','trim','toLowerCase','toUpperCase','toExternalForm'):
            regs=args if static else ([receiver] if receiver is not None else [])+args
            return tuple(a.step(site+':text_transform') for rr in regs for a in at(rr,'value'))
        if owner in ('Lorg/json/JSONObject;','Lorg/json/JSONArray;') and name in ('getString','optString','get','opt','getJSONObject','optJSONObject') and receiver is not None:
            return tuple(a.step(site+':json_field') for a in self.receiver_arguments(m,receiver,i.offset,ctx,depth))
        if name=='fromJson' and owner.startswith(('Lcom/google/gson/','Lcom/fasterxml/')):
            return tuple(a.step(site+':json_decode') for rr in args[:1] for a in at(rr,'value'))
        targets=[]
        # Retain concrete this/parameter types through component contexts and
        # local allocations, without recursively expanding receiver graphs.
        concrete=()
        if receiver is not None and i.op.startswith(('invoke-virtual','invoke-interface')):
            types=self.known_receiver_types(m,receiver,i.offset,ctx)
            if len(types)==1 and self.p.is_subtype(types[0],owner):concrete=types
        target=self.p.resolve(concrete[0] if concrete else owner,name,desc)
        if target and 'abstract' not in target.access.split() and 'native' not in target.access.split():targets=[target]
        if not targets:
            possibles=[]
            for ref in self.c.by_signature.get((name,desc),()):
                method=self.p.methods[ref]
                if self.p.is_subtype(method.owner,owner) and not {'abstract','native'}.intersection(method.access.split()):possibles.append(method)
            prefix=m.owner.rsplit('/',1)[0]
            possibles.sort(key=lambda target:(not target.owner.startswith(prefix),target.ref))
            if len(possibles)>16:self.note('virtual_dispatch_limit',site+':'+i.ref)
            targets=possibles[:16]
        out=[]
        for target in targets[:16]:
            child=self.binding(m.ref,i,target,ctx)
            for ret in target.instructions:
                if ret.op.startswith('return') and ret.regs:
                    out.extend(a.step(site+':return_from:'+target.ref) for a in self.trace(target.ref,ret.regs[0],ret.offset,mode,child,depth))
        if not targets:self.note('unmodeled_return',site+':'+i.ref)
        return tuple(out)

    def is_webview_api(self,site):
        owner,name,desc=split_ref(site.target)
        return self.p.is_subtype(owner,WV) and (name in ('loadUrl','postUrl','loadData','loadDataWithBaseURL','evaluateJavascript','addJavascriptInterface','removeJavascriptInterface'))

    def nonnull_receivers(self, atoms, site):
        kept=tuple(a for a in atoms if not (a.kind=='constant' and a.value=='0'))
        if len(kept)!=len(atoms):self.note('null_receiver_alternative_discarded',site)
        return kept

    @staticmethod
    def receiver_resolution(atoms):
        if atoms and all(any('field_owner_instance_unproven:' in p or 'field_writer_execution_unproven:' in p for p in a.path) or a.kind in ('field_slot','constructor_receiver','relative_this','view_lookup') for a in atoms):return 'possible_identity'
        if any(a.kind in ('allocation','view','component') for a in atoms):return 'abstract_identity'
        if any(a.kind in ('field_slot','constructor_receiver','relative_this','view_lookup') for a in atoms):return 'possible_identity'
        return 'unresolved'

    def object_aliases(self,left,right):
        result=[]
        for a in left:
            for b in right:
                if a.key!=b.key or a.kind not in ('allocation','view','field_slot','component','constructor_receiver','view_lookup') or b.kind not in ('allocation','view','field_slot','component','constructor_receiver','view_lookup') or not compatible(a,b):continue
                relation=('same_field_slot_possible_instance' if any('field_owner_instance_unproven:' in p or 'field_writer_execution_unproven:' in p for atom in (a,b) for p in atom.path) else
                          'same_lookup_result_possible_instance' if 'view_lookup' in (a.kind,b.kind) else
                          'same_constructor_receiver_possible_instance' if 'constructor_receiver' in (a.kind,b.kind) else
                          'same_field_slot_possible_instance' if 'field_slot' in (a.kind,b.kind) else 'same_abstract_object')
                result.append({'key':a.key,'relation':relation,
                               'left_proof':list(a.path),'right_proof':list(b.path)})
        return list({json.dumps(item,sort_keys=True):item for item in result}.values())

    def javascript_state(self,ref,offset,webviews):
        """Resolve only an unambiguous, straight-line setting on this WebView.

        A setter in another method, across a branch, or on an uncertain field
        alias is left unknown. This avoids turning mere API co-occurrence into
        an enablement claim.
        """
        if not any(a.kind in ('allocation','view') for a in webviews):
            return {'state':'unknown','setting_site':None}
        method=self.p.methods[ref]
        prior=[i for i in method.instructions if i.offset<offset]
        if any(i.op.startswith(('if-','goto')) or i.op in ('packed-switch','sparse-switch','throw') for i in prior):
            return {'state':'unknown','setting_site':None}
        keys={'settings:'+a.key for a in webviews if a.kind in ('allocation','view')}
        if len(keys)!=1 or len(webviews)!=1:
            return {'state':'unknown','setting_site':None}
        matched=[]
        for i in prior:
            if not i.ref.startswith('Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V') or len(i.regs)<2:
                continue
            settings=self.trace(ref,i.regs[0],i.offset,'object')
            if not any(a.kind=='settings' and a.key in keys for a in settings):continue
            if len(settings)!=1 or settings[0].kind!='settings':
                matched.append((i,set(),False));continue
            values=self.trace(ref,i.regs[1],i.offset,'value')
            states={a.value for a in values if a.kind=='constant'}
            matched.append((i,states,bool(values) and all(a.kind=='constant' for a in values)))
        if not matched:return {'state':'unknown','setting_site':None}
        i,states,known=matched[-1]
        state=('true' if states=={'1'} else 'false' if states=={'0'} else 'unknown') if known else 'unknown'
        return {'state':state,'setting_site':self.site(ref,i.offset)}

    def removed_before(self,reg,load,receiver):
        if reg['method']!=load.method or reg['offset']>=load.offset:return False
        middle=[i for i in self.p.methods[load.method].instructions if reg['offset']<i.offset<load.offset]
        if any(i.op.startswith(('if-','goto','return','throw')) or i.op in ('packed-switch','sparse-switch') for i in middle):return False
        for i in middle:
            if not i.ref.startswith(WV+'->removeJavascriptInterface(') or len(i.regs)<2:continue
            names={a.value for a in self.trace(load.method,i.regs[1],i.offset) if a.kind=='constant'}
            if not names.intersection(reg['names']):continue
            other=self.trace(load.method,i.regs[0],i.offset,'object')
            if self.object_aliases(receiver,other):return True
        return False

    def validation_checks(self,origin):
        checks=[]
        for ref,offset,target in sorted(origin.guards):
            if ref.endswith(':exception'):continue
            ref=ref.split(':call_context:',1)[0]
            ins,byoff,_=self.cfg(ref);branch=byoff.get(offset)
            if not branch or branch.op not in ('if-eqz','if-nez'):continue
            index=next(k for k,i in enumerate(ins) if i.offset==offset)
            definitions=self.definitions(ref,branch.regs[0],offset)
            defs=[i for i,_ in definitions if i and i.op.startswith('move-result')]
            if len(defs)!=1:continue
            result_index=next(k for k,i in enumerate(ins) if i.offset==defs[0].offset)
            if not result_index:continue
            call=ins[result_index-1]
            if not call.ref or not any(x in call.ref for x in ('->areEqual(','->equals(')):continue
            constants=[value for rr in self.actuals(call) for ok,value in [self.local_constant(ref,rr,call.offset)] if ok and isinstance(value,str)]
            if len(constants)!=1:continue
            equal=(target!=branch.target) if branch.op=='if-eqz' else (target==branch.target)
            checks.append({'kind':'constant_equality','site':self.site(ref,call.offset),'value':constants[0],
                           'required_result':equal,'scope':'Constraint on this witness; not a general sanitization proof.'})
        return checks

    def exposure(self,objects):
        types={a.typ for a in objects if a.typ in self.p.supers}
        methods={}
        for typ in types:
            seen=set();current=typ
            while current and current not in seen:
                seen.add(current)
                for ref in self.c.by_class.get(current,()):
                    m=self.p.methods[ref];signature=(m.name,m.descriptor)
                    if signature in methods:continue
                    methods[signature]=m
                current=self.p.supers.get(current,'')
        result=[]
        for m in methods.values():
            if 'public' not in m.access.split() or m.name.startswith('<'):continue
            if JS in m.annotations or self.p.target_sdk is None or self.p.target_sdk<17:result.append(m.ref)
        return {'types':sorted(types),'methods':sorted(result),'unresolved_type':not types,
                'legacy_runtime_possible':self.p.min_sdk is None or self.p.min_sdk<17}

    def registration(self,site):
        self.reset();i=self.instruction(site.method,site.offset)
        if not i or len(i.regs)<3 or not self.reachable(site.method,site.offset):return None
        objects=self.trace(site.method,i.regs[1],site.offset,'object')
        names=self.trace(site.method,i.regs[2],site.offset,'value')
        receiver=self.trace(site.method,i.regs[0],site.offset,'object')
        receiver=webview_callbacks.constructor_receiver(self,self.p.methods[site.method],i.regs[0],site.offset,receiver)
        receiver=self.nonnull_receivers(receiver,self.site(site.method,site.offset))
        return {'id':'registration:'+self.site(site.method,site.offset),'site':self.site(site.method,site.offset),
                'method':site.method,'offset':site.offset,'receiver':[a.dump() for a in receiver],
                'objects':[a.dump() for a in objects],'names':sorted({a.value for a in names if a.kind=='constant'}),
                'exposure':self.exposure(objects),'_receiver':receiver,'_objects':objects,'_names':names}

    def registration_witness(self,source,receivers,reg):
        """Join all operands under compatible choices, not exposure inventory.

        A bridge class existing on another branch cannot supply the callable
        surface of a null/unresolved object on this source's loading path.
        """
        aliases=[];views=[];objects=[];names=[]
        for load in receivers:
            if not compatible(load,source):continue
            for registered in reg['_receiver']:
                if not compatible(registered,source):continue
                relation=self.object_aliases((load,),(registered,))
                if not relation:continue
                for bridge in reg['_objects']:
                    if not all(compatible(bridge,v) for v in (source,load,registered)):continue
                    exposure=self.exposure((bridge,))
                    if not exposure['methods']:continue
                    choices=[v for v in reg['_names'] if all(compatible(v,o) for o in (source,load,registered,bridge))]
                    if reg['_names'] and not choices:continue
                    aliases.extend(relation);views.append(registered);objects.append(bridge);names.extend(choices)
        public={k:v for k,v in reg.items() if not k.startswith('_')}
        public.update(receiver=[a.dump() for a in dict.fromkeys(views)],
                      objects=[a.dump() for a in dict.fromkeys(objects)],
                      exposure=self.exposure(objects),
                      names=sorted({a.value for a in names if a.kind=='constant'}))
        return list({json.dumps(a,sort_keys=True):a for a in aliases}.values()),public

    def discover_forwarders(self):
        # Only callsites of startActivity are inspected, not every entry lifecycle.
        # First select methods that wrap external nested-Intent reads. Expanding
        # arbitrary startActivity arguments follows unrelated app navigation.
        relevant=set();front=set()
        for (name,desc),targets in self.c.call_signatures.items():
            if name in ('getParcelableExtra','getSelector','getParcelable','getStringExtra','getDataString','getData'):
                for ref in targets:front.update(s.method for s in self.c.callers_of(ref))
        for _ in range(6):
            new=front-relevant;relevant.update(new);front=set()
            for ref in new:front.update(s.method for s in self.c.callers_of(ref))
        refs=set()
        for (name,desc),targets in self.c.call_signatures.items():
            if name=='startActivity' and desc.startswith('(Landroid/content/Intent;'):refs.update(targets)
        dispatch_sites=[site for ref in refs for site in self.c.callers_of(ref)]
        # The external nested-Intent handoff should be visited before the many
        # unrelated navigation calls in large applications.
        dispatch_sites.sort(key=lambda site:(site.method not in relevant,
            site.method not in self.source_methods,
            self.source_distance(site.method),site.method,site.offset))
        for site in dispatch_sites:
                near={site.method};front={site.method}
                for _ in range(3):
                    if near&relevant:break
                    front={s.method for method in front for s in self.c.callers_of(method)}-near
                    near.update(front)
                if not near&relevant:continue
                self.reset()
                if not self.allowed(0):return
                self.reset();i=self.instruction(site.method,site.offset);actual=self.actuals(i)
                if len(actual)<2:continue
                values=self.trace(site.method,actual[1],site.offset,'value')
                for a in values:
                    if a.kind=='external_value' and any('getParcelableExtra' in x or 'getSelector' in x or 'Bundle_value' in x for x in a.path):
                        self.forwarders.append({'site':self.site(site.method,site.offset),'source':a.dump(),
                            'classification':'conditional_intent_forwarding','assumptions':['The external sender may select an explicit internal target; target/flag restrictions and runtime policy require review.']})
                objects=self.trace(site.method,actual[1],site.offset,'object')
                keys={a.key for a in objects if a.kind=='allocation' and a.typ==INTENT}
                if not keys:continue
                allocation_methods={a.key.rsplit('@',1)[0] for a in objects if a.kind=='allocation' and a.typ==INTENT}
                for allocation_ref in allocation_methods:
                    self.intent_payloads(allocation_ref,keys,site)

    def intent_payloads(self,allocation_ref,keys,dispatch):
        method=self.p.methods.get(allocation_ref)
        if not method:return
        instructions=[i for i in method.instructions if not dispatch or method.ref!=dispatch.method or i.offset<dispatch.offset]
        instructions.sort(key=lambda i:(0 if '-><init>(' in i.ref or '->setClass(' in i.ref else 1 if '->setData(' in i.ref else 2,i.offset))
        summaries=[]
        # Targets and payloads belong to one allocation in one calling context.
        # Combining them across factory calls can invent an ICC delivery.
        for key in sorted(keys):
            origin_method,ctx=self.allocation_contexts.get(key,(key.rsplit('@',1)[0],0))
            if origin_method!=allocation_ref:continue
            targets=[];extras=[]
            for prev in instructions:
                if not prev.op.startswith('invoke-') or not prev.regs or not prev.ref.startswith(INTENT+'->'):continue
                pa=self.actuals(prev)
                if not any(a.key==key for a in self.trace(method.ref,pa[0],prev.offset,'object',ctx)):continue
                _,pname,pdesc=split_ref(prev.ref)
                formal_types=parameters(pdesc)
                if pname in ('<init>','setClass'):
                    # Only the declared Class operand supplies a destination.
                    # Keep its provenance/conditions instead of reducing it to
                    # an unqualified class-name set (e.g. a Map metadata read).
                    for index,typ in enumerate(formal_types,1):
                        if typ!='Ljava/lang/Class;' or index>=len(pa):continue
                        for atom in self.trace(method.ref,pa[index],prev.offset,ctx=ctx):
                            if atom.kind=='constant' and atom.value.startswith('L') and atom.value.endswith(';'):
                                targets.append((atom,{'site':self.site(method.ref,prev.offset),
                                    'operand_index':index,'origin':atom.dump()}))
                if pname=='putExtra' and len(pa)>=3:
                    names={a.value for a in self.trace(method.ref,pa[1],prev.offset,ctx=ctx) if a.kind=='constant'}
                    sources=[a for a in self.trace(method.ref,pa[2],prev.offset,ctx=ctx) if a.kind=='external_value']
                    payload_type=formal_types[1] if len(formal_types)>1 else ''
                    extras.extend((name,source,payload_type) for name in names for source in sources)
                if pname=='setData' and len(pa)>=2:
                    extras.extend(('',a,formal_types[0] if formal_types else '') for a in self.trace(method.ref,pa[1],prev.offset,ctx=ctx) if a.kind=='external_value')
            for target,evidence in targets:
                for extra,source,payload_type in extras:
                    if not compatible(source,target):continue
                    delivered=replace(source,guards=source.guards|target.guards,
                                      callback_instances=source.callback_instances|target.callback_instances)
                    summary={'site':self.site(dispatch.method,dispatch.offset) if dispatch else method.ref+':return_intent','source':delivered.dump(),'target_class':target.value,'extra_key':extra,
                        'payload':'extra' if extra else 'data','payload_type':payload_type,
                        'target_evidence':[evidence],'classification':'explicit_intent_payload_forwarding',
                        'factory_method':method.ref,'assumptions':['Component lifecycle dispatch is modeled; Android runtime delivery is not executed.']}
                    summaries.append(summary)
                    if dispatch:self.forwarders.append(summary)
        return summaries

    def target_forwarders(self,target):
        if target in self.target_scanned:return
        self.target_scanned.add(target)
        refs={ref for ref,_ in self.c.literal_users(target)}
        for ref in sorted(refs,key=lambda r:(self.source_distance(r),r)):
            self.reset()
            if not self.allowed(0):return
            method=self.p.methods[ref]
            keys={self.site(ref,i.offset) for i in method.instructions if i.op=='new-instance' and i.literal==INTENT}
            if not keys:continue
            summaries=[s for s in self.intent_payloads(ref,keys,None) or () if s['target_class']==target]
            if not summaries:continue
            # Find actual startActivity uses of a returned Intent allocation.
            front={ref};seen=set();dispatches=[]
            for _ in range(8):
                if not self.allowed(0):break
                next_front=set()
                for ancestor in sorted(front,key=lambda r:(self.source_distance(r),r))[:32]:
                    if ancestor in seen:continue
                    seen.add(ancestor)
                    for i in self.p.methods[ancestor].instructions:
                        if '->startActivity(' not in i.ref or not i.regs:continue
                        actual=self.actuals(i)
                        if len(actual)<2:continue
                        matching={a.key for a in self.trace(ancestor,actual[1],i.offset,'object')
                                  if a.kind=='allocation' and a.key.split(':call_context:',1)[0] in keys}
                        if matching:dispatches.append((ancestor,i.offset,matching))
                    next_front.update(s.method for s in self.callers(ancestor))
                if dispatches:break
                front=next_front-seen
                if not front:break
            if not dispatches:
                self.factory_paths.extend(dict(summary,classification='intent_factory_payload_dispatch_unresolved') for summary in summaries)
            for dispatch_ref,offset,matching in dispatches:
                for summary in self.intent_payloads(ref,matching,None) or ():
                    if summary['target_class']==target:
                        self.forwarders.append(dict(summary,site=self.site(dispatch_ref,offset),dispatch_proof='Returned Intent allocation reaches startActivity operand'))

    def run(self):
        inventory=[s for s in self.c.inventory if self.is_webview_api(s)]
        # Registration seeds stay available when a user focuses a loading method.
        if self.focus_methods:
            inventory=[s for s in inventory if '->addJavascriptInterface(' in s.target or any(f in s.method for f in self.focus_methods)]
            self.per_sink_limit=max(100,min(20000,self.limits.max_steps//max(1,len(inventory))))
            self.seed_seconds=max(0.1,self.limits.timeout_seconds/max(1,len(inventory)))
        registrations=[];loads=[];evaluations=[];registration_coverage=[]
        # Each seed receives an independent slice budget, preventing one entry's
        # lifecycle setup from starving the rest of the API catalog.
        for site in inventory:
            if '->addJavascriptInterface(' not in site.target:continue
            self.reset()
            if not self.allowed(0):
                registration_coverage.append({'site':self.site(site.method,site.offset),'status':'unvisited_budget','diagnostic_codes':sorted({x[0] for x in self.seed_notes})})
                continue
            reg=self.registration(site)
            if reg:registrations.append(reg)
            registration_coverage.append({'site':self.site(site.method,site.offset),
                                          'status':'sliced_incomplete' if self.seed_notes else 'sliced_complete',
                                          'diagnostics':self.seed_diagnostics(),
                                          'diagnostic_codes':sorted({x[0] for x in self.seed_notes})})
        self.phase_deadline=time.monotonic()+min(18,self.limits.timeout_seconds*0.25)
        self.seed_notes.clear()
        self.phase_notes.clear()
        self.discover_forwarders()
        prepass_diagnostics=sorted({x[0] for x in self.phase_notes})
        self.phase_deadline=None
        candidates=[];input_paths=[];bridge_js=[];unresolved=[]
        for site in inventory:
            _,name,_=split_ref(site.target)
            if name not in ('loadUrl','postUrl','loadData','loadDataWithBaseURL','evaluateJavascript'):continue
            self.reset()
            if not self.allowed(0):
                self.coverage.append({'site':self.site(site.method,site.offset),'status':'unvisited_budget',
                                      'diagnostic_codes':sorted({x[0] for x in self.seed_notes})});continue
            before=self.sink_queries;i=self.instruction(site.method,site.offset)
            if not i or not i.regs:
                self.note('seed_instruction_unresolved',self.site(site.method,site.offset))
                self.coverage.append({'site':self.site(site.method,site.offset),'status':'sliced_incomplete',
                                      'diagnostics':self.seed_diagnostics(),
                                      'diagnostic_codes':sorted({x[0] for x in self.seed_notes})});continue
            if not self.reachable(site.method,site.offset):
                self.coverage.append({'site':self.site(site.method,site.offset),'status':'unreachable_constant_branch',
                                      'diagnostic_codes':sorted({x[0] for x in self.seed_notes})});continue
            receiver=None
            indexes=[0,1] if name in ('loadDataWithBaseURL','postUrl') else [0]
            for argindex in indexes:
                if len(i.regs)<=argindex+1:continue
                values=self.trace(site.method,i.regs[argindex+1],site.offset,'value')
                if receiver is None:
                    receiver=self.nonnull_receivers(self.trace(site.method,i.regs[0],site.offset,'object'),self.site(site.method,site.offset))
                    if not receiver:self.note('loading_receiver_unresolved',self.site(site.method,site.offset))
                external=[a for a in values if a.kind in ('external_value','web_navigation')]
                js=[a for a in values if a.kind=='bridge_parameter']
                record={'site':self.site(site.method,site.offset),'method':site.method,'offset':site.offset,'api':name,'argument_index':argindex,
                        'receiver':[a.dump() for a in receiver],'receiver_resolution':self.receiver_resolution(receiver),'origins':[a.dump() for a in values],
                        'javascript_enabled':self.javascript_state(site.method,site.offset,receiver)}
                script_prefix=javascript_url_evidence(self,site.method,i.regs[argindex+1],site.offset) if name=='loadUrl' and js else None
                if name=='loadUrl' and js and script_prefix is None:
                    self.note('javascript_scheme_unresolved',self.site(site.method,site.offset))
                script_execution=name=='evaluateJavascript' or script_prefix is not None
                if script_prefix:record['javascript_scheme_evidence']=script_prefix
                (evaluations if script_execution else loads).append(record)
                matched=False
                if not script_execution:
                    for source in external:
                        compatible_receivers=tuple(a for a in receiver if compatible(a,source))
                        source_record=dict(record,receiver=[a.dump() for a in compatible_receivers],receiver_resolution=self.receiver_resolution(compatible_receivers),origins=[source.dump()])
                        input_path={'classification':'external_input_to_webview_candidate','entry_component':source.entry,'source':source.dump(),'load':source_record,
                                    'assumptions':['Branch feasibility, URL control/validation, scheduling and runtime content loading are not proven.']+
                                    (['WebViewClient URL/request parameters are web-navigation inputs; OS Intent control and external attacker control are not established.',
                                      'Callback dispatch is linked to a concrete setWebViewClient registration; actual navigation and registration lifetime require review.']
                                     if source.kind=='web_navigation' else [])}
                        input_paths.append(input_path)
                        for reg in registrations:
                            if self.removed_before(reg,site,compatible_receivers):continue
                            aliases,bridge=self.registration_witness(source,compatible_receivers,reg)
                            if not aliases:continue
                            matched=True
                            candidates.append({'classification':'external_input_webview_bridge_candidate','entry_component':source.entry,'source':source.dump(),
                                'load':source_record,'bridge':bridge,'object_relations':aliases,
                                'assumptions':input_path['assumptions']+['Registration/page reload order requires review.']+
                                (['JavaScript is explicitly disabled before this load in the modeled straight-line method.'] if record['javascript_enabled']['state']=='false' else
                                 ['JavaScript enablement is unresolved.'] if record['javascript_enabled']['state']=='unknown' else [])})
                else:
                    for source in js:
                        compatible_receivers=tuple(a for a in receiver if compatible(a,source))
                        source_record=dict(record,receiver=[a.dump() for a in compatible_receivers],receiver_resolution=self.receiver_resolution(compatible_receivers),origins=[source.dump()])
                        for reg in registrations:
                            aliases,bridge=self.registration_witness(source,compatible_receivers,reg)
                            if not aliases or source.entry not in bridge['exposure']['methods']:continue
                            matched=True
                            checks=self.validation_checks(source)
                            callback_guards=[check for check in checks if check['kind']=='constant_equality' and check['required_result']]
                            bridge_js.append({'classification':'bridge_parameter_to_javascript_guarded_witness' if callback_guards else 'bridge_parameter_to_javascript_candidate',
                                'bridge_method':source.entry,'source':source.dump(),
                                'javascript_execution':source_record,'bridge':bridge,'object_relations':aliases,
                                'validation_checks':checks,'callback_constraints':callback_guards,
                                'assumptions':['JavaScript Bridge parameters are web-content inputs, not OS Intent inputs.','Cross-origin iframe presence, callback restrictions, exploitability and native impact require independent review.']})
                if not matched:unresolved.append(record)
            self.coverage.append({'site':self.site(site.method,site.offset),
                                  'status':'sliced_incomplete' if self.seed_notes else 'sliced_complete',
                                  'queries':self.sink_queries-before,
                                  'diagnostics':self.seed_diagnostics(),
                                  'diagnostic_codes':sorted({x[0] for x in self.seed_notes})})
        def identify(items):
            out={}
            for item in items:
                sink=item.get('load',item.get('javascript_execution',{}));bridge=item.get('bridge',{})
                identity=(item['classification'],item['source']['key'],sink.get('site'),sink.get('argument_index'),bridge.get('site'),
                    item['source'].get('branch_choices',[]),item['source'].get('callback_instances',[]),
                    item['source'].get('invocation_choices',[]),
                    [(a['kind'],a['key'],a['branch_choices'],a['callback_instances'],a.get('invocation_choices',[])) for a in sink.get('receiver',[])])
                key=hashlib.sha256(json.dumps(identity).encode()).hexdigest()[:16]
                if key not in out:out[key]=dict(item,id='DOTORI-'+key,alternative_proof_count=1)
                else:
                    old=out[key];count=old['alternative_proof_count']+1
                    if len(item['source']['path'])<len(old['source']['path']):out[key]=dict(item,id='DOTORI-'+key)
                    out[key]['alternative_proof_count']=count
            return [out[k] for k in sorted(out)]
        candidates=identify(candidates);input_paths=identify(input_paths);bridge_js=identify(bridge_js)
        diagnostics=[dict(d,kind=diagnostic_kind(d['code'])) for d in self.p.diagnostics]+[
            {'code':c,'detail':d,'kind':diagnostic_kind(c)} for c,d in sorted(self.notes)]
        review_summary=annotate_paths({'candidates':candidates,'input_webview_paths':input_paths,
                                      'bridge_javascript_paths':bridge_js},self.coverage,registration_coverage)
        completion={'loading_sites':len(self.coverage),
                    'loading_sliced_complete':sum(c['status']=='sliced_complete' for c in self.coverage),
                    'loading_sliced_incomplete':sum(c['status']=='sliced_incomplete' for c in self.coverage),
                    'loading_unvisited':sum(c['status']=='unvisited_budget' for c in self.coverage),
                    'bridge_registration_sites':len(registration_coverage),
                    'bridge_registrations_sliced_complete':sum(c['status']=='sliced_complete' for c in registration_coverage),
                    'bridge_registrations_sliced_incomplete':sum(c['status']=='sliced_incomplete' for c in registration_coverage),
                    'forwarding_prepass_diagnostic_codes':prepass_diagnostics,
                    'apk_parse_diagnostic_count':len(self.p.diagnostics)}
        return {'schema_version':'2.1','tool':{'name':'DOTORI','version':__version__},
            'input':{'package':self.p.package,'sha256':self.p.sha256,'target_sdk':self.p.target_sdk,'min_sdk':self.p.min_sdk,'dex_count':self.p.dex_count},
            'analysis_selection':{'focus_methods':list(self.focus_methods),'scope':'all_webview_api_sites' if not self.focus_methods else 'selected_loading_sites_and_all_bridge_registrations'},
            'completion':completion,
            'status':collection_status(self.coverage,registration_coverage,diagnostics),
            'coverage_status':'partial' if diagnostics else 'complete_within_model',
            'review_summary':review_summary,
            'scope':'Demand slices from WebView API operands; candidate relations, not vulnerability verdicts.',
            'limits':dict(asdict(self.limits),queries_per_seed=self.per_sink_limit,ir_cache_methods=self.c.max_cache),
            'entry_points':[asdict(c) for c in self.p.components if c.enabled and c.exported],
            'api_inventory':[s.as_dict() for s in inventory], 'seed_coverage':self.coverage,'registration_coverage':registration_coverage,
            'candidates':candidates,'input_webview_paths':input_paths,'bridge_javascript_paths':bridge_js,
            'intent_forwarding_paths':self.forwarders,'bridge_registrations':[{k:v for k,v in r.items() if not k.startswith('_')} for r in registrations],
            'unlinked_external_loads':unresolved,'diagnostics':diagnostics,
            'metrics':{'analysis_seconds':round(time.monotonic()-self.started,6),'instructions_executed':0,'slice_queries':self.queries,
                       'methods_visited':len(self.visited),'methods_indexed':len(self.p.methods),'candidate_count':len(candidates),
                       'input_webview_path_count':len(input_paths),'bridge_javascript_path_count':len(bridge_js),'entry_count':len(self.roots('Landroid/app/Activity;')),
                       'api_site_count':len(inventory),'ir_methods_decoded':self.c.decoded,'ir_cache_peak':self.c.cache_peak}}
