"""Reproducible read-only APK collection; path counts are not CVE verdicts."""
import argparse
import concurrent.futures
import csv
import hashlib
import importlib.metadata
import json
import pathlib
import subprocess
import sys
import time


def source_hashes(source):
    return {str(f.relative_to(source)):hashlib.sha256(f.read_bytes()).hexdigest()
            for f in sorted(source.rglob('*.py'))}


def run_case(row,corpus,output,timeout,max_steps):
    n=row['index'].zfill(2);apk=corpus/row['main_apk'];start=time.monotonic()
    item={'index':n,'cve':row['cve'],'package':row['package'],'version':row['versionName'],
          'expected_sha256':row['main_apk_sha256'],'vulnerability_verdict':'not_assessed',
          'expected_path_match':'not_reviewed','counted_success':False}
    if not apk.is_file():return dict(item,evaluation_status='input_missing')
    with apk.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    item['sha256']=digest
    if digest!=row['main_apk_sha256']:return dict(item,evaluation_status='input_hash_mismatch')
    command=[sys.executable,'-m','dotori','analyze',str(apk),'--max-apk-mib','2048',
             '--timeout',str(timeout),'--max-steps',str(max_steps),
             '-o',str(output/(n+'.json')),'--text',str(output/(n+'.txt'))]
    item['command']=command
    try:
        with (output/(n+'.log')).open('w') as log:
            result=subprocess.run(command,stdout=log,stderr=log,timeout=timeout+180)
        item.update(return_code=result.returncode,evaluation_status='collected' if result.returncode in (0,3) else 'process_failed')
    except subprocess.TimeoutExpired:
        item.update(return_code=None,evaluation_status='process_timeout')
    except OSError as exc:
        item.update(return_code=None,evaluation_status='launch_failed',error=str(exc))
    item['seconds']=round(time.monotonic()-start,3)
    report_file=output/(n+'.json')
    if item['evaluation_status']=='collected' and report_file.is_file():
        report=json.loads(report_file.read_text())
        if report['input']['sha256']!=digest:raise ValueError('Report input differs from checked input: '+n)
        item.update(status=report['status'],coverage_status=report['coverage_status'],
                    candidates=len(report['candidates']),input_paths=len(report['input_webview_paths']),
                    bridge_paths=len(report['bridge_javascript_paths']),metrics=report['metrics'])
    elif item['evaluation_status']=='collected':item['evaluation_status']='report_missing'
    return item


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('corpus',type=pathlib.Path);p.add_argument('output',type=pathlib.Path)
    p.add_argument('--cases',default='');p.add_argument('--jobs',type=int,default=2)
    p.add_argument('--timeout',type=float,default=120);p.add_argument('--max-steps',type=int,default=300000)
    a=p.parse_args()
    if a.jobs<1 or a.timeout<=0 or a.max_steps<1:p.error('positive jobs/timeout/max-steps required')
    if a.output.exists() and any(a.output.iterdir()):p.error('output directory must be empty; use a new run directory')
    a.output.mkdir(parents=True,exist_ok=True)
    rows=list(csv.DictReader((a.corpus/'manifest.csv').open(encoding='utf-8-sig')))
    if a.cases:rows=[r for r in rows if int(r['index']) in {int(v) for v in a.cases.split(',')}]
    import dotori
    source=pathlib.Path(dotori.__file__).parent;before=source_hashes(source)
    metadata={'tool_version':dotori.__version__,'python':sys.version,'source_sha256':before,
              'dependencies':{n:importlib.metadata.version(n) for n in ('androguard','pytest','setuptools')},
              'timeout_seconds':a.timeout,'max_steps':a.max_steps,'scope':'all_webview_api_sites',
              'cases':[r['index'] for r in rows],'warning':'No count or status is a CVE success label.'}
    (a.output/'run_metadata.json').write_text(json.dumps(metadata,indent=2))
    def run(row):
        try:result=run_case(row,a.corpus,a.output,a.timeout,a.max_steps)
        except Exception as exc:result={'index':row['index'],'evaluation_status':'evaluation_failed','error':str(exc),'counted_success':False}
        print(json.dumps(result),flush=True);return result
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as pool:results=list(pool.map(run,rows))
    stable=source_hashes(source)==before
    metadata['source_stable']=stable
    (a.output/'run_metadata.json').write_text(json.dumps(metadata,indent=2))
    if not stable:
        for item in results:item.update(evaluation_status='invalidated_source_changed',counted_success=False)
    (a.output/'summary.json').write_text(json.dumps(results,indent=2))
    return 0 if stable else 2


if __name__=='__main__':raise SystemExit(main())
