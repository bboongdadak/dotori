"""Compare actual evidence, independently of execution status labels."""
import argparse,json,pathlib

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('before',type=pathlib.Path);p.add_argument('after',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);a=p.parse_args()
 rows=[]
 before_meta=a.before/'run_metadata.json';after_meta=a.after/'run_metadata.json'
 if before_meta.exists() and after_meta.exists():
  bmeta=json.loads(before_meta.read_text());nmeta=json.loads(after_meta.read_text())
  if bmeta.get('source_stable') is False or nmeta.get('source_stable') is False:raise ValueError('Unstable source snapshot')
  for field in ('timeout_seconds','max_steps','scope','dependencies'):
   if bmeta.get(field)!=nmeta.get(field):raise ValueError('Different evaluation configuration: '+field)
 for current in sorted(a.after.glob('[0-9][0-9].json')):
  original=a.before/current.name
  if not original.exists():continue
  old=json.loads(original.read_text());new=json.loads(current.read_text())
  if old['input']['sha256']!=new['input']['sha256']:raise ValueError('Different APK: '+current.name)
  if old.get('analysis_selection')!=new.get('analysis_selection'):raise ValueError('Different analysis selection: '+current.name)
  row={'index':int(current.stem),'package':new['input']['package'],'sha256':new['input']['sha256'],'before_status':old['status'],'after_status':new['status'],'before_coverage':old['coverage_status'],'after_coverage':new['coverage_status'],'before_selection':old.get('analysis_selection'),'after_selection':new.get('analysis_selection'),'evidence_groups':{}}
  for group in ('candidates','input_webview_paths','bridge_javascript_paths'):
   before={v['id']:v for v in old[group]};after={v['id']:v for v in new[group]}
   row['evidence_groups'][group]={'before':len(before),'after':len(after),'added_ids':sorted(after.keys()-before.keys()),'removed_ids':sorted(before.keys()-after.keys()),'retained_ids':sorted(before.keys()&after.keys()),'changed_retained_ids':sorted(k for k in before.keys()&after.keys() if before[k]!=after[k])}
   def semantic(items):
    result=set()
    for v in items.values():
     sink=v.get('load',v.get('javascript_execution',{}));source=v.get('source',{})
     result.add((v.get('classification'),source.get('kind'),source.get('key'),source.get('entry'),sink.get('site'),sink.get('argument_index'),v.get('bridge',{}).get('site')))
    return result
   bsem=semantic(before);nsem=semantic(after)
   row['evidence_groups'][group]['semantic_locators']={'before':len(bsem),'after':len(nsem),'retained':len(bsem&nsem),'removed':[list(v) for v in sorted(bsem-nsem,key=str)],'added':[list(v) for v in sorted(nsem-bsem,key=str)],'meaning':'Locators ignore branch/receiver variants and ID schema changes. Retention is not proof equivalence or CVE success.'}
  row['before_diagnostic_codes']=sorted({d['code'] for d in old['diagnostics']});row['after_diagnostic_codes']=sorted({d['code'] for d in new['diagnostics']});rows.append(row)
 a.output.write_text(json.dumps({'warning':'Counts and execution status are not CVE success. Inspect source, sink, receiver and constraints for each case.','cases':rows},indent=2))
if __name__=='__main__':main()
